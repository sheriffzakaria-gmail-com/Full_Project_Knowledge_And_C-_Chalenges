Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.Mvc
Imports Cart.Models

Namespace Cart.Controllers
 ' this controller class "ProductController" is administrator class
    ' we here admin the products inside the our store
    'the products which the customers later can choose from them and add to thier carts
    'here we add the products , thier names and prices 
    ',edit the names and prices and also delete the whole product
    'here i use different types of validation for example
   ' i validate if the same product entered before or not using the 
   'jquery validation and remote attribute which use the function 
    'Check_Dublication in validation also i apply required and lenght validation 
    ' as shown in the ShoppingCartItem model related to ProductName property as shown in the below
        '<Required(AllowEmptyStrings:=False, ErrorMessage:="* Product Name Field Is Required")>
        '<StringLength(10, ErrorMessage:="You Exceeded The Maximum Lenght Which Is 10")>
        '<Remote("Check_Dublication", "Product", ErrorMessage:="Sorry But This Product Already Exist Before")>
        'Public Property ProductName As String
'==============================================================================================================
    Public Class ProductController
        Inherits Controller

        Private db As Cart_Entities = New Cart_Entities()

        Public Function Index() As ActionResult
            Dim products As List(Of ShoppingCartItem) = db.ShoppingCartItems.ToList()
            Return View(products)
			'or we can say also ===========================================================
            'dim product_data_table = db.ShoppingCartItems;
            'return View(product_data_table);
        End Function

        Public Function Create() As ActionResult
            Return View()
        End Function

        <HttpPost>
        Public Function Add(ByVal product As ShoppingCartItem) As ActionResult
            product.ShoppingCartID = 1 'i fix the value = 1 just for test and we suppose we have only 1 cart

            If ModelState.IsValid = True Then
                db.ShoppingCartItems.Add(product)
                db.SaveChanges()
                Return RedirectToAction("Index")
            Else
                Return View("Create")
            End If
        End Function

        Public Function Edit(ByVal ID As Integer) As ActionResult
            Dim product As ShoppingCartItem = db.ShoppingCartItems.Find(ID)
            Return View(product)
        End Function

        <HttpPost>
        Public Function Edit(ByVal new_obj As ShoppingCartItem) As ActionResult
            Dim old_obj As ShoppingCartItem = db.ShoppingCartItems.Find(new_obj.ID)
            old_obj.ProductName = new_obj.ProductName
            old_obj.Quantity = new_obj.Quantity
            old_obj.UnitPrice = new_obj.UnitPrice
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Public Function Delete(ByVal ID As Integer) As ActionResult
            Dim product As ShoppingCartItem = db.ShoppingCartItems.Find(ID)
            Return View(product)
        End Function

        <HttpPost>
        Public Function Delete(ByVal product As ShoppingCartItem) As ActionResult
            Dim del_obj As ShoppingCartItem = db.ShoppingCartItems.Find(product.ID)
            db.ShoppingCartItems.Remove(del_obj)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Public Function Check_Dublication(ByVal ProductName As String) As JsonResult
            Dim result As Boolean
            Dim dublication As Integer = db.ShoppingCartItems.Where(Function(tbl) tbl.ProductName = ProductName).Count()

            If dublication = 0 Then
                result = True
            Else
                result = False
            End If

            Return Json(result, JsonRequestBehavior.AllowGet)
        End Function
    End Class
End Namespace

'========================now i will write the views which belongs to this controller (product controller)===========================================
'1- index.vbhtml

@ModelType IEnumerable(Of Cart.Models.ShoppingCartItem)
@Code
    Layout = Nothing
End Code

<!DOCTYPE html>

<html>
<head>
    <meta name="viewport" content="width=device-width" />
    <title>Index</title>
</head>
<body>
    <div> 
        <a href="/Product/Create">Add New Product</a>
        <p></p>
        <table border="1">
            <thead>All Products</thead>
            <tr><td>ID</td><td>Product Name</td><td>Product Quantity</td><td>Product Price</td></tr>
            @For Each item In Model
            
            @<tr>
                <td>@item.ID</td>
                <td>@item.ProductName</td>
                <td>@item.Quantity</td>
                <td>@item.UnitPrice</td>
                <td><a href="\Product\Edit\@item.ID">Edit</a></td>
                <td><a href="\Product\Delete\@item.ID">Delete</a></td>

            </tr>
            Next
        </table>
    </div>
</body>
</html>

'2- Create.vbhtml=============================================================================================================================

@ModelType Cart.Models.ShoppingCartItem
@Code
    Layout = Nothing
End Code

<!DOCTYPE html>

<html>
<head>
    <script src="~/Scripts/jquery-3.3.1.js"></script>
    <script src="~/Scripts/jquery.validate.js"></script>
    <script src="~/Scripts/jquery.validate.unobtrusive.js"></script>
    <meta name="viewport" content="width=device-width" />
    <title>Create</title>
</head>
<body>
    <div> 
<a href="\Product\Index">All Products</a>
<p></p>
@Using @Html.BeginForm("Add", "Product", FormMethod.Post)
        
        @<table border="1">
            <thead>Add New Product</thead>
            <tr>
                <td>Product Name : </td>
                <td>@Html.TextBoxFor(tbl >= tbl.ProductName,
             New With {.type = "text", .placeholder = "Enter Product Name", .maxlength = "14", .required = True})</td>
                <td>@Html.ValidationMessageFor(Function(tbl) tbl.ProductName)</td>
                </tr>

            <tr>
            <td>Product Quantity : </td>
            <td>@Html.TextBoxFor(Function(tbl) tbl.Quantity, New With {.type = "integer"})</td>
             </tr>

                <tr>
                    <td>Product Price : </td>
                    <td>@Html.TextBoxFor(Function(tbl) tbl.UnitPrice, New With {.type = "decimal"})</td>
                 </tr>

        </table>
        @<input type="submit" value="Add New Product" />
        End Using


    </div>
</body>
</html>

'3- Edit.vbhtml====================================================================================================================================

@ModelType Cart.Models.ShoppingCartItem
@Code
    Layout = Nothing
End Code

<!DOCTYPE html>

<html>
<head>
    <meta name="viewport" content="width=device-width" />
    <title>Edit</title>
</head>
<body>
    <div> 
<a href="\Product\Create">Add New Product</a>
<a href="\Product\Index">All Products</a>
<p></p>
@Using @Html.BeginForm("Edit", "Product", FormMethod.Post)

        
         @<table border="1">
             <thead>Edit Process</thead>
             <tr>
             <td>Edit Product Name : </td>
             <td>@Html.TextBoxFor(Function(tbl) tbl.ProductName,
             New With {.type = "text", .placeholder = "Edit Product Name", .maxlength = "12", .required = True})</td>
            <td>@Html.ValidationMessageFor(Function(tbl) tbl.ProductName)</td>
             </tr>
             <tr>
                 <td>Edit Product Quantity :</td>
                 <td>@Html.TextBoxFor(Function(tbl) tbl.Quantity)</td>
             </tr>
             <tr>
                 <td> Edit Product Price : </td>
                 <td>@Html.TextBoxFor(Function(tbl) tbl.UnitPrice)</td>
             </tr>
              
         </table>
            @<input type = "submit" value="Update This Product" />
        End Using
    </div>
</body>
</html>

4- Delete.vbhtml=================================================================================================================================

@ModelType Cart.Models.ShoppingCartItem
@Code
    Layout = Nothing
End Code

<!DOCTYPE html>

<html>
<head>
    <meta name="viewport" content="width=device-width" />
    <title>Delete</title>
</head>
<body>
    <div> 
<a href="\Product\Create">Add New Product</a>
<a href="\Product\Index">All Products</a>
<p></p>

@using Html.BeginForm("Delete", "Product", FormMethod.Post)
        
            @<table border="1">
                <thead>Delete Process</thead>
                <tr>
                    <td>Product Name :</td>
                    <td>@Html.DisplayFor(Function(tbl) tbl.ProductName)</td>
                </tr>
                <tr>
                    <td>Product Quantity :</td>
                    <td>@Html.DisplayFor(Function(tbl) tbl.Quantity)</td>
                </tr>
                <tr>
                    <td>Product Price :</td>
                    <td>@Html.DisplayFor(Function(tbl) tbl.UnitPrice)</td>
                </tr>
                   

            </table>
            @<input type="submit" value="Delete This Product"/>
    End Using
    </div>
</body>
</html>

'==============now i will write the 1- ShoppingCartItem Model class  and 2- ShoppingCart Model class=============================================

Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.Web.Mvc

Namespace Cart.Models
    Public Partial Class ShoppingCartItem
        Public Property ID As Integer
		
        <Required(AllowEmptyStrings:=False, ErrorMessage:="* Product Name Field Is Required")>
        <StringLength(10, ErrorMessage:="You Exceeded The Maximum Lenght Which Is 10")>
        <Remote("Check_Dublication", "Product", ErrorMessage:="Sorry But This Product Already Exist Before")>
        Public Property ProductName As String
        
		Public Property Quantity As Integer
        Public Property UnitPrice As Decimal
        Public Property ShoppingCartID As Integer
        Public Overridable Property ShoppingCart As ShoppingCart
    End Class
End Namespace

'--------------------------------------------------------------------------------------------------------------------------------------------
Imports System
Imports System.Collections.Generic

Namespace Cart.Models
    Public Partial Class ShoppingCart
        Public Sub New()
            Me.ShoppingCartItems = New HashSet(Of ShoppingCartItem)()
        End Sub

        Public Property ID As Integer
        Public Property SubTotal As Nullable(Of Decimal)
        Public Property Tax As Nullable(Of Decimal)
        Public Property Shipping As Nullable(Of Decimal)
        Public Property Total As Nullable(Of Decimal)
        Public Overridable Property ShoppingCartItems As ICollection(Of ShoppingCartItem)
    End Class
End Namespace


'=================================================================================================================================================
'=================================================================================================================================================
'now i will write the customer side business  controller class which handle the customer's choice from our store's products this controller class will be 'responsible for adding the different products(items) to the cart and edit the quantity and delete the added product (item) by the customer 
'=================================================Customer_Shopping_CartControlle===================================================================
Imports System
Imports System.Net
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.Mvc
Imports Cart.Models

Namespace Cart.Controllers
    Public Class Customer_Shopping_CartController
        Inherits Controller

        Private db As Cart_Entities = New Cart_Entities()
        Private cart As ShoppingCart = New ShoppingCart()

        Public Function Show_Products() As ActionResult
            Dim products As List(Of ShoppingCartItem) = db.ShoppingCartItems.ToList()
            Return View(products)
        End Function

        Public Function Add_To_Cart(ByVal ID As Integer) As ActionResult
            If ID Is Nothing Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest, "BAD ID")
            End If

            Dim product As ShoppingCartItem = db.ShoppingCartItems.Find(ID)

            If Session("cart") Is Nothing Then
                product.Quantity = 1
                cart.ShoppingCartItems.Add(product)
				'Session("cart") = cart.ShoppingCartItems
                Session("cart") = cart
				
            Else
                'cart.ShoppingCartItems = CType(Session("cart"), ICollection(Of ShoppingCartItem))
                If check_product_adding_before(ID) = False Then
                    product.Quantity = 1
                    cart.ShoppingCartItems.Add(product)
                Else
                End If

                Session("cart") = cart
            End If

            Return View("Show_Customer_Products", cart)
        End Function

        Public Function check_product_adding_before(ByVal id As Integer) As Boolean
            Dim result As Boolean = False

            If Session("cart") IsNot Nothing Then
                cart = CType(Session("cart"), ShoppingCart)

                For Each product As ShoppingCartItem In cart.ShoppingCartItems

                    If product.ID = id Then
                        product.Quantity = product.Quantity + 1
                        result = True
                        Return result
                    Else
                        result = False
                    End If
                Next
            End If

            Return result
        End Function

        Public Function Remove_Product_From_The_cart(ByVal ID As Integer) As ActionResult
            cart = CType(Session("cart"), ShoppingCart)
            Dim product As ShoppingCartItem = cart.ShoppingCartItems.First(Function(obj) obj.ID = ID)
            cart.ShoppingCartItems.Remove(product)
            Session("cart") = cart
            Return View("Show_Customer_Products", cart)
        End Function

       

        Public Function Check_Out() As ActionResult
            cart = CType(Session("cart"), ShoppingCart)
            
			'save the  quantity which requsted by the customer in data base of each item in the cart
            For Each product As ShoppingCartItem In cart.ShoppingCartItems
                db.ShoppingCartItems.Find(product.ID).Quantity = product.Quantity
            Next

            db.SaveChanges()
			
			'save the totals of shoping cart in database 
            Dim db_cart As ShoppingCart = db.ShoppingCarts.FirstOrDefault()
            cart.ID = db_cart.ID
            db_cart.SubTotal = cart.SubTotal
            db_cart.Tax = cart.Tax
            db_cart.Shipping = cart.Shipping
            db_cart.Total = cart.Total
            db.SaveChanges()
            Session.Remove("cart")
            Return View()
        End Function
    End Class
End Namespace

'========================now i will write the views which belongs to this controller (Customer_Shopping_Cart controller)===========================
'1- Show_Products.vbhtml===========================================================================================================================

@ModelType IEnumerable(Of cart.models.shoppingcartitem)
    @Code
        layout = Nothing
    End Code
    

    <!DOCTYPE HTML>

    <html>
    <head>
        <meta name="viewport" content="width=device-width" />
        <title>Show_Products</title>
    </head>
    <body>
        <div>
            <table border="1" cellpadding="2" cellspacing="2">
                <thead>All Products</thead>
                <tr>
                    <td>ID</td>
                    <td>Product Name</td>
                    <td>Product Price</td>
                    <td>Add To Cart</td>
                </tr>
               @For Each item In Model
                   @<tr>
                    <td>@item.ID</td>
                    <td>@item.ProductName</td>
                    <td>@item.UnitPrice</td>
                    <td>@Html.ActionLink("Add To Cart", "Add_To_Cart", "Customer_Shopping_Cart", new with { .ID = item.ID }, null)</td>
                </tr>
               Next
                

                
                
            </table>
        </div>
    </body>
</html>

'2- Show_Customer_Products.vbhtml==================================================================================================================
@ModelType Cart.Models.ShoppingCart
@Code
    
    Layout = Nothing
    
    Dim product_subtotal As Decimal
    Dim product_tax As Decimal
    Dim product_cost As Decimal
    Dim product_shiping As Decimal = 0
    Dim order_tax As Decimal = 0
    Dim order_shiping As Decimal = 0
    Dim total_order As Decimal = 0
    Dim total_order_cost As Decimal = 0
End Code

<!DOCTYPE html>

<html>
<head>
    <meta name="viewport" content="width=device-width" />
    <title>Show_Customer_products</title>
</head>

<body>
    <div>
        <font color="#0099ff">
            <table border="1" cellpadding="1">

                <thead>Customer Cart</thead>
                <tr>
                    <td>Product Name</td>
                    <td>Product Price</td>
                    <td>Product Quantity</td>
                    <td>Product SubTotal</td>
                    <td>Product Tax</td>
                    <td>Product Cost</td>
                    <td>Product Shipping</td>
                    <td>Remove Product</td>

                </tr>

                @For Each item In Model.ShoppingCartItems
                    product_subtotal = Math.Round(item.UnitPrice * item.Quantity, 2)
                    item.ShoppingCart.SubTotal = product_subtotal
                    product_tax = Math.Round(product_subtotal * CDec(0.065), 2)
                    item.ShoppingCart.Tax = product_tax
                    product_cost = Math.Round(product_subtotal + product_tax, 2)
                    item.ShoppingCart.Total = product_cost

                    If product_cost > 100 Then
                        product_shiping = 0
                    ElseIf product_cost <= 25 Then
                        product_shiping = product_cost * CDec(0.15)
                    ElseIf product_cost > 25 AndAlso product_cost <= 100 Then
                        product_shiping = 5
                    End If

                    If product_shiping > 0 Then
                        product_shiping = Math.Round(product_shiping, 2)
                    End If

                    item.ShoppingCart.Shipping = product_shiping
                    order_tax += product_tax
                    order_shiping = order_shiping + product_shiping
                    total_order = total_order + product_cost

                    @<tr>
                        <td>@item.ProductName</td>
                        <td>@item.UnitPrice</td>
                        <td>@item.Quantity</td>
                        <td>@String.Format("${0:0.00}", product_subtotal)</td>
                        <td>@product_tax</td>
                        <td>@product_cost</td>
                        <td>@product_shiping</td>
                        <td>
                            @Html.ActionLink("Rmove This Product From The Cart",
                            "Remove_Product_From_The_cart", "Customer_Shopping_Cart",
                            New With {.ID = item.ID},
                            New With {.onclick = "return confirm('Are You Sure To Remove This Product From The Cart')"})
                    </td>

                </tr>


                Next
        </font>


        @If (total_order > 100) Then
        
            order_shiping = 0
        End If

        @total_order_cost = total_order + order_shiping


            @<tr  style="color: #0000b3; font-size: x-large; ">@total_order_cost = total_order + order_shiping


            <tr  style="color: #0000b3; font-size: x-large; ">@*#6600ff*@

           

            @Code
                'assign the values of calculated totals to cart model
                Model.SubTotal = Math.Round(total_order, 2)
                Model.Tax = Math.Round(order_tax, 2)
                Model.Shipping = Math.Round(order_shiping, 2)
                Model.Total = Math.Round(total_order_cost, 2)
                Session("cart") = Model
                
            End Code
                  
                 <td>Totals</td>
                <td></td>
            @*in the two below statments I calculated the accumulated Quantity
                and SubTotal with another way using the SUM LINQ function*@
                <td>@Model.ShoppingCartItems.Sum(Function(tbl_obj) tbl_obj.Quantity)</td>
                <td>$@Model.ShoppingCartItems.Sum(Function(tbl_obj) tbl_obj.ShoppingCart.SubTotal)</td>
                <td>@Model.Tax.Value</td>
                <td>@Model.SubTotal.Value</td>
                <td>@order_shiping</td>

            </tr>
            </table>


       <h3 style="text-align:right"> @Html.ActionLink("Continue Shopping", "Show_Products")</h3>

        <p></p>
            <h1>
                <font color="#9900cc">
                    Dear Customer
                    <br /><br />
                    Your Total Order Cost Is : $@Math.Round(total_order, 2)<br />
                    Your Total Shipping Cost IS : $@Math.Round(order_shiping, 2) <br />
                    Your Total Order Is : $@Math.Round(total_order_cost, 2)
                    <hr />

                    @Html.ActionLink("Check Out", "Check_Out")
                    <br /><br /><br /><br />
                    Thank You So Much For Your Shoping From Our Mega Store <br />
                    We Want See You Again And Always :)
                    <hr />

                </font>
            </h1>
    </div>
</body>
</html>

'3- Check_Out.vbhtml===============================================================================================================================

@Code
    Layout = Nothing
End Code

<!DOCTYPE html>

<html>
<head>
    <meta name="viewport" content="width=device-width" />
    <title>Check_Out</title>
</head>
<body>
    <div> 
        <h1>
            Thanks for completed the marketing process <br />
            Your Order Process has been Done successfully <br />
            Pkease Click @Html.ActionLink("Here", "Show_Products")
            To Continue Shopping And Create New Order
        </h1>

    </div>
</body>
</html>

'===================================:) Thank you from Sherief Zakaria :)============================================================================

