﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Cart.Models;
namespace Cart.Controllers
{
    public class Customer_Shopping_CartController : Controller
    {
        //
        // GET: /Customer_Shopping_Cart/
        Cart_Entities db = new Cart_Entities();
        ShoppingCart cart = new ShoppingCart();
        
        public ActionResult Show_Products()
        {
            
            List<ShoppingCartItem> products = db.ShoppingCartItems.ToList();
            
            return View(products);
        }

        public ActionResult Add_To_Cart(int ID)
        {
            if (ID==null)
            {
                
              return new HttpStatusCodeResult(HttpStatusCode.BadRequest,"BAD ID");
            }
            
           
            ShoppingCartItem product = db.ShoppingCartItems.Find(ID);
            
            if (Session["cart"] == null)
            {
             product.Quantity = 1;   
             cart.ShoppingCartItems.Add(product);
             
             //Session["cart"] = cart.ShoppingCartItems; 
             Session["cart"] = cart ;
             
            }

            else
            {
                 //cart.ShoppingCartItems = (ICollection<ShoppingCartItem>)Session["cart"];
                 if (check_product_adding_before(ID) == false)
                 {
                     product.Quantity = 1;
                     cart.ShoppingCartItems.Add(product);
                 }
                 else
                 {
                     
 
                 }
                
                Session["cart"] = cart;
            } //else close

            
            return View("Show_Customer_Products", cart);
        }

        public Boolean check_product_adding_before(int id)
        {
            Boolean result = false;
            if (Session["cart"] != null)
            {
                //foreach (ShoppingCartItem product in (ICollection<ShoppingCartItem>)Session["cart"])//we can use also for itration  IEnumerable or List as same as Icollection
                cart = (ShoppingCart)Session["cart"];
                foreach (ShoppingCartItem product in cart.ShoppingCartItems)
                {
                    if (product.ID == id)
                    {
                       product.Quantity = product.Quantity + 1;
                        result = true;
                        return result;
                    }
                    else
                    {
        
                        result = false;
                    }
                       
                } 
            }

            return result;
        }


        public ActionResult Remove_Product_From_The_cart(int ID)
        {
            cart = (ShoppingCart)Session["cart"]; 
            ShoppingCartItem product = cart.ShoppingCartItems.First(obj => obj.ID == ID);
            cart.ShoppingCartItems.Remove(product);
 
          Session["cart"] = cart;
          return View("Show_Customer_Products", cart);
    
        }
    public ActionResult Check_Out2()
    {
        //ShoppingCart c = new ShoppingCart();

        cart.ShoppingCartItems = (ICollection<ShoppingCartItem>)Session["cart"];
        foreach(ShoppingCartItem product in cart.ShoppingCartItems)
        {
            db.ShoppingCartItems.Find(product.ID).Quantity = product.Quantity;
            
        }
        
         db.SaveChanges(); 
         cart.SubTotal=  ViewBag.SubTotal;
         cart.Tax = ViewBag.order_tax;
         cart.Shipping = ViewBag.order_shiping;
         cart.Total = ViewBag.total;
        
         
        ShoppingCart db_cart = db.ShoppingCarts.FirstOrDefault(tbl_obj=>tbl_obj.ID ==cart.ID);        
        db_cart = cart;
        db.SaveChanges();
        Session.Remove("cart");
        return View();

    }
    public ActionResult Check_Out()
    {
        
        cart = (ShoppingCart)Session["cart"];
        //save the  quantity which requsted by the customer in data base of each item in the cart
        foreach (ShoppingCartItem product in cart.ShoppingCartItems)
        {
            db.ShoppingCartItems.Find(product.ID).Quantity = product.Quantity;
        }
        db.SaveChanges();
        
       // save the totals of shoping cart in database 
       ShoppingCart db_cart = db.ShoppingCarts.FirstOrDefault();
       cart.ID = db_cart.ID;

       db_cart.SubTotal = cart.SubTotal;
       db_cart.Tax = cart.Tax;
       db_cart.Shipping = cart.Shipping;
       db_cart.Total = cart.Total;
       db.SaveChanges();
       
        Session.Remove("cart");
        return View();
        
    }
    }//class
   
}//name space