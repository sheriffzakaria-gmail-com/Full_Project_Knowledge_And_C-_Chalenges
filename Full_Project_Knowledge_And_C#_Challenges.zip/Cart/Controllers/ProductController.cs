﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Cart.Models;
namespace Cart.Controllers
{
    // this class is administrator class
    // we here admin the products inside the our store
    //the products which the customers later can choose from them and add to thier carts
    //here we add the products , thier names and prices 
    //,edit the names and prices and also delete the whole product
    //here i use different types of validation for example
   // i validate if the same product entered before or not using the 
   //jquery validation and remote attribute which use the function 
    //Check_Dublication in validation also i apply required and lenght validation 
    // as shown in the ShoppingCartItem model related to ProductName property as shown in the below
        //[Required(AllowEmptyStrings = false ,ErrorMessage="* Product Name Field Is Required" )]
        //[StringLength(10, ErrorMessage = "You Exceeded The Maximum Lenght Which Is 10")]
        //[Remote("Check_Dublication", "Product",ErrorMessage="Sorry But This Product Already Exist Before")]
        //public string ProductName { get; set; }
//==============================================================================================================
    public class ProductController : Controller
    {
        //
        // GET: /Product/
        Cart_Entities  db = new  Cart_Entities();
        public ActionResult Index()
        {
            List<ShoppingCartItem> products = db.ShoppingCartItems.ToList();
            return View(products);
            //or ===========================================================
            //var product_data_table = db.ShoppingCartItems;
            //return View(product_data_table);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Add(ShoppingCartItem product)
        {
            product.ShoppingCartID = 1; //i fix the value = 1 just for test and we suppose we have only 1 cart
         if    (ModelState.IsValid == true)
        {
             db.ShoppingCartItems.Add(product);
             db.SaveChanges();
            return RedirectToAction("Index");
         }
         else 
         {
             return View("Create");
         }

        }
        
        public ActionResult Edit(int ID)
        {
            ShoppingCartItem product = db.ShoppingCartItems.Find(ID); 
            return View(product);
        }

        [HttpPost]
        public ActionResult Edit(ShoppingCartItem new_obj)
        {
            ShoppingCartItem old_obj = db.ShoppingCartItems.Find(new_obj.ID);
            old_obj.ProductName = new_obj.ProductName;
            old_obj.Quantity = new_obj.Quantity;
            old_obj.UnitPrice = new_obj.UnitPrice;
            db.SaveChanges();
            return RedirectToAction("Index");

        }

        public ActionResult Delete(int ID)
        {
            ShoppingCartItem product = db.ShoppingCartItems.Find(ID);
            return View(product);
        }

        [HttpPost]
        public ActionResult Delete(ShoppingCartItem product)
        {
            ShoppingCartItem del_obj = db.ShoppingCartItems.Find(product.ID);
            db.ShoppingCartItems.Remove(del_obj);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        
        public JsonResult Check_Dublication(String ProductName)
        {
            Boolean result;
            int dublication = db.ShoppingCartItems.Where(tbl => tbl.ProductName == ProductName).Count();
            if (dublication == 0)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return Json(result, JsonRequestBehavior.AllowGet);    
        }
	}
}