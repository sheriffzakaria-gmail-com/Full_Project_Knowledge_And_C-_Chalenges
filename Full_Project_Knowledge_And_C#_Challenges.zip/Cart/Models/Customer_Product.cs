﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cart.Models
{
    public class Customer_Product
    {
        public ShoppingCartItem product { get; set; } 
        public Customer_Product (ShoppingCartItem f_product)
    {
        product = f_product;
    }


    }    
    
   

    
}