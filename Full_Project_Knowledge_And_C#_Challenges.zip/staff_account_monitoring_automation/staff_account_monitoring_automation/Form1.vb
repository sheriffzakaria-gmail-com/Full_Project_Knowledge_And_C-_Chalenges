﻿Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Data.Odbc
Imports System.Data.OleDb
Imports Microsoft.VisualBasic
Imports System.Diagnostics
'Imports System.Data.OracleClient
Imports Oracle.DataAccess.Client
Imports System.IO



Public Class staff_account_monitoring
    Dim connection_string As String
    Dim required_connection As String
    Dim DWH_Connection_String As String
    Dim oracle_Connection_String As String
    Dim sql_connection_string As String
    Dim data_table As DataTable
    Dim data_set_various As DataSet
    Dim data_row_various As DataRow

    Dim last_trn_date As String

    Dim sql_table_name As String
    Dim data_table_name As String

    Dim error_file_name As String
    Dim LogFileName As String


    Dim sql As String
    Dim type As Integer
    Public Function prepare_connection(ByVal s_required_connection As String) As String
        Return GetConnectionString3(s_required_connection) 'because GeneralClass under app_code we use it direct without import it in this class
    End Function
    Public Shared Function GetConnectionString3(ByVal web_config As String) As String

        Return ConfigurationManager.ConnectionStrings(web_config).ConnectionString

    End Function
    Public Sub write_error(ByVal s_error_path_file As String, ByVal s_error As String)
        Dim file_stream As New FileStream(s_error_path_file, FileMode.Create, FileAccess.Write)
        Dim stream_writer As New StreamWriter(file_stream)
        stream_writer.WriteLine(s_error)

        stream_writer.Close()
        stream_writer.Dispose()
        stream_writer = Nothing

        file_stream.Close()
        file_stream.Dispose()
        file_stream = Nothing
    End Sub

    Public Sub write_LOG(ByVal s_Log_path_file As String, ByVal s_Message As String)
        Dim file_stream As New FileStream(s_Log_path_file, FileMode.Append, FileAccess.Write)
        Dim stream_writer As New StreamWriter(file_stream)
        stream_writer.WriteLine(s_Message)

        stream_writer.Close()
        stream_writer.Dispose()
        stream_writer = Nothing

        file_stream.Close()
        file_stream.Dispose()
        file_stream = Nothing
    End Sub
    Public Function get_last_trn_date(ByVal f_sql_connection_string, ByVal f_sql) As String
        Dim last_run_date As Date
        Try
            Using connection_object As New SqlConnection(f_sql_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
                connection_object.Open()
                Using general_command As New SqlCommand(f_sql, connection_object) ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                    general_command.CommandType = CommandType.Text
                    last_run_date = general_command.ExecuteScalar

                    Return last_run_date
                End Using
            End Using
        Catch ex As Exception
            Throw
        End Try
    End Function

    Public Function get_oracle_script(ByVal f_sql_connection_string, ByVal f_sql) As String
        Dim oracle_script As String
        Try
            Using connection_object As New SqlConnection(f_sql_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
                connection_object.Open()
                Using general_command As New SqlCommand(f_sql, connection_object) ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                    general_command.CommandType = CommandType.Text
                    oracle_script = general_command.ExecuteScalar

                    Return oracle_script
                End Using
            End Using
        Catch ex As Exception
            Throw
        End Try

    End Function
    Public Function get_data_from_DWH(ByVal f_oracle_connection_string As String, ByVal f_sql As String, ByVal f_data_table_name As String) As DataTable

        Dim data_set As New DataSet
        Dim oracle_data_table As New DataTable
        Dim oracle_data_row As DataRow
        Dim oracle_data_colunm As DataColumn


        Try

            Using oracle_connection_object As New OdbcConnection(f_oracle_connection_string)
                oracle_connection_object.ConnectionTimeout = 0
                oracle_connection_object.Open()

                Using oracle_command As New OdbcCommand(f_sql, oracle_connection_object)
                    oracle_command.CommandTimeout = 0
                    oracle_command.CommandType = CommandType.Text
                    Using oracle_data_adabter As New OdbcDataAdapter(oracle_command)
                        oracle_data_adabter.Fill(data_set, f_data_table_name)
                        oracle_data_table = data_set.Tables(f_data_table_name)
                        Return oracle_data_table

                    End Using

                End Using

            End Using
        Catch ex As Exception


            Throw 'means throw and transfer the error to the main sub which is in this case  form_load
        Finally


        End Try
    End Function
    Public Function get_data_from_oracle(ByVal f_oracle_connection_string As String, ByVal f_sql As String, ByVal f_data_table_name As String) As DataTable

        Dim data_set As New DataSet
        Dim oracle_data_table As New DataTable
        Dim oracle_data_row As DataRow
        Dim oracle_data_colunm As DataColumn


        Try

            Using oracle_connection_object As New OracleConnection(f_oracle_connection_string)
                'oracle_connection_object.ConnectionTimeout = 0 'because it is read only
                oracle_connection_object.Open()

                Using oracle_command As New OracleCommand(f_sql, oracle_connection_object)
                    oracle_command.CommandTimeout = 0
                    oracle_command.CommandType = CommandType.Text
                    Using oracle_data_adabter As New OracleDataAdapter(oracle_command)
                        oracle_data_adabter.Fill(data_set, f_data_table_name)
                        oracle_data_table = data_set.Tables(f_data_table_name)
                        Return oracle_data_table

                    End Using

                End Using

            End Using
        Catch ex As Exception


            Throw 'means throw and transfer the error to the main sub which is in this case  form_load
        Finally


        End Try
    End Function
    Public Sub upload_from_oracle_to_sql(ByVal s_sql_connection_string As String, ByVal s_oracle_data_table As DataTable, ByVal s_sql_table_name As String, ByVal s_Drop_Table_If_Exists As Boolean)
        Try
            Using connection_object As New SqlConnection(s_sql_connection_string)
                connection_object.Open()
                Dim sqlTableCreator As SQLCreateTable = New SQLCreateTable

                sqlTableCreator.Connection = connection_object
                sqlTableCreator.DestinationTableName = s_sql_table_name
                sqlTableCreator.DropTableIfExists = s_Drop_Table_If_Exists
                sqlTableCreator.CreateFromDataTable(s_oracle_data_table)


                Using Sql_Bulk As New SqlBulkCopy(connection_object)
                    Sql_Bulk.DestinationTableName = s_sql_table_name
                    Sql_Bulk.NotifyAfter = 1000
                    Sql_Bulk.WriteToServer(s_oracle_data_table)
                    Sql_Bulk.Close()
                End Using
            End Using
        Catch ex As Exception
            Throw
        End Try



    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '  data center and command line execute  
        Dim Dir_path As String


        Dim command_string As String = Command()
        'command_string = "c:,C:\currior\birthday,C:\currior\sms_birthday,1,is-egypt\20128611,@V.2323" 'for testCommandString = "C:\Documents and Settings\2012861\My Documents\ss\,SW-1006231-103.txt,out.txt,1"
        'note the command string uusing dc task manager inside it's job create the job dir which create folder by job id and date + time and pass this folder to the exe wich concatenate the file name on the folder path
        command_string = "c:,"
        Try

            If command_string = "?" Or command_string = "" Then
                MsgBox("1- dir_path , 2- path_birthday_file which is out put path for example C:\currior\birthday\ , 3- path_sms_file which is out put path for example C:\currior\sms_birthday\ , 4- parameter which determine which sub to run")
            ElseIf command_string <> "" Then

                Dir_path = command_string.Split(",")(0) & "\"
                error_file_name = IO.Path.Combine(Dir_path, "Error.err")
                LogFileName = IO.Path.Combine(Dir_path, "Log.txt")

                For i = 1 To 3

                    required_connection = "sql_Connection_String"
                    sql_connection_string = prepare_connection(required_connection)

                    If i = 1 Then
                        sql_table_name = "Staff_Account_Monitoring_50000"
                        data_table_name = "staff_account_50000"
                    ElseIf i = 2 Then
                        sql_table_name = "Staff_Transfer"
                        data_table_name = "transfer"

                    ElseIf i = 3 Then
                        sql_table_name = "Staff_OD"
                        data_table_name = "staff_od"
                    End If


                    sql = "SELECT  Convert(varchar,(SELECT MAX(DAT_TXN) FROM " & sql_table_name & " ),103)"

                    last_trn_date = get_last_trn_date(sql_connection_string, sql)
                    'last_trn_date = "24/07/2016"

                    If i <> 3 Then 'for dwh only we get qracle script from sql server table called oracle_script_table
                        sql = "select script from oracle_script_table where RecordID = " & i

                        sql = get_oracle_script(sql_connection_string, sql) 'sql here is oracle script  which readed from sql server table called oracle_script_table

                        sql = sql & last_trn_date & "','dd/mm/yyyy') order by DAT_TXN"
                        required_connection = "DWH_Connection_String"
                        DWH_Connection_String = prepare_connection(required_connection)
                        data_table = get_data_from_DWH(DWH_Connection_String, sql, data_table_name)

                    ElseIf i = 3 Then
                        required_connection = "oracle_Connection_String"
                        oracle_Connection_String = prepare_connection(required_connection)

                        sql = "SELECT d_mis_date as DAT_TXN , v_product_code ,v_acct_no, v_acct_status, v_branch_code , " & _
                        "v_customer_code, n_eop_bal_dr, v_currency_code, dat_last_overdue " & _
                        "FROM fct_od_accounts_fcr r " & _
                        "WHERE     r.d_mis_date >  TO_DATE ( '" & last_trn_date & "', 'DD/MM/YYYY') " & _
                         "AND r.v_customer_code IN " & _
                         "(SELECT u.v_customer_code FROM dim_customer u " & _
                        "WHERE u.d_mis_date > TO_DATE ( '" & last_trn_date & "', 'DD/MM/YYYY')" & _
                        "AND u.f_cust_staffind = 'Y') AND v_product_code IN (602) " & _
                        "UNION ALL " & _
                        "SELECT    r.d_mis_date as DAT_TXN , v_product_code ,v_acct_no, v_acct_status, v_branch_code , " & _
                        "v_customer_code, n_eop_bal_dr, v_currency_code, dat_last_overdue " & _
                        "FROM    fct_od_accounts_fcr r JOIN BBE_UDF lg_udf " & _
                        "ON     lg_udf.d_mis_date = r.d_mis_date AND lg_udf.udf_flag = 'TXT_225' " & _
                        "AND lg_udf.udf_value IN ('NON LGS', 'LGS') AND lg_udf.custmer_code = r.v_customer_code " & _
                        " WHERE r.d_mis_date >  TO_DATE ( '" & last_trn_date & "', 'DD/MM/YYYY') " & _
                        "order by dat_txn"

                        data_table = get_data_from_oracle(oracle_Connection_String, sql, data_table_name)
                    End If

                    If data_table IsNot Nothing Then
                        upload_from_oracle_to_sql(sql_connection_string, data_table, sql_table_name, False)
                    End If
                Next
            End If 'command_string = "?"
        Catch ex As Exception
            'here we will recive the the throw error from the child sub like "prepare_and_send_email_oracle"
            write_error(error_file_name, ex.Message & vbCrLf & ex.StackTrace)
        Finally
            End
        End Try
    End Sub

End Class
