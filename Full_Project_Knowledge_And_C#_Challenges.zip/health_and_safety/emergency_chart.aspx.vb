﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class emergency_chart
    Inherits System.Web.UI.Page
    Dim url As String

    Dim data_set_various As DataSet
    Dim data_row_various As DataRow
    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    'various
    Dim array(0) As String
    Dim command_field As CommandField
    Dim link_field As HyperLinkField

    Dim sql, data_table_name As String

    Protected Sub GridView_emergency_chart_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView_emergency_chart.PageIndexChanging
        GridView_emergency_chart.PageIndex = e.NewPageIndex
        'here i should refill the data set again
        If Session("Group_RecordID") = 1 Or Session("Group_RecordID") = 2 Then 'maker or checker
            Call fill_grid_view()
        ElseIf Session("Group_RecordID") = 3 Then 'cres
            If ddl_branches.SelectedIndex = 0 Then 'also we can say  ddl_branches.selecteditem.value = -1
                Call fill_grid_view(2)
            Else
                Call fill_grid_view(3)
            End If
        End If

    End Sub

    Protected Sub GridView_emergency_chart_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView_emergency_chart.RowCommand


        Dim index As Integer = Convert.ToInt32(e.CommandArgument)

        Dim result_of_function As Boolean

        Session("emergency_chart_RecordID") = GridView_emergency_chart.Rows(index).Cells(0).Text

        If e.CommandName = "Delete" Then
            result_of_function = customer_information_class_object.fn_delete_record_from_grid_view(Session("connection_string"), "stp_delete_record", "emergency_chart_table", Session("emergency_chart_RecordID"))

            If result_of_function = True Then
                lbl_result.Text = ("<h4><font color = 'green'> :) The Record Has Been Deleted Successfully :)</font></h4>")
            Else
                lbl_result.Text = ("<h4><font color = 'red'> :) There Is Error Happened During The Deletion Process <br>The Record Has Not Been Deleted :(</font></h4>")
            End If


        End If

        If e.CommandName = "Authorize" Then
            sql = "update emergency_chart_table set authorized = 2 where RecordID = " & Session("emergency_chart_RecordID")
            Call customer_information_class_object.s_update_status(Session("connection_string"), sql)
            Call fill_grid_view()
        End If

    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button

            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))

                If Session("Group_RecordID") = 2 Then 'checker
                    GridView_emergency_chart.Columns(12).Visible = True
                    GridView_emergency_chart.Columns(11).Visible = False
                    GridView_emergency_chart.Columns(10).Visible = False
                    Call fill_grid_view()

                ElseIf Session("Group_RecordID") = 3 Then  'cres
                    ddl_branches.Visible = True
                    Call fill_all_drop_down_list_boxes()
                    GridView_emergency_chart.Columns(12).Visible = False
                    GridView_emergency_chart.Columns(11).Visible = False
                    GridView_emergency_chart.Columns(10).Visible = False
                    Call fill_grid_view(2)

                ElseIf Session("Group_RecordID") = 1 Then 'maker
                    Call fill_grid_view()
                End If

                'i moved the below statements in fill_grid_view()
                'If data_set_various.Tables(data_table_name).Rows.Count = 0 Then
                '    lbl_result.Visible = True
                '    lbl_result.Text = "No Data Found !!"
                'End If

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub

    Protected Sub GridView_emergency_chart_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridView_emergency_chart.RowEditing
        'note when press new link in gridview the querystring count = 0 because 
        Session("process") = 2
        url = System.Configuration.ConfigurationManager.AppSettings("url_add_update_emergency_chart") ' "~/add_update_emergency_chart.aspx?"
        Response.Redirect(url & "RecordID=" & GridView_emergency_chart.Rows(e.NewEditIndex).Cells(0).Text)
    End Sub

    Protected Sub GridView_emergency_chart_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridView_emergency_chart.SelectedIndexChanging
        url = System.Configuration.ConfigurationManager.AppSettings("url_emergency_chart_details") '"~/emergency_chart_details.aspx?"
        Response.Redirect(url & "RecordID=" & GridView_emergency_chart.Rows(e.NewSelectedIndex).Cells(0).Text)
    End Sub

    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub


    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub
    Public Sub fill_grid_view(Optional ByVal s_sql_types As Integer = 100) '100 means all for maker and checker
        If s_sql_types = 2 Then 'log in as cres and see all branches
            sql = "select * from emergency_chart_new_view where authorized = 2 order by date desc"
        ElseIf s_sql_types = 3 Then ' log in as cres and see specific branch
            sql = "select * from emergency_chart_new_view where authorized = 2 and fk_branch_RecordID = " & Session("branch_RecordID") & " order by date desc"

        Else 'all records during the load or log in as maker or checker based on specific branch 
            sql = "select * from emergency_chart_new_view where  fk_branch_RecordID = " & Session("branch_RecordID") & " order by date desc"
        End If
        data_table_name = "emergency_chart_maker_table"

        data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, data_table_name)
        If data_set_various IsNot Nothing Then
            GridView_emergency_chart.DataSource = data_set_various.Tables(data_table_name)
            GridView_emergency_chart.DataBind()
        Else
            lbl_result.Visible = True
            lbl_result.Text = "No Data Found !!"
        End If
    End Sub

    Protected Sub GridView_emergency_chart_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView_emergency_chart.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(8).Text = 2 Then
                Dim c As Button = e.Row.FindControl("cmd_authorize")
                c.Enabled = False
            End If
        End If

    End Sub

    Public Sub fill_all_drop_down_list_boxes()

        sql = "SELECT RecordID , name FROM TblBranches"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_branches, "RecordID", "name")
    End Sub

    Protected Sub ddl_branches_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_branches.SelectedIndexChanged
        If ddl_branches.SelectedIndex = 0 Then 'also we can say  ddl_branches.selecteditem.value = -1
            Call fill_grid_view(2)

        Else
            Session("branch_RecordID") = ddl_branches.SelectedItem.Value
            Call fill_grid_view(3)

        End If
    End Sub
End Class
