Imports Microsoft.VisualBasic
Imports System.Diagnostics
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.IO


Public Class customer_information_class
    
    
    Public Function fn_hse_checklist_header_add_update_record(ByVal f_connection_string As String, ByVal f_fk_branch_RecordID As Integer, ByVal f_hse_inspector As String, ByVal f_emergency_manager As String, ByVal f_branch_head_count As Integer, ByVal f_no_fire_fighting_trainees As Integer, ByVal f_no_of_aid_trainees As Integer, ByVal f_process As Integer, ByVal f_fk_user_RecordID As Integer, Optional ByVal f_record_id As Integer = 0) As Integer
        Dim var_record_id As Integer
        Using connection_object As New SqlConnection(f_connection_string)
            connection_object.Open()
            Using general_command As New SqlCommand("stp_add_update_hse_header", connection_object)
                general_command.CommandType = CommandType.StoredProcedure
                general_command.Parameters.Add("@fk_branch_RecordID", SqlDbType.Int, Nothing, "fk_branch_RecordID").Value = HttpContext.Current.Session("branch_RecordID")
                general_command.Parameters.Add("@hse_inspector", SqlDbType.NVarChar, 500, "hse_inspector").Value = f_hse_inspector
                general_command.Parameters.Add("@emergency_manager", SqlDbType.NVarChar, 500, "emergency_manager").Value = f_emergency_manager
                general_command.Parameters.Add("@branch_head_count", SqlDbType.Int, Nothing, "branch_head_count").Value = f_branch_head_count
                general_command.Parameters.Add("@no_fire_fighting_trainees", SqlDbType.Int, Nothing, "no_fire_fighting_trainees").Value = f_no_fire_fighting_trainees
                general_command.Parameters.Add("@no_of_aid_trainees", SqlDbType.Int, Nothing, "no_of_aid_trainees").Value = f_no_of_aid_trainees
                general_command.Parameters.Add("@fk_user_RecordID", SqlDbType.Int, Nothing, "fk_user_RecordID").Value = HttpContext.Current.Session("user_RecordID")

                general_command.Parameters.Add("@process", SqlDbType.Int).Value = f_process

                If f_process = 1 Then
                    general_command.Parameters.Add("@var_record_id", SqlDbType.Int).Direction = ParameterDirection.ReturnValue
                    general_command.ExecuteNonQuery()
                    var_record_id = general_command.Parameters.Item("@var_record_id").Value
                    'note that the parameter in sp may be also declared variable like this case(DECLARE @var_record_id INT) and we deal with it in vb like the normal parameters which located after the create procedure (....@file_name nvarchar(50)..)
                    'i stop the below stament and will use the seesion direct in the code of the page
                    'HttpContext.Current.Session("var_record_id") = var_record_id   'general_command.Parameters.Item("@var_record_id").Value
                    Return var_record_id  'insert

                ElseIf f_process = 2 Then
                    general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = f_record_id
                    Return general_command.ExecuteNonQuery() 'update 'return the number of row affected
                End If
            End Using
        End Using
    End Function
    Public Function fn_Fire_Drill_add_update_record(ByVal f_connection_string As String, ByVal f_fk_branch_RecordID As Integer, ByVal f_control_collection As Collection, ByVal f_fk_user_RecordID As Integer, ByVal f_process As Integer, Optional ByVal f_record_id As Integer = 0) As Integer
        Dim var_record_id As Integer
        Using connection_object As New SqlConnection(f_connection_string)
            connection_object.Open()
            Using general_command As New SqlCommand("stp_add_update_Fire_Drill", connection_object)
                general_command.CommandType = CommandType.StoredProcedure
                general_command.Parameters.Add("@fk_branch_RecordID", SqlDbType.Int, Nothing, "branch_RecordID").Value = f_fk_branch_RecordID
                general_command.Parameters.Add("@evacuation_duration", SqlDbType.NVarChar, 500, "evacuation_duration").Value = f_control_collection.Item("txt_evacuation_duration").Text
                general_command.Parameters.Add("@observation", SqlDbType.NVarChar, 500, "observation").Value = f_control_collection("txt_observation").Text

                general_command.Parameters.Add("@emergency_manager_red_hat", SqlDbType.Bit, Nothing, "emergency_manager_red_hat").Value = f_control_collection("CheckBox1").Checked
                general_command.Parameters.Add("@evacuation_manager", SqlDbType.Bit, Nothing, "evacuation_manager").Value = f_control_collection("CheckBox2").Checked
                general_command.Parameters.Add("@first_aider", SqlDbType.Bit, Nothing, "first_aider").Value = f_control_collection("CheckBox3").Checked
                general_command.Parameters.Add("@fire_fighters", SqlDbType.Bit, Nothing, "fire_fighters").Value = f_control_collection("CheckBox4").Checked
                general_command.Parameters.Add("@evacuation_monitor", SqlDbType.Bit, Nothing, "evacuation_monitor").Value = f_control_collection("CheckBox5").Checked

                general_command.Parameters.Add("@reason_of_evacuation", SqlDbType.NVarChar, 500, "reason_of_evacuation").Value = f_control_collection("txt_reason_of_evacuation").Text
                general_command.Parameters.Add("@comment", SqlDbType.NVarChar, 4000, "comment").Value = f_control_collection("txt_comment").Text
                general_command.Parameters.Add("@branch_manager_name", SqlDbType.NVarChar, 500, "branch_manager_name").Value = f_control_collection("txt_branch_manager_name").Text
                general_command.Parameters.Add("@fk_user_RecordID", SqlDbType.Int, Nothing, "fk_user_RecordID").Value = HttpContext.Current.Session("user_RecordID")

                general_command.Parameters.Add("@process", SqlDbType.Int).Value = f_process

                If f_process = 1 Then
                    general_command.Parameters.Add("@var_record_id", SqlDbType.Int).Direction = ParameterDirection.ReturnValue
                    general_command.ExecuteNonQuery()
                    var_record_id = general_command.Parameters.Item("@var_record_id").Value
                    'note that the parameter in sp may be also declared variable like this case(DECLARE @var_record_id INT) and we deal with it in vb like the normal parameters which located after the create procedure (....@file_name nvarchar(50)..)
                    'i stop the below stament and will use the seesion direct in the code of the page
                    'HttpContext.Current.Session("var_record_id") = var_record_id   'general_command.Parameters.Item("@var_record_id").Value
                    Return var_record_id  'insert

                ElseIf f_process = 2 Then
                    general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = f_record_id
                    Return general_command.ExecuteNonQuery() 'update 'return the number of row affected
                End If
            End Using
        End Using
    End Function
    Public Function fn_cres_branch_data_add_update_record(ByVal f_connection_string As String, ByVal f_fk_branch_RecordID As Integer, ByVal f_control_collection As Collection, ByVal f_folder_files As String, ByVal f_fk_user_RecordID As Integer, ByVal f_process As Integer, Optional ByVal f_record_id As Integer = 0) As Integer
        Dim var_record_id As Integer

        Using connection_object As New SqlConnection(f_connection_string)
            connection_object.Open()
            Using general_command As New SqlCommand("stp_add_update_branch_data_system", connection_object)
                general_command.CommandType = CommandType.StoredProcedure
                general_command.Parameters.Add("@fk_branch_RecordID", SqlDbType.Int, Nothing, "branch_RecordID").Value = f_fk_branch_RecordID
                general_command.Parameters.Add("@address", SqlDbType.NVarChar, 500, "address").Value = f_control_collection.Item("txt_address").Text
                general_command.Parameters.Add("@area", SqlDbType.NVarChar, 500, "area").Value = f_control_collection("txt_area").Text

                general_command.Parameters.Add("@no_of_floor", SqlDbType.Int, Nothing, "no_of_floor").Value = f_control_collection("txt_no_of_floor").Text
                general_command.Parameters.Add("@no_of_first_aid_boxes", SqlDbType.Int, Nothing, "no_of_first_aid_boxes").Value = f_control_collection("txt_no_of_first_aid_boxes").Text

                general_command.Parameters.Add("@area_of_each_month", SqlDbType.Int, Nothing, "area_of_each_month").Value = f_control_collection("txt_area_of_each_month").Text
                general_command.Parameters.Add("@no_of_head_count", SqlDbType.Int, Nothing, "no_of_head_count").Value = f_control_collection("txt_no_of_head_count").Text

                general_command.Parameters.Add("@no_of_co2_automatic_extinguishers", SqlDbType.Int, Nothing, "no_of_co2_automatic_extinguishers").Value = f_control_collection("txt_no_of_co2_automatic_extinguishers").Text
                general_command.Parameters.Add("@no_of_dry_powder_extinguishers", SqlDbType.Int, Nothing, "no_of_dry_powder_extinguishers").Value = f_control_collection("txt_no_of_dry_powder_extinguishers").Text
                general_command.Parameters.Add("@no_of_fire_panels", SqlDbType.Int, Nothing, "no_of_fire_panels").Value = f_control_collection("txt_no_of_fire_panels").Text
                general_command.Parameters.Add("@no_of_smoke_detectors", SqlDbType.Int, Nothing, "no_of_smoke_detectors").Value = f_control_collection("txt_no_of_smoke_detectors").Text


                general_command.Parameters.Add("@no_of_exit_doors", SqlDbType.Int, Nothing, "no_of_exit_doors").Value = f_control_collection("txt_no_of_exit_doors").Text
                general_command.Parameters.Add("@no_of_co2_extinguisher", SqlDbType.NVarChar, 50, "no_of_co2_extinguisher").Value = f_control_collection("txt_no_of_co2_extinguisher").Text
                general_command.Parameters.Add("@no_of_powder_extinguisher", SqlDbType.NVarChar, 50, "no_of_powder_extinguisher").Value = f_control_collection("txt_no_of_powder_extinguisher").Text

                general_command.Parameters.Add("@no_of_fm2oo_extinguisher", SqlDbType.NVarChar, 500, "no_of_fm2oo_extinguisher").Value = f_control_collection("txt_no_of_fm2oo_extinguisher").Text
                general_command.Parameters.Add("@no_of_hosoreel_boxes", SqlDbType.NVarChar, 500, "no_of_hosoreel_boxes").Value = f_control_collection("txt_no_of_hosoreel_boxes").Text

                general_command.Parameters.Add("@generator", SqlDbType.Bit, Nothing, "generator").Value = f_control_collection("chk_generator").checked
                general_command.Parameters.Add("@generator_serial_number", SqlDbType.NVarChar, 500, "generator_serial_number").Value = f_control_collection("txt_generator_serial_number").Text
                general_command.Parameters.Add("@generator_barcode", SqlDbType.NVarChar, 500, "generator_barcode").Value = f_control_collection("txt_generator_barcode").Text

                general_command.Parameters.Add("@ups", SqlDbType.Bit, Nothing, "ups").Value = f_control_collection("chk_ups").checked
                general_command.Parameters.Add("@ups_serial_number", SqlDbType.NVarChar, 500, "ups_serial_number").Value = f_control_collection("txt_ups_serial_number").Text
                general_command.Parameters.Add("@ups_barcode", SqlDbType.NVarChar, 500, "ups_barcode").Value = f_control_collection("txt_ups_barcode").Text


                general_command.Parameters.Add("@last_civil_defence_visit", SqlDbType.DateTime, Nothing, "last_civil_defence_visit").Value = HttpContext.Current.Session("last_civil_defence_visit")
                general_command.Parameters.Add("@no_of_heat_detectors", SqlDbType.Int, Nothing, "no_of_heat_detectors").Value = f_control_collection("txt_no_of_heat_detectors").Text
                general_command.Parameters.Add("@electricity_panel_no", SqlDbType.NVarChar, 500, "electricity_panel_no").Value = f_control_collection("txt_electricity_panel_no").Text

                general_command.Parameters.Add("@no_of_fire_break_glass", SqlDbType.Int, Nothing, "no_of_fire_break_glass").Value = f_control_collection("txt_no_of_fire_break_glass").Text
                general_command.Parameters.Add("@no_of_fire_alarm_sirens", SqlDbType.Int, Nothing, "no_of_fire_alarm_sirens").Value = f_control_collection("txt_no_of_fire_alarm_sirens").Text

                general_command.Parameters.Add("@folder_files", SqlDbType.NVarChar, 500, "folder_files").Value = f_folder_files

                general_command.Parameters.Add("@fk_user_RecordID", SqlDbType.Int, Nothing, "fk_user_RecordID").Value = f_fk_user_RecordID
                general_command.Parameters.Add("@process", SqlDbType.Int).Value = f_process

                If f_process = 1 Then
                    general_command.Parameters.Add("@var_record_id", SqlDbType.Int).Direction = ParameterDirection.ReturnValue
                    general_command.ExecuteNonQuery()
                    var_record_id = general_command.Parameters.Item("@var_record_id").Value
                    'note that the parameter in sp may be also declared variable like this case(DECLARE @var_record_id INT) and we deal with it in vb like the normal parameters which located after the create procedure (....@file_name nvarchar(50)..)
                    'i stop the below stament and will use the seesion direct in the code of the page
                    'HttpContext.Current.Session("var_record_id") = var_record_id   'general_command.Parameters.Item("@var_record_id").Value
                    Return var_record_id  'insert

                ElseIf f_process = 2 Then
                    general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = f_record_id
                    Return general_command.ExecuteNonQuery() 'update 'return the number of row affected
                End If
            End Using
        End Using
    End Function
    Public Function fn_add_update_emergency_chart(ByVal f_connection_string As String, ByVal f_fk_branch_RecordID As Integer, ByVal f_control_collection As Collection, ByVal f_fk_user_RecordID As Integer, ByVal f_process As Integer, Optional ByVal f_record_id As Integer = 0) As Integer
        Dim var_record_id As Integer

        Using connection_object As New SqlConnection(f_connection_string)
            connection_object.Open()
            Using general_command As New SqlCommand("stp_add_update_emergency_chart", connection_object)
                general_command.CommandType = CommandType.StoredProcedure
                general_command.Parameters.Add("@fk_branch_RecordID", SqlDbType.Int, Nothing, "branch_RecordID").Value = f_fk_branch_RecordID
                general_command.Parameters.Add("@account_number", SqlDbType.NVarChar, 50, "account_number").Value = f_control_collection.Item("txt_account_number").Text
                general_command.Parameters.Add("@name", SqlDbType.NVarChar, 500, "name").Value = f_control_collection("txt_name").Text
                general_command.Parameters.Add("@ext", SqlDbType.NVarChar, 50, "ext").Value = f_control_collection("txt_ext").Text
                general_command.Parameters.Add("@fk_hat_colour", SqlDbType.Int, Nothing, "fk_hat_colour").Value = f_control_collection("ddl_hat_type").SelectedIndex

                general_command.Parameters.Add("@fk_user_RecordID", SqlDbType.Int, Nothing, "fk_user_RecordID").Value = f_fk_user_RecordID
                general_command.Parameters.Add("@process", SqlDbType.Int).Value = f_process

                If f_process = 1 Then
                    general_command.Parameters.Add("@var_record_id", SqlDbType.Int).Direction = ParameterDirection.ReturnValue
                    general_command.ExecuteNonQuery()
                    var_record_id = general_command.Parameters.Item("@var_record_id").Value
                    'note that the parameter in sp may be also declared variable like this case(DECLARE @var_record_id INT) and we deal with it in vb like the normal parameters which located after the create procedure (....@file_name nvarchar(50)..)
                    'i stop the below stament and will use the seesion direct in the code of the page
                    'HttpContext.Current.Session("var_record_id") = var_record_id   'general_command.Parameters.Item("@var_record_id").Value
                    Return var_record_id  'insert

                ElseIf f_process = 2 Then
                    general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = f_record_id
                    Return general_command.ExecuteNonQuery() 'update 'return the number of row affected
                End If
            End Using
        End Using
    End Function
    Public Function fn_add_update_evacuation(ByVal f_connection_string As String, ByVal f_fk_branch_RecordID As Integer, ByVal f_control_collection As Collection, ByVal f_fk_user_RecordID As Integer, ByVal f_process As Integer, Optional ByVal f_record_id As Integer = 0) As Integer
        Dim var_record_id As Integer

        Using connection_object As New SqlConnection(f_connection_string)
            connection_object.Open()
            Using general_command As New SqlCommand("stp_add_update_evacuation", connection_object)
                general_command.CommandType = CommandType.StoredProcedure

                general_command.Parameters.Add("@fk_branch_RecordID", SqlDbType.Int, Nothing, "branch_RecordID").Value = f_fk_branch_RecordID

                'A
                general_command.Parameters.Add("@a_address", SqlDbType.NVarChar, 500, "a_address").Value = f_control_collection.Item("txt_a_address").Text
                general_command.Parameters.Add("@a_floors_number", SqlDbType.NVarChar, 50, "a_floors_number").Value = f_control_collection("txt_a_floors_number").Text
                general_command.Parameters.Add("@a_emoloyees_number", SqlDbType.NVarChar, 50, "a_emoloyees_number").Value = f_control_collection("txt_a_emoloyees_number").Text
                general_command.Parameters.Add("@a_designated_assemply_point", SqlDbType.NVarChar, 500, "a_designated_assemply_point").Value = f_control_collection.Item("txt_a_designated_assemply_point").Text
                general_command.Parameters.Add("@a_alternative_assemply_point", SqlDbType.NVarChar, 50, "a_alternative_assemply_point").Value = f_control_collection("txt_a_alternative_assemply_point").Text
                general_command.Parameters.Add("@a_elevator_available", SqlDbType.Bit, Nothing, "a_elevator_available").Value = f_control_collection("rbl_a_elevator_available").items(0).selected
                general_command.Parameters.Add("@a_usage_elevator_emergency", SqlDbType.Bit, Nothing, "a_usage_elevator_emergency").Value = f_control_collection("rbl_a_usage_elevator_emergency").items(0).selected

                'B
                general_command.Parameters.Add("@b_evacuation_date", SqlDbType.DateTime, Nothing, "b_evacuation_date").Value = f_control_collection("Cal_evacuation_date").SelectedDate
                general_command.Parameters.Add("@b_emergency_situation", SqlDbType.Int, Nothing, "b_emergency_situation").Value = f_control_collection("ddl_b_emergency_situation").SelectedIndex
                general_command.Parameters.Add("@b_other", SqlDbType.NVarChar, 50, "b_other").Value = f_control_collection("txt_b_other").Text
                general_command.Parameters.Add("@b_evacuation_duration", SqlDbType.NVarChar, 50, "b_evacuation_duration").Value = f_control_collection("txt_b_evacuation_duration").Text
                general_command.Parameters.Add("@b_evacuation_panic", SqlDbType.Bit, Nothing, "b_evacuation_panic").Value = f_control_collection("rbl_b_evacuation_panic").items(0).selected
                general_command.Parameters.Add("@b_disability_person", SqlDbType.Bit, Nothing, "b_disability_person").Value = f_control_collection("rbl_b_disability_person").items(0).selected
                general_command.Parameters.Add("@b_assembly_area", SqlDbType.Bit, Nothing, "b_assembly_area").Value = f_control_collection("rbl_b_assembly_area").items(0).selected
                general_command.Parameters.Add("@b_attendees_area", SqlDbType.Bit, Nothing, "b_attendees_area").Value = f_control_collection("rbl_b_attendees_area").items(0).selected

                'C
                general_command.Parameters.Add("@c_emergency_manager_name", SqlDbType.NVarChar, 500, "c_emergency_manager_name").Value = f_control_collection("txt_c_emergency_manager_name").Text
                general_command.Parameters.Add("@c_emergency_manager_deputy", SqlDbType.NVarChar, 500, "c_emergency_manager_deputy").Value = f_control_collection("txt_c_emergency_manager_deputy").Text
                general_command.Parameters.Add("@c_ensure_evacuation", SqlDbType.Bit, Nothing, "c_ensure_evacuation").Value = f_control_collection("rbl_c_ensure_evacuation").items(0).selected
                general_command.Parameters.Add("@c_coloured_hats", SqlDbType.Bit, Nothing, "c_coloured_hats").Value = f_control_collection("rbl_c_coloured_hats").items(0).selected
                general_command.Parameters.Add("@c_ohs_team", SqlDbType.Bit, Nothing, "c_ohs_team").Value = f_control_collection("rbl_c_ohs_team").items(0).selected
                general_command.Parameters.Add("@c_evacuation_up_to_date", SqlDbType.Bit, Nothing, "c_evacuation_up_to_date").Value = f_control_collection("rbl_c_evacuation_up_to_date").items(0).selected

                'D
                general_command.Parameters.Add("@d_evacuation_alarm", SqlDbType.Bit, Nothing, "d_evacuation_alarm").Value = f_control_collection("rbl_d_evacuation_alarm").items(0).selected
                general_command.Parameters.Add("@d_clear_instruction", SqlDbType.Bit, Nothing, "d_clear_instruction").Value = f_control_collection("rbl_d_clear_instruction").items(0).selected
                general_command.Parameters.Add("@d_card_access_door", SqlDbType.Bit, Nothing, "d_card_access_door").Value = f_control_collection("rbl_d_card_access_door").items(0).selected
                general_command.Parameters.Add("@d_emergency_exit_unobstructed", SqlDbType.Bit, Nothing, "d_emergency_exit_unobstructed").Value = f_control_collection("rbl_d_emergency_exit_unobstructed").items(0).selected
                general_command.Parameters.Add("@d_signs_visible", SqlDbType.Bit, Nothing, "d_signs_visible").Value = f_control_collection("rbl_d_signs_visible").items(0).selected
                general_command.Parameters.Add("@d_security_perform", SqlDbType.Bit, Nothing, "d_security_perform").Value = f_control_collection("rbl_d_security_perform").items(0).selected

                'E
                general_command.Parameters.Add("@e_bulding_service", SqlDbType.Bit, Nothing, "e_bulding_service").Value = f_control_collection("rbl_e_bulding_service").items(0).selected
                general_command.Parameters.Add("@e_maintainance", SqlDbType.Bit, Nothing, "e_maintainance").Value = f_control_collection("rbl_e_maintainance").items(0).selected
                general_command.Parameters.Add("@e_bsis", SqlDbType.Bit, Nothing, "e_bsis").Value = f_control_collection("rbl_e_bsis").items(0).selected
                general_command.Parameters.Add("@e_emergency_service", SqlDbType.Bit, Nothing, "e_emergency_service").Value = f_control_collection("rbl_e_emergency_service").items(0).selected
                general_command.Parameters.Add("@e_fire_brigade", SqlDbType.Bit, Nothing, "e_fire_brigade").Value = f_control_collection("rbl_e_fire_brigade").items(0).selected
                general_command.Parameters.Add("@e_ambulance", SqlDbType.Bit, Nothing, "e_ambulance").Value = f_control_collection("rbl_e_ambulance").items(0).selected
                general_command.Parameters.Add("@e_police", SqlDbType.Bit, Nothing, "e_police").Value = f_control_collection("rbl_e_police").items(0).selected

                '-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                general_command.Parameters.Add("@emergency_manager_name", SqlDbType.NVarChar, 500, "emergency_manager_name").Value = f_control_collection("txt_emergency_manager_name").Text
                general_command.Parameters.Add("@emergency_manager_signature", SqlDbType.NVarChar, 500, "emergency_manager_signature").Value = f_control_collection("txt_emergency_manager_signature").Text




                general_command.Parameters.Add("@fk_user_RecordID", SqlDbType.Int, Nothing, "fk_user_RecordID").Value = f_fk_user_RecordID
                general_command.Parameters.Add("@process", SqlDbType.Int).Value = f_process

                If f_process = 1 Then
                    general_command.Parameters.Add("@var_record_id", SqlDbType.Int).Direction = ParameterDirection.ReturnValue
                    general_command.ExecuteNonQuery()
                    var_record_id = general_command.Parameters.Item("@var_record_id").Value
                    'note that the parameter in sp may be also declared variable like this case(DECLARE @var_record_id INT) and we deal with it in vb like the normal parameters which located after the create procedure (....@file_name nvarchar(50)..)
                    'i stop the below stament and will use the seesion direct in the code of the page
                    'HttpContext.Current.Session("var_record_id") = var_record_id   'general_command.Parameters.Item("@var_record_id").Value
                    Return var_record_id  'insert

                ElseIf f_process = 2 Then
                    general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = f_record_id
                    Return general_command.ExecuteNonQuery() 'update 'return the number of row affected
                End If
            End Using
        End Using
    End Function
    Public Function fn_add_update_cleaning_evaluation(ByVal f_connection_string As String, ByVal f_fk_branch_RecordID As Integer, ByVal f_control_collection As Collection, ByVal f_fk_user_RecordID As Integer, ByVal f_process As Integer, Optional ByVal f_record_id As Integer = 0) As Integer
        Dim var_record_id As Integer

        Using connection_object As New SqlConnection(f_connection_string)
            connection_object.Open()
            Using general_command As New SqlCommand("stp_add_update_cleaning_evaluation", connection_object)
                general_command.CommandType = CommandType.StoredProcedure
                general_command.Parameters.Add("@fk_branch_RecordID", SqlDbType.Int, Nothing, "branch_RecordID").Value = f_fk_branch_RecordID
                general_command.Parameters.Add("@facade_cleaning", SqlDbType.Int, Nothing, "facade_cleaning").Value = f_control_collection("ddl_facade_cleaning").SelectedIndex
                general_command.Parameters.Add("@carpet_shampooing", SqlDbType.Int, Nothing, "carpet_shampooing").Value = f_control_collection("ddl_carpet_shampooing").SelectedIndex
                general_command.Parameters.Add("@furniture", SqlDbType.Int, Nothing, "furniture").Value = f_control_collection("ddl_furniture").SelectedIndex
                general_command.Parameters.Add("@pest_control", SqlDbType.Int, Nothing, "pest_control").Value = f_control_collection("ddl_pest_control").SelectedIndex
                general_command.Parameters.Add("@material_availability", SqlDbType.Int, Nothing, "material_availability").Value = f_control_collection("ddl_material_availability").SelectedIndex
                general_command.Parameters.Add("@cleaning_walls_ceiling", SqlDbType.Int, Nothing, "cleaning_walls_ceiling").Value = f_control_collection("ddl_cleaning_walls_ceiling").SelectedIndex
                general_command.Parameters.Add("@cleaner_uniform", SqlDbType.Int, Nothing, "cleaner_uniform").Value = f_control_collection("ddl_cleaner_uniform").SelectedIndex
                general_command.Parameters.Add("@cleaner_attitude", SqlDbType.Int, Nothing, "cleaner_attitude").Value = f_control_collection("ddl_cleaner_attitude").SelectedIndex
                general_command.Parameters.Add("@final_evaluation", SqlDbType.Int, Nothing, "final_evaluation").Value = f_control_collection("ddl_final_evaluation").SelectedIndex

                general_command.Parameters.Add("@comment", SqlDbType.NVarChar, 4000, "comment").Value = f_control_collection.Item("txt_comment").Text

                general_command.Parameters.Add("@fk_user_RecordID", SqlDbType.Int, Nothing, "fk_user_RecordID").Value = f_fk_user_RecordID
                general_command.Parameters.Add("@process", SqlDbType.Int).Value = f_process

                If f_process = 1 Then
                    general_command.Parameters.Add("@var_record_id", SqlDbType.Int).Direction = ParameterDirection.ReturnValue
                    general_command.ExecuteNonQuery()
                    var_record_id = general_command.Parameters.Item("@var_record_id").Value
                    'note that the parameter in sp may be also declared variable like this case(DECLARE @var_record_id INT) and we deal with it in vb like the normal parameters which located after the create procedure (....@file_name nvarchar(50)..)
                    'i stop the below stament and will use the seesion direct in the code of the page
                    'HttpContext.Current.Session("var_record_id") = var_record_id   'general_command.Parameters.Item("@var_record_id").Value
                    Return var_record_id  'insert

                ElseIf f_process = 2 Then
                    general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = f_record_id
                    Return general_command.ExecuteNonQuery() 'update 'return the number of row affected
                End If
            End Using
        End Using
    End Function
    Public Sub s_update_status(ByVal s_connection_string As String, ByVal s_sql As String)

        Using connection_object As New SqlConnection(s_connection_string)
            connection_object.Open()
            Using general_command As New SqlCommand(s_sql, connection_object)
                general_command.CommandType = CommandType.Text
                general_command.ExecuteNonQuery()
            End Using

        End Using
    End Sub


    Public Function fn_answer_add_update(ByVal f_connection_string As String, ByVal f_data_row As DataRow, ByVal f_process As Integer, ByVal f_label As Label, Optional ByVal f_record_id As Integer = 0) As Integer
        Dim var_record_id As Integer
        Try
            Using connection_object As New SqlConnection(f_connection_string)
                Using general_command As New SqlCommand("stp_answer_add_update", connection_object)
                    connection_object.Open()
                    general_command.CommandType = CommandType.StoredProcedure
                    general_command.Parameters.Add("@fk_check_list_RecordID", SqlDbType.Int, Nothing, "fk_check_list_RecordID").Value = f_data_row("fk_check_list_RecordID")
                    general_command.Parameters.Add("@fk_check_list_q_RecordID", SqlDbType.Int, Nothing, "fk_check_list_q_RecordID").Value = f_data_row("fk_check_list_q_RecordID")
                    general_command.Parameters.Add("@answer", SqlDbType.Bit, Nothing, "answer").Value = f_data_row("answer")
                    general_command.Parameters.Add("@comment", SqlDbType.NVarChar, 4000, "comment").Value = f_data_row("comment")
                    general_command.Parameters.Add("@process", SqlDbType.Int).Value = f_process
                    If f_process = 1 Then

                        general_command.Parameters.Add("@var_record_id", SqlDbType.Int).Direction = ParameterDirection.ReturnValue
                        general_command.ExecuteNonQuery()
                        var_record_id = general_command.Parameters.Item("@var_record_id").Value
                        'note that the parameter in sp may be also declared variable like this case(DECLARE @var_record_id INT) and we deal with it in vb like the normal parameters which located after the create procedure (....@file_name nvarchar(50)..)
                        'i stop the below stament and will use the seesion direct in the code of the page
                        'HttpContext.Current.Session("var_record_id") = var_record_id   'general_command.Parameters.Item("@var_record_id").Value
                        Return var_record_id  'insert

                    ElseIf f_process = 2 Then
                        general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = f_record_id
                        Return general_command.ExecuteNonQuery() 'update 'return the number of row affected
                    End If


                End Using
            End Using
        Catch ex As Exception
            f_label.Text = ""
            f_label.Text = "<font color = 'red'>" & ex.Message & "</br>" & ex.StackTrace & "</br>There Is Error In DWH Happened During The Validation Process Please Reupdae The Collection Feedback Status Again </font> "
            Return -1
        End Try

    End Function
    Public Function fn_emergency_add_update(ByVal f_connection_string As String, ByVal f_data_row As DataRow, ByVal f_process As Integer, Optional ByVal f_record_id As Integer = 0) As Integer
        Dim var_record_id As Integer
        Using connection_object As New SqlConnection(f_connection_string)
            Using general_command As New SqlCommand("stp_emergency_add_update", connection_object)
                connection_object.Open()
                general_command.CommandType = CommandType.StoredProcedure
                general_command.Parameters.Add("@fk_check_list_RecordID", SqlDbType.Int, Nothing, "fk_check_list_RecordID").Value = f_data_row("fk_check_list_RecordID")

                general_command.Parameters.Add("@e_m_name", SqlDbType.NVarChar, 500, "e_m_name").Value = f_data_row("e_m_name")
                general_command.Parameters.Add("@e_m_account", SqlDbType.NVarChar, 50, "e_m_account").Value = f_data_row("e_m_account")
                general_command.Parameters.Add("@e_m_ext", SqlDbType.NVarChar, 10, "comment").Value = f_data_row("e_m_ext")

                general_command.Parameters.Add("@d_e_m_name", SqlDbType.NVarChar, 500, "d_e_m_name").Value = f_data_row("d_e_m_name")
                general_command.Parameters.Add("@d_e_m_account", SqlDbType.NVarChar, 50, "d_e_m_account").Value = f_data_row("d_e_m_account")
                general_command.Parameters.Add("@d_e_m_ext", SqlDbType.NVarChar, 10, "d_e_m_ext").Value = f_data_row("d_e_m_ext")

                general_command.Parameters.Add("@f_a_name", SqlDbType.NVarChar, 500, "f_a_name").Value = f_data_row("f_a_name")
                general_command.Parameters.Add("@f_a_account", SqlDbType.NVarChar, 50, "f_a_account").Value = f_data_row("f_a_account")
                general_command.Parameters.Add("@f_a_ext", SqlDbType.NVarChar, 10, "f_a_ext").Value = f_data_row("f_a_ext")

                general_command.Parameters.Add("@evac_m_name_1", SqlDbType.NVarChar, 500, "evac_m_name_1").Value = f_data_row("evac_m_name_1")
                general_command.Parameters.Add("@evac_m_account_1", SqlDbType.NVarChar, 50, "evac_m_account_1").Value = f_data_row("evac_m_account_1")
                general_command.Parameters.Add("@evac_m_ext_1", SqlDbType.NVarChar, 10, "evac_m_ext_1").Value = f_data_row("evac_m_ext_1")
                general_command.Parameters.Add("@evac_m_name_2", SqlDbType.NVarChar, 500, "evac_m_name_2").Value = f_data_row("evac_m_name_2")
                general_command.Parameters.Add("@evac_m_account_2", SqlDbType.NVarChar, 50, "evac_m_account_2").Value = f_data_row("evac_m_account_2")
                general_command.Parameters.Add("@evac_m_ext_2", SqlDbType.NVarChar, 10, "evac_m_ext_2").Value = f_data_row("evac_m_ext_2")

                general_command.Parameters.Add("@evac_monitor_name", SqlDbType.NVarChar, 500, "evac_monitor_name").Value = f_data_row("evac_monitor_name")
                general_command.Parameters.Add("@evac_monitor_account", SqlDbType.NVarChar, 50, "evac_monitor_account").Value = f_data_row("evac_monitor_account")
                general_command.Parameters.Add("@evac_monitor_ext", SqlDbType.NVarChar, 10, "evac_monitor_ext").Value = f_data_row("evac_monitor_ext")

                general_command.Parameters.Add("@f_f_name_1", SqlDbType.NVarChar, 500, "f_f_name_1").Value = f_data_row("f_f_name_1")
                general_command.Parameters.Add("@f_f_account_1", SqlDbType.NVarChar, 50, "f_f_account_1").Value = f_data_row("f_f_account_1")
                general_command.Parameters.Add("@f_f_ext_1", SqlDbType.NVarChar, 10, "f_f_ext_1").Value = f_data_row("f_f_ext_1")
                general_command.Parameters.Add("@f_f_name_2", SqlDbType.NVarChar, 500, "f_f_name_2").Value = f_data_row("f_f_name_2")
                general_command.Parameters.Add("@f_f_account_2", SqlDbType.NVarChar, 50, "f_f_account_2").Value = f_data_row("f_f_account_2")
                general_command.Parameters.Add("@f_f_ext_2", SqlDbType.NVarChar, 10, "f_f_ext_2").Value = f_data_row("f_f_ext_2")
                general_command.Parameters.Add("@f_f_name_3", SqlDbType.NVarChar, 500, "f_f_name_3").Value = f_data_row("f_f_name_3")
                general_command.Parameters.Add("@f_f_account_3", SqlDbType.NVarChar, 50, "f_f_account_3").Value = f_data_row("f_f_account_3")
                general_command.Parameters.Add("@f_f_ext_3", SqlDbType.NVarChar, 10, "f_f_ext_3").Value = f_data_row("f_f_ext_3")
                general_command.Parameters.Add("@f_f_name_4", SqlDbType.NVarChar, 500, "f_f_name_4").Value = f_data_row("f_f_name_4")
                general_command.Parameters.Add("@f_f_account_4", SqlDbType.NVarChar, 50, "f_f_account_4").Value = f_data_row("f_f_account_4")
                general_command.Parameters.Add("@f_f_ext_4", SqlDbType.NVarChar, 10, "f_f_ext_4").Value = f_data_row("f_f_ext_4")

                general_command.Parameters.Add("@process", SqlDbType.Int).Value = f_process
                If f_process = 1 Then

                    general_command.Parameters.Add("@var_record_id", SqlDbType.Int).Direction = ParameterDirection.ReturnValue
                    general_command.ExecuteNonQuery()
                    var_record_id = general_command.Parameters.Item("@var_record_id").Value
                    'note that the parameter in sp may be also declared variable like this case(DECLARE @var_record_id INT) and we deal with it in vb like the normal parameters which located after the create procedure (....@file_name nvarchar(50)..)
                    'i stop the below stament and will use the seesion direct in the code of the page
                    'HttpContext.Current.Session("var_record_id") = var_record_id   'general_command.Parameters.Item("@var_record_id").Value
                    Return var_record_id  'insert

                ElseIf f_process = 2 Then
                    general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = f_record_id
                    Return general_command.ExecuteNonQuery() 'update 'return the number of row affected
                End If
            End Using
        End Using
    End Function
    
    Public Function fn_check_list_q_a_information(ByVal f_connection_string As String) As DataTable
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable


        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand("stp_check_list_q_a_information", connection_object)
                general_command.CommandType = CommandType.StoredProcedure
                general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = HttpContext.Current.Session("hse_checklist_header_RecordID")
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, "check_list_q_a_information")
                general_data_table = general_data_set.Tables("check_list_q_a_information")

                If general_data_table.Rows.Count > 0 Then

                    Return general_data_table
                Else
                    Return Nothing
                End If
            End Using
        End Using

    End Function
    
    Public Function fn_question_information_select_one_record(ByVal f_connection_string As String, ByVal f_direction As Integer) As DataRow
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_row As DataRow 'if needed

        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand("stp_question_browzing", connection_object)
                general_command.CommandType = CommandType.StoredProcedure
                general_command.Parameters.Add("@direction", SqlDbType.Int).Value = f_direction
                general_command.Parameters.Add("@current_Record", SqlDbType.Int, Nothing, "RecordID").Value = HttpContext.Current.Session("question_RecordID")
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, "question_information_table")
                If general_data_set.Tables("question_information_table").Rows.Count > 0 Then
                    general_data_row = general_data_set.Tables("question_information_table").Rows(0)
                Else
                    general_data_row = Nothing
                End If
                Return general_data_row
            End Using
        End Using

    End Function
    Public Function fn_question_information_select_one_record(ByVal f_connection_string As String, ByVal f_sql As String) As DataRow 'overloading for this function
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_row As DataRow 'if needed

        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand(f_sql, connection_object)
                general_command.CommandType = CommandType.Text
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, "question_information_table")
                If general_data_set.Tables("question_information_table").Rows.Count > 0 Then
                    general_data_row = general_data_set.Tables("question_information_table").Rows(0)

                Else
                    general_data_row = Nothing
                End If
                Return general_data_row
            End Using
        End Using

    End Function
    Public Function fn_emergency_information_select_one_record(ByVal f_connection_string As String, ByVal f_sql As String) As DataRow 'overloading for this function
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_row As DataRow 'if needed

        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand(f_sql, connection_object)
                general_command.CommandType = CommandType.Text
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, "emergency_information_table")
                If general_data_set.Tables("emergency_information_table").Rows.Count > 0 Then
                    general_data_row = general_data_set.Tables("emergency_information_table").Rows(0)

                Else
                    general_data_row = Nothing
                End If
                Return general_data_row
            End Using
        End Using

    End Function
    Public Function fn_check_list_information_search(ByVal f_connection_string As String) As DataSet
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed

        'connection_object.Open() 'because i use using connection_object  i dont ned say "connection_object.Open() "
        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand("select * from hse_checklist_header_View where Branch_RecordID = " & HttpContext.Current.Session("branch_RecordID") & "order by hse_date desc", connection_object) 'authorized = 2 and ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                general_command.CommandType = CommandType.Text
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, "check_list_information_table")
                Return general_data_set
            End Using
        End Using
    End Function
    Public Function fn_get_data_for_grid_view(ByVal f_connection_string As String, ByVal f_sql As String, ByVal f_data_table_name As String) As DataSet
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed


        'connection_object.Open() 'because i use using connection_object  i dont ned say "connection_object.Open() "
        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand(f_sql, connection_object) ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                general_command.CommandType = CommandType.Text
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, f_data_table_name)
                Return general_data_set
            End Using
        End Using
    End Function


    Public Function fn_check_list_information_search(ByVal f_connection_string As String, ByVal f_sql As String) As DataSet
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed

        'connection_object.Open() 'because i use using connection_object  i dont ned say "connection_object.Open() "
        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand(f_sql, connection_object) ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                general_command.CommandType = CommandType.Text
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, "check_list_information_table")
                Return general_data_set
            End Using
        End Using
    End Function
    Public Function fn_search_data(ByVal f_connection_string As String, ByVal f_sql As String, ByVal f_data_table_name As String) As DataSet

        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed

        Try
            Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
                Using general_command As New SqlCommand(f_sql, connection_object) ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                    general_command.CommandType = CommandType.Text
                    Using general_data_adapter As New SqlDataAdapter(general_command)
                        general_data_adapter.SelectCommand = general_command
                        general_data_adapter.Fill(general_data_set, f_data_table_name)
                        general_data_table = general_data_set.Tables(f_data_table_name)

                        Return general_data_set
                        
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Return Nothing
        End Try

        
    End Function
    Public Function fn_select_one_record(ByVal f_connection_string As String, ByVal f_sql As String, ByVal f_data_table_name As String) As DataRow 'overloading for this function
        'Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_row As DataRow 'if needed

        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand(f_sql, connection_object)
                general_command.CommandType = CommandType.Text
                Using general_data_adapter As New SqlDataAdapter(general_command)
                    general_data_adapter.SelectCommand = general_command
                    general_data_adapter.Fill(general_data_set, f_data_table_name)
                    If general_data_set.Tables(f_data_table_name).Rows.Count > 0 Then
                        general_data_row = general_data_set.Tables(f_data_table_name).Rows(0)

                    Else
                        general_data_row = Nothing
                    End If
                    Return general_data_row
                End Using
            End Using
        End Using
    End Function

    Public Function fn_check_list_information_search(ByVal f_connection_string As String, ByVal f_status_check_list As Integer) As DataSet
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed
        Dim sql As String

        If f_status_check_list = 0 Then
            sql = " select * from hse_checklist_header_View where authorized = 1 and Branch_RecordID = " & HttpContext.Current.Session("branch_RecordID") & "order by hse_date desc"
        ElseIf f_status_check_list = 1 Then
            sql = " select * from hse_checklist_header_View where authorized = 2 and Branch_RecordID = " & HttpContext.Current.Session("branch_RecordID") & "order by hse_date desc"
        End If

        'connection_object.Open() 'because i use using connection_object  i dont ned say "connection_object.Open() "
        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand(sql, connection_object) ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                general_command.CommandType = CommandType.Text
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, "check_list_information_table")
                Return general_data_set
            End Using
        End Using
    End Function
    Public Function fn_fire_drill_information_search(ByVal f_connection_string As String, ByVal f_sql As String) As DataSet
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed

        'connection_object.Open() 'because i use using connection_object  i dont ned say "connection_object.Open() "
        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand(f_sql, connection_object) ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                general_command.CommandType = CommandType.Text
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, "fire_drill_information_table")
                Return general_data_set
            End Using
        End Using
    End Function

    Public Function fn_check_list_information_Delete(ByVal f_connection_string As String) As Boolean
        Try
            Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
                connection_object.Open()

                Using general_command As New SqlCommand("stp_check_list_delete", connection_object) 'here i write the name of stored procedure or the sql string in case if the command type property of the command object is text
                    general_command.CommandType = CommandType.StoredProcedure
                    general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = HttpContext.Current.Session("check_list_RecordID")
                    general_command.ExecuteNonQuery()
                End Using

            End Using
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    Public Function fn_delete_record_from_grid_view(ByVal f_connection_string As String, ByVal f_stp_name As String, ByVal f_table_name As String, ByVal f_record_id As Integer) As Boolean
        Try
            Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
                connection_object.Open()

                Using general_command As New SqlCommand(f_stp_name, connection_object) 'here i write the name of stored procedure or the sql string in case if the command type property of the command object is text
                    general_command.CommandType = CommandType.StoredProcedure
                    general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = f_record_id
                    general_command.Parameters.Add("@table_name", SqlDbType.NVarChar, 500, Nothing).Value = f_table_name
                    general_command.ExecuteNonQuery()
                End Using

            End Using
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    Public Function fn_delete_file_from_grid_view(ByVal f_connection_string As String, ByVal f_sql As String) As Boolean
        Try
            Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
                connection_object.Open()
                Using general_command As New SqlCommand(f_sql, connection_object) 'here i write the name of stored procedure or the sql string in case if the command type property of the command object is text
                    general_command.CommandType = CommandType.Text
                    general_command.ExecuteNonQuery()
                End Using

            End Using
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
   
   
    Public Function fn_check_hse_checklist_header_record(ByVal f_connection_string As String, ByVal f_now As Date, ByVal f_branch_RecordID As Integer) As DataRow
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed

        Using connection_object As New SqlConnection(f_connection_string)
            Using genral_command As New SqlCommand("select  * from hse_checklist_header_View WHERE DATEDIFF(MONTH,hse_date,GETDATE()) = 0 AND branch_RecordID =  " & f_branch_RecordID, connection_object)
                genral_command.CommandType = CommandType.Text

                general_data_adabter.SelectCommand = genral_command
                general_data_adabter.Fill(general_data_set, "hse_checklist_header_table")
                general_data_table = general_data_set.Tables("hse_checklist_header_table")
                If general_data_table.Rows.Count > 0 Then
                    Return general_data_table.Rows(0)
                Else
                    Return Nothing
                End If


            End Using
        End Using

    End Function
    Public Function fn_check_fire_drill_record(ByVal f_connection_string As String, ByVal f_now As Date, ByVal f_branch_RecordID As Integer) As DataRow
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed

        Using connection_object As New SqlConnection(f_connection_string)
            Using genral_command As New SqlCommand("select  *   from fire_drill_view WHERE DATEDIFF(MONTH,date,GETDATE()) = 0 AND branch_RecordID =  " & f_branch_RecordID, connection_object)
                genral_command.CommandType = CommandType.Text

                general_data_adabter.SelectCommand = genral_command
                general_data_adabter.Fill(general_data_set, "fire_drill_table")
                general_data_table = general_data_set.Tables("fire_drill_table")
                If general_data_table.Rows.Count > 0 Then
                    Return general_data_table.Rows(0)
                Else
                    Return Nothing
                End If

            End Using
        End Using

    End Function
    Public Function fn_authorize_fire_drill(ByVal f_connection_string As String, ByVal f_sql As String) As Boolean
        Try
            Using connection_object As New SqlConnection(f_connection_string)
                connection_object.Open()
                Using general_command_object As New SqlCommand(f_sql, connection_object)
                    general_command_object.ExecuteNonQuery()
                End Using
            End Using
            Return True
        Catch ex As Exception
            Return False
        End Try

    End Function
    Public Function fn_check_branch_system_data_record(ByVal f_connection_string As String, ByVal f_now As Date, ByVal f_branch_RecordID As Integer) As DataRow
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed

        Using connection_object As New SqlConnection(f_connection_string)

            'stop it in 2017
            'Using genral_command As New SqlCommand("select  * from branch_system_data_view WHERE DATEDIFF(Year,create_stamp,GETDATE()) = 0 AND branch_RecordID =  " & f_branch_RecordID, connection_object)
            Using genral_command As New SqlCommand("select  * from branch_system_data_view WHERE  branch_RecordID =  " & f_branch_RecordID, connection_object)
                genral_command.CommandType = CommandType.Text

                general_data_adabter.SelectCommand = genral_command
                general_data_adabter.Fill(general_data_set, "branch_system_data")
                general_data_table = general_data_set.Tables("branch_system_data")
                If general_data_table.Rows.Count > 0 Then
                    Return general_data_table.Rows(0)
                Else
                    Return Nothing
                End If


            End Using
        End Using

    End Function

   

    Public Sub s_upload_files(ByVal s_connection_string As String, ByVal s_folder_files As String, ByVal s_file_upload As FileUpload, ByVal s_lbl_files_upload As Label)
        Dim file_name, full_path, content_type, size, sql As String
        Try
            If s_file_upload.HasFile = True Then
                s_lbl_files_upload.Text = ""
                file_name = Path.GetFileName(s_file_upload.PostedFile.FileName)
                full_path = s_folder_files & file_name
                content_type = s_file_upload.PostedFile.ContentType
                size = s_file_upload.PostedFile.ContentLength

                s_lbl_files_upload.Text = "<font color = '#9900FF'> File Name : " & file_name & "<br>" & _
                                    "File Size : " & size & " kb <br> " & _
                                    "File Content Type : " & content_type & "</font>"

                s_file_upload.SaveAs(full_path)

                Using connection_object As New SqlConnection(s_connection_string)
                    connection_object.Open()
                    sql = "insert into uploaded_files_table values (@folder_files, @file_name, @full_path ,@content_type,@size)"
                    Using genral_command As New SqlCommand(sql, connection_object)
                        genral_command.CommandType = CommandType.Text
                        genral_command.Parameters.Add("@folder_files", SqlDbType.VarChar).Value = s_folder_files
                        genral_command.Parameters.Add("@file_name", SqlDbType.VarChar).Value = file_name
                        genral_command.Parameters.Add("@full_path", SqlDbType.VarChar).Value = full_path
                        genral_command.Parameters.Add("@content_type", SqlDbType.VarChar).Value = content_type
                        genral_command.Parameters.Add("@size", SqlDbType.VarChar).Value = size & " kb"
                        genral_command.ExecuteNonQuery()

                    End Using
                End Using

            Else
                s_lbl_files_upload.Text = "<font color = 'red'> you didn't choose any file for upload please choose a file to upload </font>"
            End If
        Catch ex As Exception
            s_lbl_files_upload.Text = ex.Message
        End Try

    End Sub

    Public Function fill_grid_view_with_uploaded_file(ByVal f_connection_string As String, ByVal s_folder_files As String, ByVal f_data_table_name As String) As DataTable
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable
        Dim sql As String
        sql = "select * from uploaded_files_table where folder_files = '" & s_folder_files & " '"

        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            'connection_object.Open()
            Using general_command As New SqlCommand(sql, connection_object)
                general_command.CommandType = CommandType.Text
                Using general_data_adapter As New SqlDataAdapter(general_command)
                    general_data_adapter.SelectCommand = general_command
                    general_data_adapter.Fill(general_data_set, f_data_table_name)
                    If general_data_set.Tables(f_data_table_name).Rows.Count > 0 Then
                        general_data_table = general_data_set.Tables(f_data_table_name)

                    Else
                        general_data_table = Nothing
                    End If
                    Return general_data_table
                End Using
            End Using
        End Using
    End Function


End Class
                                       