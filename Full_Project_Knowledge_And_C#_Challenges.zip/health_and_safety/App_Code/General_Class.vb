' notes
' 1- if i will retrieve connetion string or retrieve 1 value from table in db i create function in this class
Imports Microsoft.VisualBasic
Imports system.Data.SqlClient
Imports System.Data.OleDb
Imports System.Data
Imports System.Diagnostics
Imports System.Net.Mail

Public Class GeneralClass
    Public Shared Function GetConnectionString1() As String
        Dim configurationAppSettings As New System.Configuration.AppSettingsReader()
        Return DirectCast(((configurationAppSettings.GetValue("ConnectionString", GetType(String)))), String)
    End Function
    Public Shared Function GetConnectionString2() As String 'shared it means u dont need to create obj from the class to use this function but u can use it directly with the name of the class shared as same as static in c#
        Return ConfigurationManager.ConnectionStrings("copy_of_NorthwindConnectionString").ConnectionString
        'Dim connection_string As String = ConfigurationManager.ConnectionStrings("copy_of_AdventureWorksConnectionString").ConnectionString
        'Dim configurationAppSettings As New System.Configuration.AppSettingsReader()
        'Return DirectCast(((configurationAppSettings.GetValue("ConnectionString", GetType(String)))), String)
    End Function
    Public Shared Function GetConnectionString(ByVal web_config As String) As String
        Return ConfigurationManager.ConnectionStrings(web_config).ConnectionString
        'Dim connection_string As String = ConfigurationManager.ConnectionStrings("copy_of_AdventureWorksConnectionString").ConnectionString
        'Dim configurationAppSettings As New System.Configuration.AppSettingsReader()
        'Return DirectCast(((configurationAppSettings.GetValue("ConnectionString", GetType(String)))), String)
    End Function
    Public Shared Function get_branch_codes(ByVal f_connection_string As String) As SqlDataReader
        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            connection_object.Open()
            Using general_command As New SqlCommand("select branch_code,branch_name from branches", connection_object)

                general_command.CommandType = Data.CommandType.Text
                Dim f_data_reader_branch As SqlDataReader = general_command.ExecuteReader(CommandBehavior.SingleResult)
                Return f_data_reader_branch

            End Using
        End Using
    End Function
    Public Shared Function get_data_reader(ByVal f_connection_string As String, ByVal f_sql As String) As SqlDataReader
        Dim connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
        connection_object.Open()
        Dim general_command As New SqlCommand(f_sql, connection_object)

        general_command.CommandType = Data.CommandType.Text
        Dim data_reader As SqlDataReader = general_command.ExecuteReader(CommandBehavior.SingleResult)
        
        Return data_reader

    End Function
    Public Shared Function get_user_login_account() As String
        'Return 2027303   'sami  checker '  '2027303
        'Return 2009583 'dina
        'Return 2023210 'safan maker
        'Return 2012861 'hossam  checker
        'Return 2001755 'dc
        'Return 9999999 'hi level checker
        'Return 2007712
        'Return 2008812
        'Return "H10027859"     'mohamed abo magd
        ' Return "H10026093"  'nagla
        'Return "H10060554" 'katrin
        'Return "H10027575"


        Dim f_get_user_login_account As String

        If InStr(1, HttpContext.Current.Request.ServerVariables(7).ToString, "\") > 0 Then
            f_get_user_login_account = HttpContext.Current.Request.ServerVariables(7).ToString.Split("\")(1)
        Else
            f_get_user_login_account = HttpContext.Current.Request.ServerVariables(7).ToString
        End If

        Return f_get_user_login_account
    End Function

    Public Shared Function validate_user_account_in_admin_db(ByVal f_connection_string As String, ByVal f_user_login_account As String) As Boolean
        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            connection_object.Open()
            Using general_command As New SqlCommand("select UserAccount from V_Users where UserAccount = '" & f_user_login_account & "'", connection_object)
                'because i use "Using general_command"  so that i can ignore this statement : "general_command.CommandType = Data.CommandType.Text"
                'general_command.CommandType = Data.CommandType.Text
                f_user_login_account = general_command.ExecuteScalar   'here i use f_user_login_account for another issue
                If f_user_login_account <> "" Then
                    Return True
                Else
                    Return False
                End If
            End Using
        End Using
    End Function
    Public Shared Function log_in(ByVal f_connection_string As String, ByVal f_client_ip_address As String) As String
        Using connection_object As New SqlConnection(f_connection_string)
            connection_object.Open()
            Using general_command As New SqlCommand("Login", connection_object)
                Dim result As Integer
                Dim result_string As String
                general_command.CommandType = CommandType.StoredProcedure
                general_command.Parameters.Add("@Password", SqlDbType.NVarChar, 50, Nothing).Value = DBNull.Value
                general_command.Parameters.Add("@CurrentIP", SqlDbType.NVarChar, 50, Nothing).Value = f_client_ip_address
                result = general_command.ExecuteScalar()
                Select Case result

                    Case 1
                        result_string = "Unauthorized Login ."
                    Case 3
                        result_string = "User Must Change Password ."
                    Case 4
                        result_string = "Account is Disabled ."
                    Case 5
                        result_string = "Account is Locked ."

                    Case 7
                        result_string = "Log In Succeeded ."

                    Case Else
                        result_string = ""

                End Select
                Return result_string
            End Using

        End Using
        'the below if i will use the log in function in both succeded log in or fail and i will use log in function as alternate to validate_user_account_in_admin_db
        'in this case i will make the log in function return true
        'x = general_command.ExecuteScalar()
        'Select Case x
        '    Case 7 ' means succeded log in 
        '        Return True
        '        else
        '        Error
        'End Select

    End Function
    Public Function get_user_id_and_user_type(ByVal f_connection_string As String, ByVal f_user_login_account As String) As DataRow
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_row As DataRow 'if needed

        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand("select RecordID ,Group_RecordID,branch_RecordID,branch_name  from V_Users where UserAccount = '" & f_user_login_account & "'", connection_object)
                'because i use "Using general_commandand the command type is text not stored procedure"  so that i can ignore this statement : "'general_command.CommandType = Data.CommandType.Text"
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, "user_id_and_user_type")
                Debug.Print(general_command.CommandText)
                general_data_row = general_data_set.Tables(0).Rows(0)
                Return general_data_row
            End Using
        End Using

    End Function
    Public Function get_maker_email_and_checker_email(ByVal f_connection_string As String) As DataRow
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_row As DataRow 'if needed

        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand("SELECT maker_email, checker_email FROM V_Users WHERE RecordID = " & HttpContext.Current.Session("maker_id"), connection_object)
                'because i use "Using general_commandand the command type is text not stored procedure"  so that i can ignore this statement : "'general_command.CommandType = Data.CommandType.Text"
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, "maker_email_and_checker_email")
                Debug.Print(general_command.CommandText)
                general_data_row = general_data_set.Tables(0).Rows(0)
                Return general_data_row
            End Using
        End Using

    End Function
    Public Function get_maker_email(ByVal f_connection_string As String) As DataRow
        ' here i can also use connected model with command.execute scalar
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_row As DataRow 'if needed

        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            Using general_command As New SqlCommand("SELECT maker_email FROM meta_user_data_view WHERE RecordID = " & HttpContext.Current.Session("maker_id"), connection_object)
                'because i use "Using general_commandand the command type is text not stored procedure"  so that i can ignore this statement : "'general_command.CommandType = Data.CommandType.Text"
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, "maker_emaill")
                Debug.Print(general_command.CommandText)
                general_data_row = general_data_set.Tables(0).Rows(0)
                Return general_data_row
            End Using
        End Using

    End Function

    Public Function get_checker_email(ByVal f_connection_string As String) As String
        Dim f_checker_email As String
        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            connection_object.Open()
            Using general_command As New SqlCommand("stp_get_checker_email", connection_object) ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                general_command.CommandType = CommandType.StoredProcedure
                general_command.Parameters.Add("@RecordID", SqlDbType.Int, Nothing, "RecordID").Value = HttpContext.Current.Session("checker_id")
                f_checker_email = general_command.ExecuteScalar()
            End Using
        End Using
        Return f_checker_email
    End Function

    Public Function stp_get_all_checkers_mail_under_1_department(ByVal f_connection_string As String) As String
        Dim checker_email_for_1_department As String
        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            connection_object.Open()
            Using general_command As New SqlCommand("stp_get_all_checkers_mail_under_1_department", connection_object) ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                general_command.CommandType = CommandType.StoredProcedure
                general_command.Parameters.Add("@id", SqlDbType.Int, Nothing, "id").Value = HttpContext.Current.Session("var_record_id")
                general_command.Parameters.Add("@checker_email_for_1_department", SqlDbType.NVarChar, 4000, "checker_email").Direction = ParameterDirection.Output
                general_command.ExecuteScalar()
                'note i can say also direct "checker_email_for_1_department = general_command.ExecuteScalar() " without need to declare output parameter in st procedure
                checker_email_for_1_department = general_command.Parameters("@checker_email_for_1_department").Value
            End Using
        End Using
        Return checker_email_for_1_department
    End Function
    Public Sub refresh_grid_view(ByVal s_data_table As DataTable, ByVal s_grid_view As GridView)
        s_grid_view.DataSource = s_data_table
        s_grid_view.DataBind()
    End Sub
    Public Sub refresh_detail_view(ByVal s_data_set As DataSet, ByVal s_data_table As String, ByVal s_detail_view As DetailsView)
        s_detail_view.DataSource = s_data_set.Tables(s_data_table)
        s_detail_view.DataBind()

    End Sub
    Public Sub hide_grid_view(ByVal s_grid_view As GridView)
        s_grid_view.DataSource = Nothing
        s_grid_view.DataBind()
    End Sub
    Public Sub fill_any_drop_down_list(ByVal s_data_reader As SqlDataReader, ByVal s_drop_down_list As DropDownList, ByVal s_data_value_field As String, ByVal s_data_text_field As String)
        's_drop_down_list.Items.Clear()
        s_drop_down_list.DataSource = s_data_reader
        s_drop_down_list.DataValueField = "RecordID" 's_data_value_field
        s_drop_down_list.DataTextField = "name" 's_data_text_field
        s_drop_down_list.DataBind()
        s_data_reader.Close()
    End Sub
    Public Sub send_mail(ByVal s_from As String, ByVal s_to As String, ByVal s_cc As String, ByVal s_subject As String, ByVal s_body As String, ByVal s_me As Page)
        ' the first way to create cc ===> mail_message_object.CC.Add(s_cc)  where s_cc is normal string for ex : Sherif.Zakariasayed@egypt.bafrica.barclays.com
        '''' the second way Dim cc_object As New MailAddress(s_cc) another way to create cc ==>mail_message_object.CC.Add(cc_object) where s_cc is normal string contain 1 string email or collection of mails for ex : Sherif.Zakariasayed@egypt.bafrica.barclays.com , hossam.fathy@egypt.bafrica.barclays.com
        ' the below describe the collection of mails

        Dim cc1mail, to1mail As String, cc_mail_array_string, to_mail_array_string As String()

        '(1) Create the MailMessage instance
        'Dim mail_message_object As New MailMessage(s_from, s_to)
        Dim mail_message_object As New MailMessage
        mail_message_object.From = New MailAddress(s_from)

        If s_to <> String.Empty Then
            If s_to.Contains(",") Then
                to_mail_array_string = s_to.Split(",")
                For Each to1mail In to_mail_array_string
                    mail_message_object.To.Add(New MailAddress(to1mail))
                Next
            Else
                mail_message_object.To.Add(New MailAddress(s_to))
            End If
        End If

        If s_cc <> String.Empty Then
            If s_cc.Contains(",") Then
                cc_mail_array_string = s_cc.Split(",")
                For Each cc1mail In cc_mail_array_string
                    mail_message_object.CC.Add(New MailAddress(cc1mail))
                Next
            Else
                mail_message_object.CC.Add(New MailAddress(s_cc))
            End If
        End If

        '(2) Assign the MailMessage's properties
        mail_message_object.Subject = s_subject
        mail_message_object.Body = s_body
        mail_message_object.IsBodyHtml = True


        '(3) Create the SmtpClient object
        Dim smtp_client_object As New SmtpClient

        '(4) Send the MailMessage (will use the Web.config settings)
        Try
            smtp_client_object.Send(mail_message_object)

        Catch smtpEx As SmtpException
            'A problem occurred when sending the email message
            s_me.ClientScript.RegisterStartupScript(Me.GetType(), "OhCrap", String.Format("alert('There was a problem in sending the email: {0}');", smtpEx.Message.Replace("'", "\'")), True)

        Finally
            mail_message_object.Dispose()
            smtp_client_object = Nothing
        End Try

    End Sub

    Public Sub send_mail_2(ByVal s_from As String, ByVal s_to As String, ByVal s_cc As String, ByVal s_subject As String, ByVal s_body As String)
        ' the first way to create cc ===> mail_message_object.CC.Add(s_cc)  where s_cc is normal string for ex : Sherif.Zakariasayed@egypt.bafrica.barclays.com
        '''' the second way Dim cc_object As New MailAddress(s_cc) another way to create cc ==>mail_message_object.CC.Add(cc_object) where s_cc is normal string contain 1 string email or collection of mails for ex : Sherif.Zakariasayed@egypt.bafrica.barclays.com , hossam.fathy@egypt.bafrica.barclays.com

        '(1) Create the MailMessage instance
        Dim mail_message_object As New MailMessage(s_from, s_to)
        mail_message_object.CC.Add(s_cc)
        '(2) Assign the MailMessage's properties
        mail_message_object.Subject = s_subject
        mail_message_object.Body = s_body
        mail_message_object.IsBodyHtml = True


        '(3) Create the SmtpClient object
        Dim smtp_client_object As New SmtpClient

        '(4) Send the MailMessage (will use the Web.config settings)
        Try
            smtp_client_object.Send(mail_message_object)

        Finally
            mail_message_object.Dispose()
            smtp_client_object = Nothing
        End Try

    End Sub

    Public Shared Function SetLenth(ByVal Str As String, ByVal Length As Integer, ByVal LengthChr As String, Optional ByVal FromRight As Boolean = False) As String
        Dim sss As String
        Dim L As Integer
        L = Length - Len(Str)
        If L > 0 Then
            If FromRight = True Then
                sss = Str + New String(LengthChr, L)
            Else
                sss = New String(LengthChr, L) + Str
            End If
        ElseIf L = 0 Then
            sss = Str
        End If

        Return sss
    End Function
    Public Function upload_from_excel(ByVal s_connection_string As String, ByVal s_excel_connection_string As String, ByVal s_file_name As String, ByVal s_upload_type As Integer) As String
        'Declare Variables - Edit these based on your particular situation
        Dim str, msg As String
        Dim sql_table_name As String

        ' Dim sExcelFileName As String = "myExcelFile.xls"

        Dim exel_sheet_name As String = "[Report1$]" '"[sheet1$]"  


        'Series of commands to bulk copy data from the excel file into our SQL table

        Using OleDbConn As OleDbConnection = New OleDbConnection(s_excel_connection_string)

            Using OleDbCmd As OleDbCommand = New OleDbCommand(("SELECT * FROM " & exel_sheet_name), OleDbConn)

                Try

                    OleDbConn.Open()

                    Dim dr As OleDbDataReader = OleDbCmd.ExecuteReader()
                    'dr.Read() if we need to ignore the first record in the data reader

                    Dim bulkCopy As SqlBulkCopy = New SqlBulkCopy(s_connection_string)
                    If s_upload_type = 1 Then

                        str = " Auto Loan Data "
                        sql_table_name = "customer_information_table"
                        '23 colunm start from 0
                        bulkCopy.ColumnMappings.Add(0, 1)
                        bulkCopy.ColumnMappings.Add(1, 2)
                        bulkCopy.ColumnMappings.Add(2, 3)
                        bulkCopy.ColumnMappings.Add(3, 4)
                        bulkCopy.ColumnMappings.Add(4, 5)
                        bulkCopy.ColumnMappings.Add(5, 6)
                        bulkCopy.ColumnMappings.Add(6, 7)
                        bulkCopy.ColumnMappings.Add(7, 8)
                        bulkCopy.ColumnMappings.Add(8, 9)
                        bulkCopy.ColumnMappings.Add(9, 10)
                        bulkCopy.ColumnMappings.Add(10, 11)
                        bulkCopy.ColumnMappings.Add(11, 12)
                        bulkCopy.ColumnMappings.Add(12, 13)
                        bulkCopy.ColumnMappings.Add(13, 14)
                        bulkCopy.ColumnMappings.Add(14, 15)
                        bulkCopy.ColumnMappings.Add(15, 16)
                        bulkCopy.ColumnMappings.Add(16, 17)
                        bulkCopy.ColumnMappings.Add(17, 18)
                        bulkCopy.ColumnMappings.Add(18, 19)
                        bulkCopy.ColumnMappings.Add(19, 20)
                        bulkCopy.ColumnMappings.Add(20, 21)
                        bulkCopy.ColumnMappings.Add(21, 22)
                        bulkCopy.ColumnMappings.Add(22, 27) 'amount_string
                        'bulkCopy.ColumnMappings.Add(22, 23)
                    ElseIf s_upload_type = 2 Then

                        str = " Personal Loan Data "
                        sql_table_name = "Personal_loans_table"
                        bulkCopy.ColumnMappings.Add(0, 1)
                        bulkCopy.ColumnMappings.Add(1, 2)
                        bulkCopy.ColumnMappings.Add(2, 3)
                        bulkCopy.ColumnMappings.Add(3, 4)
                        bulkCopy.ColumnMappings.Add(4, 5)
                        bulkCopy.ColumnMappings.Add(5, 6)
                        bulkCopy.ColumnMappings.Add(6, 13)
                    End If

                    bulkCopy.DestinationTableName = sql_table_name

                    bulkCopy.WriteToServer(dr)

                    dr.Close()
                    msg = ("<h3><font color = 'green'>Congratulation All Data Uploaded Succesfully</font> </h3>")

                Catch ex As Exception

                    msg = ("<h3><font color = 'red'>There Is Error Happen During Uploading" & str & "</font> </h3><br>") & ex.Message
                End Try
                Return msg
            End Using
        End Using

        'OleDbConn.Close()
    End Function
    Public Function update_collection_feedback(ByVal f_connection_string As String, ByVal f_file_path As String) As String
        'ByVal f_lbl_result As Label,
        Dim msg As String
        Dim excel_sql_string, sql As String
        Dim i, j As Integer



        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed

     

        excel_sql_string = "Select * FROM OPENROWSET"
        excel_sql_string &= "('Microsoft.Jet.OLEDB.4.0','Excel 8.0;Database=" & f_file_path & ";"
        'excel_sql_string &= "HDR = YES ','SELECT * FROM [collection_feedback$]')"
        excel_sql_string &= "HDR = YES ','SELECT [Customer Name],[Loan Amount], [Car Model],[Letter Issuance Date],[Branch Name], iif([Collection Feedback] = ''APPROVED'',1,2) as [Collection Feedback] , id FROM [collection_feedback$] where id >= 1')"


        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            connection_object.Open()
            Using general_command As New SqlCommand(excel_sql_string, connection_object) 'here i write the name of stored procedure or the sql string in case if the command type property of the command object is text
                Try
                    'general_command.CommandType = CommandType.Text
                    general_data_adabter.SelectCommand = general_command
                    general_data_adabter.Fill(general_data_set, "excel")
                    general_data_table = general_data_set.Tables("excel")

                    For i = 1 To general_data_table.Rows.Count - 1 'we need loop 10 times only not 11 because the number of rows is 11 and first row contains the header 
                        sql = "update customer_information_table set fk_Collection_feedback_RecordID = " & general_data_table.Rows(i)(5) & " where RecordID = " & general_data_table.Rows(i)(6)

                        If general_data_table.Rows(i)(2) Is Nothing Or general_data_table.Rows(i)(6) Is DBNull.Value Then 'here it means that we arrive to the end of row data in excel file 
                            msg = ("<h3><font color = 'green'>:) Congratulation Updating Done Succesfully :) </font> </h3>")
                            Exit For
                        End If
                        general_command.CommandText = sql
                        Debug.Print(general_command.CommandText)
                        general_command.ExecuteNonQuery()
                    Next

                    msg = ("<h3><font color = 'green'>:) Congratulation Updating Done Succesfully :) </font> </h3>")
                Catch ex As Exception
                    msg = "there is error happen during <br>" & ex.Message
                End Try
            End Using
        End Using
        Return msg
    End Function

    'note ExecuteScalar will return only the first cell in the result set it means if i have more row and more colunm it will return the first row and first col

End Class
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  