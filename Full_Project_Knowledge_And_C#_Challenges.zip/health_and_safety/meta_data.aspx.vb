
Partial Class meta_data
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then

            Session("user_login_account") = GeneralClass.get_user_login_account()
            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub



End Class
