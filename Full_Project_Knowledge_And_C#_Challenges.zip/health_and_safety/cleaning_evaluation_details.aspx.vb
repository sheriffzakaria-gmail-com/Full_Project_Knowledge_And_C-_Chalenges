﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class cleaning_evaluation_details
    Inherits System.Web.UI.Page
    Public Shared connection_string As String
    Public Shared required_connection As String


    Public data_set_various As DataSet 'here if i will retrieve from the function dataset 
    Public data_row_various As DataRow 'here if i will retrieve from the function just 1 datarow

    Dim data_reader As SqlDataReader 'this data reader to fill drop down list box

    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    Dim sql, data_table_name As String

    Public Function prepare_connection(ByVal s_required_connection As String) As String
        Return GeneralClass.GetConnectionString(s_required_connection) 'because GeneralClass under app_code we use it direct without import it in this class
    End Function


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            Session("user_login_account") = GeneralClass.get_user_login_account()
            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then

                If Session("Group_RecordID") = 2 And Request.QueryString("authorized") <> 2 Then ' the sender is checker and this check list need to be authories
                    cmd_authorize.Visible = True
                    lbl_authorize.Visible = True
                End If

                Call fill_all_drop_down_list_boxes()

                Session("cleaning_evaluation_RecordID") = Request.QueryString("RecordID")
                sql = "select * from cleaning_evaluation_table where RecordID = " & Session("cleaning_evaluation_RecordID")
                data_table_name = "cleaning_evaluation_table"
                data_row_various = customer_information_class_object.fn_select_one_record(Session("connection_string"), sql, data_table_name)
                Call fill_control_with_data(data_row_various)
                Call control_any_controls(Page.Controls)


            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If

    End Sub

    Public Sub fill_all_drop_down_list_boxes()

        sql = "SELECT RecordID , name FROM TblBranches"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_branches, "RecordID", "name")

        sql = "SELECT RecordID , name FROM  cleaning_level_table"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_facade_cleaning, "RecordID", "name")

        sql = "SELECT RecordID , name FROM  cleaning_level_table"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_carpet_shampooing, "RecordID", "name")

        sql = "SELECT RecordID , name FROM  cleaning_level_table"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_pest_control, "RecordID", "name")

        sql = "SELECT RecordID , name FROM  cleaning_level_table"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_material_availability, "RecordID", "name")

        sql = "SELECT RecordID , name FROM  cleaning_level_table"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_cleaning_walls_ceiling, "RecordID", "name")

        sql = "SELECT RecordID , name FROM  cleaning_level_table"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_cleaner_uniform, "RecordID", "name")

        sql = "SELECT RecordID , name FROM  cleaning_level_table"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_cleaner_attitude, "RecordID", "name")

        sql = "SELECT RecordID , name FROM  cleaning_level_table"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_final_evaluation, "RecordID", "name")

        GeneralClass.get_data_reader(Session("connection_string"), sql).Close()
    End Sub
    Public Sub fill_control_with_data(ByVal s_data_row As DataRow)
        'in case of maker and checker only i can read the branch from the home page (Session("branch_name")
        'and i can use ddl_branches.SelectedItem.Text = Session("branch_name")
        'but with the cres we cant do this and should fill the ddl and point to the target branch 

        'ddl_branches.SelectedItem.Text = Session("branch_name")

        ddl_branches.SelectedValue = IIf(s_data_row("fk_branch_RecordID") IsNot DBNull.Value, s_data_row("fk_branch_RecordID"), "-1")

        txt_date.Text = IIf(s_data_row("date") IsNot DBNull.Value, Format(CStr(s_data_row("date") & ""), "Short Date"), String.Empty)

        ddl_facade_cleaning.SelectedValue = IIf(s_data_row("facade_cleaning") IsNot DBNull.Value, s_data_row("facade_cleaning"), "-1")

        ddl_carpet_shampooing.SelectedValue = IIf(s_data_row("carpet_shampooing") IsNot DBNull.Value, s_data_row("carpet_shampooing"), "-1")
        ddl_furniture.SelectedValue = IIf(s_data_row("furniture") IsNot DBNull.Value, s_data_row("furniture"), "-1")

        ddl_pest_control.SelectedValue = IIf(s_data_row("pest_control") IsNot DBNull.Value, s_data_row("pest_control"), "-1")

        ddl_material_availability.SelectedValue = IIf(s_data_row("material_availability") IsNot DBNull.Value, s_data_row("material_availability"), "-1")

        ddl_cleaning_walls_ceiling.SelectedValue = IIf(s_data_row("cleaning_walls_ceiling") IsNot DBNull.Value, s_data_row("cleaning_walls_ceiling"), "-1")

        ddl_cleaner_attitude.SelectedValue = IIf(s_data_row("cleaner_attitude") IsNot DBNull.Value, s_data_row("cleaner_attitude"), "-1")

        ddl_final_evaluation.SelectedValue = IIf(s_data_row("final_evaluation") IsNot DBNull.Value, s_data_row("final_evaluation"), "-1")


        txt_comment.Text = IIf(s_data_row("comment") IsNot DBNull.Value, s_data_row("comment"), "")

    End Sub

    Protected Sub cmd_back_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmd_back.Click
        Response.Redirect("cleaning_evaluation.aspx")
    End Sub




    Public Sub reset_any_controls(ByVal controls As ControlCollection)
        Dim control As Control

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then
                                'MsgBox(ctlContent.ID)
                                For Each control In ctlContent.Controls
                                    'MsgBox(control.ID)
                                    ' Do work...
                                    If TypeOf control Is TextBox Then
                                        Dim textbox As TextBox
                                        textbox = control
                                        textbox.Text = ""

                                    ElseIf TypeOf control Is Label Then ' i stoped the label to show lbl_result.Text = ("<h4><font color = 'green'> :) The Record Has Been Added Successfully :)</font></h4>")
                                        Dim label As Label
                                        label = control
                                        label.Text = ""

                                    ElseIf TypeOf control Is CheckBox Then
                                        Dim CheckBox As CheckBox
                                        CheckBox = control
                                        CheckBox.Checked = False

                                    ElseIf TypeOf control Is DropDownList Then
                                        Dim DropDownList As DropDownList
                                        DropDownList = control
                                        DropDownList.SelectedIndex = -1

                                    ElseIf TypeOf control Is RadioButtonList Then
                                        Dim RadioButtonList As RadioButtonList
                                        RadioButtonList = control
                                        For Each item As ListItem In RadioButtonList.Items
                                            item.Selected = False
                                        Next

                                    ElseIf TypeOf control Is Panel Then
                                        For Each conntrol_in_panel As Control In control.Controls
                                            If TypeOf conntrol_in_panel Is TextBox Then
                                                Dim textbox As TextBox
                                                textbox = conntrol_in_panel
                                                textbox.Text = ""

                                            ElseIf TypeOf conntrol_in_panel Is Label Then ' i stoped the label to show lbl_result.Text = ("<h4><font color = 'green'> :) The Record Has Been Added Successfully :)</font></h4>")
                                                Dim label As Label
                                                label = conntrol_in_panel
                                                label.Text = ""

                                            ElseIf TypeOf conntrol_in_panel Is CheckBox Then
                                                Dim CheckBox As CheckBox
                                                CheckBox = conntrol_in_panel
                                                CheckBox.Checked = False

                                            ElseIf TypeOf conntrol_in_panel Is DropDownList Then
                                                Dim DropDownList As DropDownList
                                                DropDownList = conntrol_in_panel
                                                DropDownList.SelectedIndex = -1

                                            ElseIf TypeOf conntrol_in_panel Is RadioButtonList Then
                                                Dim RadioButtonList As RadioButtonList
                                                RadioButtonList = conntrol_in_panel
                                                For Each item As ListItem In RadioButtonList.Items
                                                    item.Selected = False
                                                Next item
                                            End If

                                        Next conntrol_in_panel


                                    End If
                                Next control

                            End If
                        Next
                    End If
                Next
            End If
        Next


    End Sub
    Public Sub control_any_controls(ByVal controls As ControlCollection)
        Dim control As Control

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then
                                'MsgBox(ctlContent.ID)
                                For Each control In ctlContent.Controls
                                    If TypeOf control Is Panel Then
                                        'MsgBox(ctlContent.ID)
                                        For Each control_in_panel As Control In control.Controls

                                            If TypeOf control_in_panel Is TextBox Then
                                                Dim textbox As TextBox
                                                textbox = control_in_panel
                                                textbox.Enabled = False

                                            ElseIf TypeOf control_in_panel Is DropDownList Then
                                                Dim DropDownList As DropDownList
                                                DropDownList = control_in_panel
                                                DropDownList.Enabled = False

                                            ElseIf TypeOf control_in_panel Is Label Then
                                                Dim Label As Label
                                                Label = control_in_panel
                                                Label.Enabled = False

                                            ElseIf TypeOf control_in_panel Is RadioButtonList Then
                                                Dim RadioButtonList As RadioButtonList
                                                RadioButtonList = control_in_panel
                                                RadioButtonList.Enabled = False

                                            ElseIf TypeOf control_in_panel Is RadioButton Then
                                                Dim RadioButton As RadioButton
                                                RadioButton = control_in_panel
                                                RadioButton.Enabled = False

                                            ElseIf TypeOf control_in_panel Is Calendar Then
                                                Dim calendar As Calendar
                                                calendar = control_in_panel
                                                calendar.Enabled = False
                                            End If ' controls in pannel

                                        Next control_in_panel 'controls in pannel

                                        ''''''''''''''''''''''''''''
                                    ElseIf TypeOf control Is TextBox Then
                                        Dim textbox As TextBox
                                        textbox = control
                                        textbox.Enabled = False

                                    ElseIf TypeOf control Is DropDownList Then
                                        Dim DropDownList As DropDownList
                                        DropDownList = control
                                        DropDownList.Enabled = False

                                    ElseIf TypeOf control Is Label Then
                                        Dim Label As Label
                                        Label = control
                                        Label.Enabled = False

                                    ElseIf TypeOf control Is RadioButtonList Then
                                        Dim RadioButtonList As RadioButtonList
                                        RadioButtonList = control
                                        RadioButtonList.Enabled = False

                                    ElseIf TypeOf control Is RadioButton Then
                                        Dim RadioButton As RadioButton
                                        RadioButton = control
                                        RadioButton.Enabled = False

                                    ElseIf TypeOf control Is Calendar Then
                                        Dim calendar As Calendar
                                        calendar = control
                                        calendar.Enabled = False
                                    End If 'controls in content place holder

                                Next ' pannel
                            End If
                        Next 'ctlContent
                    End If
                Next 'ctlForm
            End If
        Next 'ctlMaster


    End Sub

    


    Protected Sub cmd_authorize_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmd_authorize.Click
        sql = "update cleaning_evaluation_table set authorized = 2 where RecordID = " & Session("cleaning_evaluation_RecordID")
        Call customer_information_class_object.s_update_status(Session("connection_string"), sql)
        lbl_authorize.Text = "This Evacuation Already Authorized"
        cmd_authorize.Enabled = False
    End Sub
End Class
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             