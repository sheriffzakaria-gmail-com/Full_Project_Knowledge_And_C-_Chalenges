﻿

Imports System.Data
Imports System.Data.SqlClient
Imports System.IO


Partial Class cres_branch_data
    Inherits System.Web.UI.Page

    Public Shared connection_string As String
    Public Shared required_connection As String

    Public Shared oracle_connection_string, oracle_prime_connection_string As String
    Public Shared oracle_required_connection As String

    Dim data_set_various As DataSet 'here if i will retrieve from the function dataset 
    Dim data_table_various As DataTable
    Shared data_row_various As DataRow 'here if i will retrieve from the function just 1 datarow


    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    Dim sql As String
    Dim answer As Boolean

    Public Function prepare_connection(ByVal s_required_connection As String) As String
        Return GeneralClass.GetConnectionString(s_required_connection) 'because GeneralClass under app_code we use it direct without import it in this class
    End Function
    Public Sub reset_any_controls(ByVal controls As ControlCollection)
        Dim control As Control

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then
                                'MsgBox(ctlContent.ID)
                                For Each control In ctlContent.Controls
                                    'MsgBox(control.ID)
                                    ' Do work...
                                    If TypeOf control Is TextBox Then
                                        Dim textbox As TextBox
                                        textbox = control
                                        textbox.Text = ""

                                        'ElseIf TypeOf control Is Label Then
                                        '    Dim label As Label
                                        '    label = control
                                        '    label.Text = ""

                                    ElseIf TypeOf control Is CheckBox Then
                                        Dim CheckBox As CheckBox
                                        CheckBox = control
                                        CheckBox.Checked = False

                                    ElseIf TypeOf control Is GridView Then
                                        Dim GridView As GridView
                                        GridView = control
                                        GridView.DataSource = Nothing
                                        GridView.DataBind()

                                        'ElseIf TypeOf control Is DropDownList Then
                                        '    Dim DropDownList As DropDownList
                                        '    DropDownList = control
                                        '    DropDownList.SelectedIndex = -1

                                        'ElseIf TypeOf control Is Calendar Then
                                        '    Dim calendar As Calendar
                                        '    calendar = control
                                        '    calendar.Enabled = False
                                    End If
                                Next control

                            End If
                        Next
                    End If
                Next
            End If
        Next


    End Sub
    Public Function create_folder_files(ByVal f_folder_name As String) As String
        Dim folder_files As String
        folder_files = Server.MapPath("~/Uploads/" & f_folder_name & "/")
        If Not Directory.Exists(folder_files) Then
            Directory.CreateDirectory(folder_files)
        Else
            'ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Directory already exists.');", True)
        End If
        Return folder_files
    End Function
    Public Sub fill_control_with_data(ByVal s_data_row As DataRow, ByVal s_all_part As Integer) ' 1 all but 2 fill some control  
        If s_all_part = 1 Then
            ddl_branches.SelectedValue = IIf(s_data_row("branch_RecordID") IsNot DBNull.Value, s_data_row("branch_RecordID"), "-1")
            txt_address.Text = IIf(s_data_row("address") IsNot DBNull.Value, s_data_row("address"), "")

            txt_area.Text = IIf(s_data_row("area") IsNot DBNull.Value, s_data_row("area"), "")
            txt_no_of_floor.Text = IIf(s_data_row("no_of_floor") IsNot DBNull.Value, s_data_row("no_of_floor"), "")

            txt_no_of_first_aid_boxes.Text = IIf(s_data_row("no_of_first_aid_boxes") IsNot DBNull.Value, s_data_row("no_of_first_aid_boxes"), "")
            txt_area_of_each_month.Text = IIf(s_data_row("area_of_each_month") IsNot DBNull.Value, s_data_row("area_of_each_month"), "")
            txt_no_of_head_count.Text = IIf(s_data_row("no_of_head_count") IsNot DBNull.Value, s_data_row("no_of_head_count"), "")

            txt_no_of_co2_automatic_extinguishers.Text = IIf(s_data_row("no_of_co2_automatic_extinguishers") IsNot DBNull.Value, s_data_row("no_of_co2_automatic_extinguishers"), "")
            txt_no_of_dry_powder_extinguishers.Text = IIf(s_data_row("no_of_dry_powder_extinguishers") IsNot DBNull.Value, s_data_row("no_of_dry_powder_extinguishers"), "")

            txt_no_of_fire_panels.Text = IIf(s_data_row("no_of_fire_panels") IsNot DBNull.Value, s_data_row("no_of_fire_panels"), "")
            txt_no_of_smoke_detectors.Text = IIf(s_data_row("no_of_smoke_detectors") IsNot DBNull.Value, s_data_row("no_of_smoke_detectors"), "")
            txt_no_of_exit_doors.Text = IIf(s_data_row("no_of_exit_doors") IsNot DBNull.Value, s_data_row("no_of_exit_doors"), "")

            txt_no_of_co2_extinguisher.Text = IIf(s_data_row("no_of_co2_extinguisher") IsNot DBNull.Value, s_data_row("no_of_co2_extinguisher"), "")
            txt_no_of_powder_extinguisher.Text = IIf(s_data_row("no_of_powder_extinguisher") IsNot DBNull.Value, s_data_row("no_of_powder_extinguisher"), "")
            txt_no_of_fm2oo_extinguisher.Text = IIf(s_data_row("no_of_fm2oo_extinguisher") IsNot DBNull.Value, s_data_row("no_of_fm2oo_extinguisher"), "")

            txt_no_of_hosoreel_boxes.Text = IIf(s_data_row("no_of_hosoreel_boxes") IsNot DBNull.Value, s_data_row("no_of_hosoreel_boxes"), "")
           
            chk_generator.Checked = IIf(s_data_row("generator") IsNot DBNull.Value, s_data_row("generator"), False)
            If chk_generator.Checked = True Then
                txt_generator_serial_number.Enabled = True
                txt_generator_barcode.Enabled = True
            Else
                txt_generator_serial_number.Enabled = False
                txt_generator_barcode.Enabled = False
            End If
            txt_generator_serial_number.Text = IIf(s_data_row("generator_serial_number") IsNot DBNull.Value, s_data_row("generator_serial_number"), "")
            txt_generator_barcode.Text = IIf(s_data_row("generator_barcode") IsNot DBNull.Value, s_data_row("generator_barcode"), "")


            chk_ups.Checked = IIf(s_data_row("ups") IsNot DBNull.Value, s_data_row("ups"), False)
            If chk_ups.Checked = True Then
                txt_ups_serial_number.Enabled = True
                txt_ups_barcode.Enabled = True
            Else
                txt_ups_serial_number.Enabled = False
                txt_ups_barcode.Enabled = False
            End If
            txt_ups_serial_number.Text = IIf(s_data_row("ups_serial_number") IsNot DBNull.Value, s_data_row("ups_serial_number"), "")
            txt_ups_barcode.Text = IIf(s_data_row("ups_barcode") IsNot DBNull.Value, s_data_row("ups_barcode"), "")

            txt_last_civil_defence_visit.Text = IIf(s_data_row("last_civil_defence_visit") IsNot DBNull.Value, Format(CStr(s_data_row("last_civil_defence_visit") & ""), "Short Date"), String.Empty) ' i try this in case of null Format(Now, "dd/MM/yyyy")) ' also i can use  in stored procedure convert(varchar(10), CAST( [Insurance_starting_date] as Insurance_starting_date  ),103)   ' old use CStr(Cal_Insurance_starting_date.SelectedDate.Day) & "/" & CStr(Cal_Insurance_starting_date.SelectedDate.Month) & "/" & Cal_Insurance_starting_date.SelectedDate.Year
            Session("last_civil_defence_visit") = s_data_row("last_civil_defence_visit")

            txt_no_of_heat_detectors.Text = IIf(s_data_row("no_of_heat_detectors") IsNot DBNull.Value, s_data_row("no_of_heat_detectors"), "")
            txt_electricity_panel_no.Text = IIf(s_data_row("electricity_panel_no") IsNot DBNull.Value, s_data_row("electricity_panel_no"), "")

            txt_no_of_fire_break_glass.Text = IIf(s_data_row("no_of_fire_break_glass") IsNot DBNull.Value, s_data_row("no_of_fire_break_glass"), "")
            txt_no_of_fire_alarm_sirens.Text = IIf(s_data_row("no_of_fire_alarm_sirens") IsNot DBNull.Value, s_data_row("no_of_fire_alarm_sirens"), "")
        End If

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then  'here we need execute the below during the normal load for the page not the load as result from control like button

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                Call fill_all_drop_down_list_boxes()
                Call control_any_controls(Page.Controls, False)
                
            Else
                Response.Redirect("~\invalid_login.aspx")
            End If
        End If

    End Sub

    Protected Sub Image_save_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles Image_save.Click
        Dim control_collection As Collection

        control_collection = fill_control_collection()


        If Session("branch_system_data_process") = 1 Then ' insert

            Session("branch_system_data_RecordID") = customer_information_class_object.fn_cres_branch_data_add_update_record(Session("connection_string"), Session("branch_RecordID"), control_collection, Session("folder_files"), Session("user_RecordID"), Session("branch_system_data_process"))

            lbl_result.Text = ("<h4><font color = 'green'>  Thank you The Record Has Been Added Successfully :) </font></h4>")
            Call reset_any_controls(Page.Controls)
            ddl_branches.SelectedIndex = 0

        ElseIf Session("branch_system_data_process") = 2 Then 'update
            customer_information_class_object.fn_cres_branch_data_add_update_record(Session("connection_string"), Session("branch_RecordID"), control_collection, "", Session("user_RecordID"), Session("branch_system_data_process"), Session("branch_system_data_RecordID"))
            lbl_result.Text = ("<h4><font color = 'green'> Thank you The Record Has Been Updated Successfully :) </font></h4>")
        End If

        'Image_save.Enabled = False

    End Sub

    Public Function fill_control_collection() As Collection
        Dim control_collection As New Collection()


        Dim control As Control

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then
                                'MsgBox(ctlContent.ID)
                                For Each control_in_placeholder As Control In ctlContent.Controls 'content place holder
                                    If TypeOf control_in_placeholder Is TextBox Then
                                        Dim textbox As TextBox
                                        textbox = control_in_placeholder
                                        control_collection.Add(textbox, textbox.ID)

                                    ElseIf TypeOf control_in_placeholder Is CheckBox Then
                                        Dim CheckBox As CheckBox
                                        CheckBox = control_in_placeholder
                                        control_collection.Add(CheckBox, CheckBox.ID)

                                    ElseIf TypeOf control_in_placeholder Is Calendar Then
                                        Dim Calendar As Calendar
                                        Calendar = control_in_placeholder
                                        control_collection.Add(Calendar, Calendar.ID)

                                    End If


                                    If TypeOf control_in_placeholder Is Panel Then
                                        'MsgBox(ctlContent.ID)
                                        For Each control In control_in_placeholder.Controls

                                            If TypeOf control Is TextBox Then
                                                Dim textbox As TextBox
                                                textbox = control
                                                control_collection.Add(textbox, textbox.ID)

                                            ElseIf TypeOf control Is CheckBox Then
                                                Dim CheckBox As CheckBox
                                                CheckBox = control
                                                control_collection.Add(CheckBox, CheckBox.ID)


                                                'ElseIf TypeOf control Is RadioButton And InStr(control.ID, "true") > 0 Then
                                                '    Dim RadioButton As RadioButton
                                                '    RadioButton = control
                                                '    collection_opt.Add(RadioButton)

                                                'ElseIf TypeOf control Is RadioButton And InStr(control.ID, "false") > 0 Then
                                                '    Dim RadioButton_false As RadioButton
                                                '    RadioButton_false = control
                                                '    collection_opt_false.Add(RadioButton_false)


                                            End If
                                        Next control
                                    End If ' pannel
                                Next ' pannel
                            End If
                        Next
                    End If
                Next
            End If
        Next

        Return control_collection


    End Function

    Public Sub reset_some_controls(ByVal s_control_collection As Collection)

        For Each control As Control In s_control_collection

            If TypeOf control Is TextBox Then
                Dim text_box As TextBox
                'text_box = CType(Control, TextBox)
                text_box = control
                text_box.Text = ""


            ElseIf TypeOf control Is RadioButton Then
                Dim radio_button As RadioButton
                radio_button = control
                radio_button.Checked = False
            End If

        Next
    End Sub
    Public Sub fill_all_drop_down_list_boxes()

        sql = "SELECT RecordID , name FROM TblBranches"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_branches, "RecordID", "name")

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Cal_last_civil_defence_visit.Visible = True
    End Sub

    Protected Sub Cal_last_civil_defence_visit_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cal_last_civil_defence_visit.SelectionChanged
        txt_last_civil_defence_visit.Text = Format(Cal_last_civil_defence_visit.SelectedDate, "dd/MM/yyyy")
        Session("last_civil_defence_visit") = Cal_last_civil_defence_visit.SelectedDate
        Cal_last_civil_defence_visit.Visible = False
    End Sub

    Protected Sub ddl_branches_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_branches.SelectedIndexChanged

        If ddl_branches.SelectedIndex = 0 Then
            Call reset_any_controls(Page.Controls)
            Call control_any_controls(Page.Controls, False)
        End If

        If ddl_branches.SelectedIndex > 0 Then
            Call control_any_controls(Page.Controls, True)
            Image_save.Enabled = True
            Session("branch_RecordID") = ddl_branches.SelectedItem.Value
            Session("branch_name") = ddl_branches.SelectedItem.Text

            data_row_various = customer_information_class_object.fn_check_branch_system_data_record(Session("connection_string"), Now, Session("branch_RecordID"))

            If data_row_various IsNot Nothing Then ' we here has 1 record
                Session("branch_system_data_process") = 2 'update
                'show the data in control
                Call fill_control_with_data(data_row_various, 1) ' here the record is exist so that we will fill all the control with the all data
                Session("branch_system_data_RecordID") = data_row_various("RecordID") 'to use it in update statment
                Session("folder_files") = data_row_various("folder_files")
                Call fill_grid_view_with_uploaded_file()

            Else

                Call reset_any_controls(Page.Controls)
                Session("branch_system_data_process") = 1 'insert

            End If

        End If

        lbl_result.Text = ""
    End Sub

    Public Sub control_any_controls(ByVal controls As ControlCollection, ByVal poperty_value As Boolean)
        Dim control As Control

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then  '
                                'MsgBox(ctlContent.ID)

                                For Each control_in_placeholder As Control In ctlContent.Controls

                                    'MsgBox(ctlContent.ID)

                                    If TypeOf control_in_placeholder Is TextBox Then
                                        Dim textbox As TextBox
                                        textbox = control_in_placeholder
                                        If textbox.ID <> "txt_generator_serial_number" And textbox.ID <> "txt_generator_barcode"  _
                                            And textbox.ID <> "txt_ups_serial_number" And textbox.ID <> "txt_ups_barcode" Then
                                            textbox.Enabled = poperty_value
                                        End If
                                        'i stop it because if the ddl branches is disabled we cant select any branch
                                        'ElseIf TypeOf control_in_placeholder Is DropDownList Then
                                        '    Dim DropDownList As DropDownList
                                        '    DropDownList = control_in_placeholder
                                        '    DropDownList.Enabled = poperty_value

                                    ElseIf TypeOf control_in_placeholder Is Label Then
                                        Dim Label As Label
                                        Label = control_in_placeholder
                                        Label.Enabled = poperty_value

                                    ElseIf TypeOf control_in_placeholder Is RadioButtonList Then
                                        Dim RadioButtonList As RadioButtonList
                                        RadioButtonList = control_in_placeholder
                                        RadioButtonList.Enabled = poperty_value

                                    ElseIf TypeOf control_in_placeholder Is RadioButton Then
                                        Dim RadioButton As RadioButton
                                        RadioButton = control_in_placeholder
                                        RadioButton.Enabled = poperty_value

                                    ElseIf TypeOf control_in_placeholder Is Calendar Then
                                        Dim calendar As Calendar
                                        calendar = control_in_placeholder
                                        calendar.Enabled = poperty_value


                                    ElseIf TypeOf control_in_placeholder Is Panel Then

                                        For Each control In control_in_placeholder.Controls

                                            'MsgBox(ctlContent.ID)


                                            If TypeOf control Is TextBox Then
                                                Dim textbox As TextBox
                                                textbox = control
                                                textbox.Enabled = poperty_value

                                                'ElseIf TypeOf control Is DropDownList Then
                                                '    Dim DropDownList As DropDownList
                                                '    DropDownList = control
                                                '    DropDownList.Enabled = poperty_value

                                            ElseIf TypeOf control Is Label Then
                                                Dim Label As Label
                                                Label = control
                                                Label.Enabled = poperty_value

                                            ElseIf TypeOf control Is RadioButtonList Then
                                                Dim RadioButtonList As RadioButtonList
                                                RadioButtonList = control
                                                RadioButtonList.Enabled = poperty_value

                                            ElseIf TypeOf control Is RadioButton Then
                                                Dim RadioButton As RadioButton
                                                RadioButton = control
                                                RadioButton.Enabled = poperty_value

                                            ElseIf TypeOf control Is Calendar Then
                                                Dim calendar As Calendar
                                                calendar = control
                                                calendar.Enabled = poperty_value
                                            End If

                                        Next control 'For Each control In control_in_placeholder.Controls related to control in pannel

                                    End If '  ElseIf TypeOf control_in_placeholder Is Panel Then
                                Next control_in_placeholder ' pannel
                    End If
                        Next
            End If ' If TypeOf ctlForm Is HtmlForm Then
        Next 'For Each ctlForm As Control In ctlMaster.Controls
            End If 'If TypeOf ctlMaster Is MasterPage Then
        Next 'For Each ctlMaster As Control In Page.Controls


    End Sub

    Protected Sub chk_generator_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_generator.CheckedChanged
        If chk_generator.Checked = True Then
            txt_generator_serial_number.Enabled = True
            txt_generator_barcode.Enabled = True
        Else
            txt_generator_serial_number.Enabled = False
            txt_generator_barcode.Enabled = False
            txt_generator_serial_number.Text = ""
            txt_generator_barcode.Text = ""
        End If
    End Sub

    Protected Sub chk_ups_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chk_ups.CheckedChanged
        If chk_ups.Checked = True Then
            txt_ups_serial_number.Enabled = True
            txt_ups_barcode.Enabled = True
        Else
            txt_ups_serial_number.Enabled = False
            txt_ups_barcode.Enabled = False
            txt_ups_serial_number.Text = ""
            txt_ups_barcode.Text = ""
        End If
    End Sub

    
    Public Sub fill_grid_view_with_uploaded_file()
        data_table_various = customer_information_class_object.fill_grid_view_with_uploaded_file(Session("connection_string"), Session("folder_files"), "uploaded_files")
        gv_upload_files.DataSource = data_table_various
        gv_upload_files.DataBind()
    End Sub

    
    Protected Sub lnk_dowanload_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim filePath As String = CType(sender, LinkButton).CommandArgument
        Response.ContentType = ContentType
        Response.AppendHeader("Content-Disposition", ("attachment; filename=" + Path.GetFileName(filePath)))
        Response.WriteFile(filePath)
        Response.End()
    End Sub

    Protected Sub lnk_delete_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim result_of_function As Boolean
        Dim filePath As String = TryCast(sender, LinkButton).CommandArgument
        File.Delete(filePath)
        sql = "delete from uploaded_files_table where path = '" & filePath & " '"
        result_of_function = customer_information_class_object.fn_delete_file_from_grid_view(Session("connection_string"), sql)
        Call fill_grid_view_with_uploaded_file()
        lbl_upload_files.Text = ""
    End Sub

    Protected Sub btn_Upload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_upload.Click
        If Session("branch_system_data_process") = 1 Then
            Session("folder_files") = create_folder_files(Session("branch_name") & "_" & Format(Now, "dd_MM_yyyy")) '_hh_mm_ss_tt
        End If
        Call customer_information_class_object.s_upload_files(Session("connection_string"), Session("folder_files"), FileUpload1, lbl_upload_files)
        Call fill_grid_view_with_uploaded_file()
    End Sub
End Class
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              