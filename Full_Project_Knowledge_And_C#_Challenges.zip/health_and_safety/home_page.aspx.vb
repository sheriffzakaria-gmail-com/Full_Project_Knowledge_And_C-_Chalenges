Imports System.Data
Imports system.Data.SqlClient
Partial Class _Customer
    Inherits System.Web.UI.Page

    Public Shared connection_string As String
    Public Shared required_connection As String

    Public Shared oracle_connection_string, oracle_prime_connection_string As String
    Public Shared oracle_required_connection As String

    Dim data_set_various As DataSet 'here if i will retrieve from the function dataset 
    Dim data_row_various As DataRow 'here if i will retrieve from the function just 1 datarow


    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class
    Dim loan_type As Integer
    Dim sql As String

    Public Function prepare_connection(ByVal s_required_connection As String) As String
        Return GeneralClass.GetConnectionString(s_required_connection) & ";Application Name=CRES_HEALTH_AND_SAFTY\" & GeneralClass.get_user_login_account 'because GeneralClass under app_code we use it direct without import it in this class
    End Function
    
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button

            required_connection = "CRES_HEALTH_AND_SAFTY_ConnectionString"
            connection_string = prepare_connection(required_connection) 'THIS FUNCTION WILL CALL ANOTHER FUNCTION EXIST IN SETTING CLASS
            Session("connection_string") = connection_string

            Session("user_login_account") = GeneralClass.get_user_login_account()
            Session("client_ip_address") = Request.UserHostAddress()
            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then

                Call GeneralClass.log_in(Session("connection_string"), Session("client_ip_address"))

                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))
                Session("user_RecordID") = data_row_various("RecordID")
                Session("Group_RecordID") = data_row_various("Group_RecordID")
                Session("branch_RecordID") = data_row_various("branch_RecordID")
                Session("branch_name") = data_row_various("branch_name") ' 'readed from home page

            Else
                Session("can_not_log_in") = GeneralClass.log_in(Session("connection_string"), Session("client_ip_address"))
                Response.Redirect("~\invalid_login.aspx")
            End If



        End If


    End Sub

    

   

    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub



End Class
