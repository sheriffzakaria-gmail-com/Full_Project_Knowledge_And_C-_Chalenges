﻿
Imports System.Net.Mail
Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Data.OleDb
Public Class Form1

    Dim connection_string As String
    Dim required_connection As String
    Dim oracle_connection_string As String
    Dim oracle_required_connection As String

    Dim data_set_various As DataSet 'here if i will retrieve from the function dataset 
    Dim data_row_various As DataRow 'here if i will retrieve from the function just 1 datarow



    Dim sql As String



    Dim from, too, cc, subject, body As String
    Public Function prepare_connection(ByVal s_required_connection As String) As String
        Return GetConnectionString3(s_required_connection) 'because GeneralClass under app_code we use it direct without import it in this class
    End Function
    Public Shared Function GetConnectionString3(ByVal web_config As String) As String

        Return ConfigurationManager.ConnectionStrings(web_config).ConnectionString
        'Dim connection_string As String = ConfigurationManager.ConnectionStrings("copy_of_AdventureWorksConnectionString").ConnectionString
        'Dim configurationAppSettings As New System.Configuration.AppSettingsReader()
        'Return DirectCast(((configurationAppSettings.GetValue("ConnectionString", GetType(String)))), String)
    End Function
    Public Function send_mail(ByVal s_from As String, ByVal s_to As String, ByVal s_cc As String, ByVal s_subject As String, ByVal s_body As String) As Boolean
        ' the first way to create cc ===> mail_message_object.CC.Add(s_cc)  where s_cc is normal string for ex : Sherif.Zakariasayed@egypt.bafrica.barclays.com
        '''' the second way Dim cc_object As New MailAddress(s_cc) another way to create cc ==>mail_message_object.CC.Add(cc_object) where s_cc is normal string contain 1 string email or collection of mails for ex : Sherif.Zakariasayed@egypt.bafrica.barclays.com , hossam.fathy@egypt.bafrica.barclays.com
        ' the below describe the collection of mails
        Dim result As Boolean
        Dim cc1mail, to1mail As String, cc_mail_array_string, to_mail_array_string As String()

        '(1) Create the MailMessage instance
        'Dim mail_message_object As New MailMessage(s_from, s_to)
        Dim mail_message_object As New MailMessage
        mail_message_object.From = New MailAddress(s_from)

        If s_to <> String.Empty Then
            If s_to.Contains(";") Then
                to_mail_array_string = s_to.Split(";")
                For Each to1mail In to_mail_array_string
                    mail_message_object.To.Add(New MailAddress(to1mail))
                Next
            Else
                mail_message_object.To.Add(New MailAddress(s_to))
            End If
        End If

        If s_cc <> String.Empty Then
            If s_cc.Contains(",") Then
                cc_mail_array_string = s_cc.Split(",")
                For Each cc1mail In cc_mail_array_string
                    mail_message_object.CC.Add(New MailAddress(cc1mail))
                Next
            Else
                mail_message_object.CC.Add(New MailAddress(s_cc))
            End If
        End If

        '(2) Assign the MailMessage's properties
        mail_message_object.Subject = s_subject
        mail_message_object.Body = s_body
        mail_message_object.IsBodyHtml = True


        '(3) Create the SmtpClient object
        Dim smtp_client_object As New SmtpClient

        '(4) Send the MailMessage (will use the Web.config settings)
        Try
            smtp_client_object.Send(mail_message_object)
            result = True
            Return result



        Catch smtpEx As SmtpException
            result = False
            'A problem occurred when sending the email message
            MsgBox(smtpEx.Message & vbCrLf & smtpEx.Source)
            Return result

            'the below is related to web application 
            ''''s_me.ClientScript.RegisterStartupScript(Me.GetType(), "OhCrap", String.Format("alert('There was a problem in sending the email: {0}');", smtpEx.Message.Replace("'", "\'")), True)

        Finally
            mail_message_object.Dispose()
            smtp_client_object = Nothing

        End Try

    End Function
    
    
   
    Public Function fn_prepare_notification_mail(ByVal f_connection_string As String, ByVal f_sql As String) As Boolean
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed
        Dim general_data_row, log_data_row As DataRow
        Dim data_table_name As String = "lating_check_list_view"
        Dim sql As String 'we send here the lating branches which we should send mails to them
        Dim notification_type As Integer
        'insert base date in log table to use it with branch name
        'connection_object.Open() 'because i use using connection_object  i dont ned say "connection_object.Open() "
        Using connection_object As New SqlConnection(f_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function

            Using general_command As New SqlCommand(f_sql, connection_object) ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                general_command.CommandType = CommandType.Text
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, data_table_name)
                general_data_table = general_data_set.Tables(data_table_name)

                For Each general_data_row In general_data_table.Rows  'here i have the base date and the branch

                    If general_data_set.Tables.Contains("log") = True Then
                        general_data_set.Tables.Remove(general_data_set.Tables("log"))
                    End If

                    'check in log table with the key base date + branch and i will get the notification if record exist if not will be 1
                    sql = "select * From  notification_log_table where base_date = '" & Format(general_data_row("base_date"), "dd-MMM-yyyy") & "' and " & _
                    "fk_branch_RecordID = " & general_data_row("branch_RecordID") & _
                    " and fk_notification_RecordID IN (SELECT MAX(fk_notification_RecordID) FROM  notification_log_table " & _
                    "where fk_branch_RecordID = " & general_data_row("branch_RecordID") & " GROUP BY fk_branch_RecordID )"

                    general_command.CommandText = sql
                    general_data_adabter.Fill(general_data_set, "log") 'creating log table in data table

                    If general_data_set.Tables("log").Rows.Count < 1 Then
                        notification_type = 1

                        If DatePart(DateInterval.Day, Now) > 2 Then  'DatePart(DateInterval.Day, Now) > 7
                            'pass base_date here to use it in the function who insert in the log table 
                            Call prepare_and_send_email(f_connection_string, general_data_row("base_date"), notification_type, general_data_row("branch_RecordID"))
                        End If

                    Else
                        log_data_row = general_data_set.Tables("log").Rows(0)
                        notification_type = log_data_row("fk_notification_RecordID")
                        If notification_type <> 3 Then
                            If DateDiff(DateInterval.Day, log_data_row("notification_date"), Now) > 1 And log_data_row("fk_notification_RecordID") = 1 Then   'DateDiff(DateInterval.Day, log_data_row("notification_date"), Now) > 3
                                notification_type = 2
                                Call prepare_and_send_email(f_connection_string, general_data_row("base_date"), notification_type, general_data_row("branch_RecordID"))

                            ElseIf DateDiff(DateInterval.Day, log_data_row("notification_date"), Now) > 2 And log_data_row("fk_notification_RecordID") = 2 Then ' ElseIf DateDiff(DateInterval.Day, log_data_row("notification_date"), Now) > 3
                                notification_type = 3
                                Call prepare_and_send_email(f_connection_string, general_data_row("base_date"), notification_type, general_data_row("branch_RecordID"))
                            End If 'DateDiff
                        End If 'notification_type <> 3
                    End If 'general_data_set.Tables("log").Rows.Count < 1


                Next
            End Using
        End Using
    End Function
    
   
    Public Sub prepare_and_send_email(ByVal s_connection_string As String, ByVal s_base_date As Date, ByVal s_notification_type As Integer, ByVal s_branch_RecordID As Integer)
        Dim general_data_adabter As New SqlDataAdapter()
        Dim general_data_set As New DataSet()
        Dim general_data_table As New DataTable 'if needed
        Dim general_data_row As DataRow
        Dim data_table_name As String = "send_email_check_list_notification_view"

        Using connection_object As New SqlConnection(s_connection_string) ' here i created CONNECTION object which it will released and destroyed afer end of the function
            'here will get the branch and it's current notification
            sql = "select * from send_email_check_list_notification_view where fk_branch_RecordID = " & s_branch_RecordID & _
                                                " and fk_notification_RecordID = " & s_notification_type

            Using general_command As New SqlCommand(sql, connection_object) ' note in case if the command type is text  that it is not ablogatory to say general_command.CommandType = .... but i should write it if i will use stored procedure which has parameters only
                general_command.CommandType = CommandType.Text
                general_data_adabter.SelectCommand = general_command
                general_data_adabter.Fill(general_data_set, data_table_name)
                general_data_table = general_data_set.Tables(data_table_name)
                general_data_row = general_data_table.Rows(0)

                from = "Health_And_Safty_System@barclays.com"
                too = general_data_row("email_to").ToString.Trim
                subject = general_data_row("email_subject")
                body = "<font color = 'DarkViolet'> <h4>  Dear Sir <br><br><br>" & general_data_row("email_body") & " " & general_data_row("Branch_name") & " Branch<br><br><br><br>" & _
                             "Thank You And Best Regards <br> Health And Safty System </h4></font>"

                If send_mail(from, too, cc, subject, body) = True Then

                    sql = "insert into notification_log_table (fk_branch_RecordID, base_date, notification_date , fk_notification_RecordID) " & _
                             "values ( " & s_branch_RecordID & ", '" & s_base_date.ToString("dd-MMM-yyyy") & "' ,getdate()," & s_notification_type & " )"
                    fn_insert_into_log_table(connection_string, sql)

                End If
            End Using
        End Using
    End Sub

    Public Function fn_insert_into_log_table(ByVal f_connection_string As String, ByVal f_sql As String) As Boolean
        Try
            Using connection_object = New SqlConnection(f_connection_string)
                connection_object.Open()
                Using general_command_object = New SqlCommand(f_sql, connection_object)
                    general_command_object.ExecuteNonQuery()
                End Using
            End Using
            Return True
        Catch ex As Exception
            Return False
        End Try

    End Function


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        required_connection = "CRES_HEALTH_AND_SAFTY_ConnectionString"
        connection_string = prepare_connection(required_connection) 'THIS FUNCTION WILL CALL ANOTHER FUNCTION EXIST IN SETTING CLASS
        sql = "select * from lating_check_list_view"
        fn_prepare_notification_mail(connection_string, sql)

        End
    End Sub
End Class
