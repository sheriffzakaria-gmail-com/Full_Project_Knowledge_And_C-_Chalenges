﻿

Imports System.Data
Imports System.Data.SqlClient


Partial Class health_and_safty_check_list
    Inherits System.Web.UI.Page

    Public Shared connection_string As String
    Public Shared required_connection As String

    Public Shared oracle_connection_string, oracle_prime_connection_string As String
    Public Shared oracle_required_connection As String

    Dim data_set_various As DataSet 'here if i will retrieve from the function dataset 
    Dim data_table_various As DataTable
    Shared data_row_various As DataRow 'here if i will retrieve from the function just 1 datarow


    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    Dim sql As String
    Dim answer As Boolean

    Public Function prepare_connection(ByVal s_required_connection As String) As String
        Return GeneralClass.GetConnectionString(s_required_connection) 'because GeneralClass under app_code we use it direct without import it in this class
    End Function
    Public Sub reset_any_controls(ByVal controls As ControlCollection)
        Dim control As Control

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then
                                'MsgBox(ctlContent.ID)
                                For Each control In ctlContent.Controls
                                    'MsgBox(control.ID)
                                    ' Do work...
                                    If TypeOf control Is TextBox Then
                                        Dim textbox As TextBox
                                        textbox = control
                                        textbox.Text = ""
                                    ElseIf TypeOf control Is DropDownList Then
                                        Dim DropDownList As DropDownList
                                        DropDownList = control
                                        DropDownList.SelectedIndex = -1

                                        ''ElseIf TypeOf control Is Calendar Then
                                        ''    Dim calendar As Calendar
                                        ''    calendar = control
                                        ''    calendar.Enabled = False
                                    End If
                                Next control

                            End If
                        Next
                    End If
                Next
            End If
        Next


    End Sub
    Public Sub fill_control_with_data(ByVal s_data_row As DataRow, ByVal s_all_part As Integer) ' 1 all but 2 fill some control  
        If s_all_part = 1 Then
            txt_branch_name.Text = IIf(s_data_row("branch_name") IsNot DBNull.Value, s_data_row("branch_name"), "")
            'If(IsDBNull(dRow("sysdate")), "", Format(dRow("sysdate"), "MM/dd/yyyy")) ' in visual studio 2011 and 2010 we can use this concept but if i will use iif it will return error in case if the field value = null cause i cant use format(null,"dd/MM/yyyy") but i can solve it by using IIf(s_data_row("insurance_ending_date") IsNot DBNull.Value, Format(CStr(s_data_row("insurance_ending_date") & ""), "Short Date"), String.Empty)
            txt_hse_date.Text = IIf(s_data_row("hse_date") IsNot DBNull.Value, Format(CStr(s_data_row("hse_date") & ""), "Short Date"), String.Empty) ' i try this in case of null Format(Now, "dd/MM/yyyy")) ' also i can use  in stored procedure convert(varchar(10), CAST( [Insurance_starting_date] as Insurance_starting_date  ),103)   ' old use CStr(Cal_Insurance_starting_date.SelectedDate.Day) & "/" & CStr(Cal_Insurance_starting_date.SelectedDate.Month) & "/" & Cal_Insurance_starting_date.SelectedDate.Year
            txt_hse_inspector.Text = IIf(s_data_row("hse_inspector") IsNot DBNull.Value, s_data_row("hse_inspector"), "")
            txt_emergency_manager.Text = IIf(s_data_row("emergency_manager") IsNot DBNull.Value, s_data_row("emergency_manager"), "")
            txt_branch_head_count.Text = IIf(s_data_row("branch_head_count") IsNot DBNull.Value, s_data_row("branch_head_count"), "")
            txt_no_fire_fighting_trainees.Text = IIf(s_data_row("no_fire_fighting_trainees") IsNot DBNull.Value, s_data_row("no_fire_fighting_trainees"), "")
            txt_no_of_aid_trainees.Text = IIf(s_data_row("no_of_aid_trainees") IsNot DBNull.Value, s_data_row("no_of_aid_trainees"), "")


            'ddl_insuranse_company.SelectedValue = IIf(s_data_row("fk_Insurance_company_RecordID") IsNot DBNull.Value, s_data_row("fk_Insurance_company_RecordID"), "-1")

        ElseIf s_all_part = 2 Then
            txt_branch_name.Text = Session("branch_name") 'IIf(s_data_row("branch_name") IsNot DBNull.Value, s_data_row("branch_name"), "")
            txt_hse_date.Text = Format(Now, "dd/MM/yyyy")


        ElseIf s_all_part = 3 Then ' here we will show the  q data 
            lbl_category.Text = IIf(s_data_row("category") IsNot DBNull.Value, s_data_row("category"), "")
            lbl_question.Text = IIf(s_data_row("question") IsNot DBNull.Value, s_data_row("question"), "")
            lbl_hint.Text = IIf(s_data_row("hint") IsNot DBNull.Value, s_data_row("hint"), "")


        ElseIf s_all_part = 4 Then ' here we will show the  answer  data 
            opt_true.Checked = IIf(s_data_row("answer") IsNot DBNull.Value, s_data_row("answer"), False)
            If s_data_row("answer") Is DBNull.Value Then
                opt_false.Checked = False
            ElseIf opt_true.Checked = True Then
                opt_false.Checked = False
            ElseIf opt_true.Checked = False And s_data_row("answer") IsNot DBNull.Value Then 'in case if the answer false
                opt_false.Checked = True
            End If
            txt_comment.Text = IIf(s_data_row("comment") IsNot DBNull.Value, s_data_row("comment"), "")

        ElseIf s_all_part = 5 Then ' here we will show the emergency data 
            txt_e_m_name.Text = IIf(s_data_row("e_m_name") IsNot DBNull.Value, s_data_row("e_m_name"), "")
            txt_e_m_account.Text = IIf(s_data_row("e_m_account") IsNot DBNull.Value, s_data_row("e_m_account"), "")
            txt_e_m_ext.Text = IIf(s_data_row("e_m_ext") IsNot DBNull.Value, s_data_row("e_m_ext"), "")

            txt_d_e_m_name.Text = IIf(s_data_row("d_e_m_name") IsNot DBNull.Value, s_data_row("d_e_m_name"), "")
            txt_d_e_m_account.Text = IIf(s_data_row("d_e_m_account") IsNot DBNull.Value, s_data_row("d_e_m_account"), "")
            txt_d_e_m_ext.Text = IIf(s_data_row("d_e_m_ext") IsNot DBNull.Value, s_data_row("d_e_m_ext"), "")

            txt_f_a_name.Text = IIf(s_data_row("f_a_name") IsNot DBNull.Value, s_data_row("f_a_name"), "")
            txt_f_a_account.Text = IIf(s_data_row("f_a_account") IsNot DBNull.Value, s_data_row("f_a_account"), "")
            txt_f_a_ext.Text = IIf(s_data_row("f_a_ext") IsNot DBNull.Value, s_data_row("f_a_ext"), "")

            txt_evac_m_name_1.Text = IIf(s_data_row("evac_m_name_1") IsNot DBNull.Value, s_data_row("evac_m_name_1"), "")
            txt_evac_m_account_1.Text = IIf(s_data_row("evac_m_account_1") IsNot DBNull.Value, s_data_row("evac_m_account_1"), "")
            txt_evac_m_ext_1.Text = IIf(s_data_row("evac_m_ext_1") IsNot DBNull.Value, s_data_row("evac_m_ext_1"), "")
            txt_evac_m_name_2.Text = IIf(s_data_row("evac_m_name_2") IsNot DBNull.Value, s_data_row("evac_m_name_2"), "")
            txt_evac_m_account_2.Text = IIf(s_data_row("evac_m_account_2") IsNot DBNull.Value, s_data_row("evac_m_account_2"), "")
            txt_evac_m_ext_2.Text = IIf(s_data_row("evac_m_ext_2") IsNot DBNull.Value, s_data_row("evac_m_ext_2"), "")

            txt_evac_monitor_name.Text = IIf(s_data_row("evac_monitor_name") IsNot DBNull.Value, s_data_row("evac_monitor_name"), "")
            txt_evac_monitor_account.Text = IIf(s_data_row("evac_monitor_account") IsNot DBNull.Value, s_data_row("evac_monitor_account"), "")
            txt_evac_monitor_ext.Text = IIf(s_data_row("evac_monitor_ext") IsNot DBNull.Value, s_data_row("evac_monitor_ext"), "")

            txt_f_f_name_1.Text = IIf(s_data_row("f_f_name_1") IsNot DBNull.Value, s_data_row("f_f_name_1"), "")
            txt_f_f_account_1.Text = IIf(s_data_row("f_f_account_1") IsNot DBNull.Value, s_data_row("f_f_account_1"), "")
            txt_f_f_ext_1.Text = IIf(s_data_row("f_f_ext_1") IsNot DBNull.Value, s_data_row("f_f_ext_1"), "")
            txt_f_f_name_2.Text = IIf(s_data_row("f_f_name_2") IsNot DBNull.Value, s_data_row("f_f_name_2"), "")
            txt_f_f_account_2.Text = IIf(s_data_row("f_f_account_2") IsNot DBNull.Value, s_data_row("f_f_account_2"), "")
            txt_f_f_ext_2.Text = IIf(s_data_row("f_f_ext_2") IsNot DBNull.Value, s_data_row("f_f_ext_2"), "")
            txt_f_f_name_3.Text = IIf(s_data_row("f_f_name_3") IsNot DBNull.Value, s_data_row("f_f_name_3"), "")
            txt_f_f_account_3.Text = IIf(s_data_row("f_f_account_3") IsNot DBNull.Value, s_data_row("f_f_account_3"), "")
            txt_f_f_ext_3.Text = IIf(s_data_row("f_f_ext_3") IsNot DBNull.Value, s_data_row("f_f_ext_3"), "")
            txt_f_f_name_4.Text = IIf(s_data_row("f_f_name_4") IsNot DBNull.Value, s_data_row("f_f_name_4"), "")
            txt_f_f_account_4.Text = IIf(s_data_row("f_f_account_4") IsNot DBNull.Value, s_data_row("f_f_account_4"), "")
            txt_f_f_ext_4.Text = IIf(s_data_row("f_f_ext_4") IsNot DBNull.Value, s_data_row("f_f_ext_4"), "")
        End If

    End Sub

    Public Sub get_and_show_answer()
        'here we will start read the answer table using Session("hse_checklist_header_RecordID")  and Session("question_RecordID")
        'and if there is not any datarow return then we will insert this row and if exist then we will show the q data and answer data and we will update
        sql = "select * from hse_checklist_a_table where fk_check_list_RecordID =  " & Session("hse_checklist_header_RecordID") & " and fk_check_list_q_RecordID = " & Session("question_RecordID")
        data_row_various = customer_information_class_object.fn_question_information_select_one_record(Session("connection_string"), sql)
        If data_row_various IsNot Nothing Then
            Call fill_control_with_data(data_row_various, 4)
        End If
    End Sub
    Public Sub fill_control_with_data(ByVal s_data_row As DataRow)

        ''lbl_category.Text = IIf(s_data_row("category") IsNot DBNull.Value, s_data_row("category"), "")
        ''lbl_question.Text = IIf(s_data_row("question") IsNot DBNull.Value, s_data_row("question"), "")
        ''lbl_hint.Text = IIf(s_data_row("hint") IsNot DBNull.Value, s_data_row("hint"), "")

        ''opt_true.Checked = s_data_row("answer")
        ''If opt_true.Checked = True Then
        ''    opt_false.Checked = False
        ''ElseIf opt_true.Checked = False Then
        ''    opt_false.Checked = True
        ''End If

        ''txt_comment.Text = IIf(s_data_row("comment") IsNot DBNull.Value, s_data_row("comment"), "")

    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then  'here we need execute the below during the normal load for the page not the load as result from control like button

            
            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then

                data_row_various = customer_information_class_object.fn_check_hse_checklist_header_record(Session("connection_string"), Now, Session("branch_RecordID"))

                If data_row_various IsNot Nothing Then ' we here has 1 record
                    Session("header_process") = 2 'update
                    'show the data in control
                    Call fill_control_with_data(data_row_various, 1) ' here the record is exist so that we will fill all the control with the all data
                    Session("hse_checklist_header_RecordID") = data_row_various("RecordID") 'to use it in update statment

                Else
                    Session("header_process") = 1 'insert
                    'show the date and branch
                    Call fill_control_with_data(Nothing, 2) ' may be here we will send nothing not ==> data_table_various.Rows(0)

                End If

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If


        End If

    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click


        lnk_btn_next.Enabled = True
        lnk_btn_last.Enabled = True

        opt_false.Enabled = True
        opt_true.Enabled = True
        txt_comment.Enabled = True

        If Session("header_process") = 1 Then ' insert
            Session("hse_checklist_header_RecordID") = customer_information_class_object.fn_hse_checklist_header_add_update_record(Session("connection_string"), Session("branch_RecordID"), Trim(txt_hse_inspector.Text), (txt_emergency_manager.Text), Val(Trim(txt_branch_head_count.Text)), Val(Trim(txt_no_fire_fighting_trainees.Text)), Val(Trim(txt_no_of_aid_trainees.Text)), Session("header_process"), Session("user_RecordID"))
            lbl_result.Text = ("<h4><font color = 'green'>  Thank you the record has been added successfully </font></h4>")
            ' ImageButton1.Enabled = False
        ElseIf Session("header_process") = 2 Then 'update
            customer_information_class_object.fn_hse_checklist_header_add_update_record(Session("connection_string"), Session("branch_RecordID"), Trim(txt_hse_inspector.Text), (txt_emergency_manager.Text), Val(Trim(txt_branch_head_count.Text)), Val(Trim(txt_no_fire_fighting_trainees.Text)), Val(Trim(txt_no_of_aid_trainees.Text)), Session("header_process"), Session("user_RecordID"), Session("hse_checklist_header_RecordID"))
            lbl_result.Text = ("<h4><font color = 'green'> Thank you the record has been updated successfully </font></h4>")
        End If

        'here we will fill the control detail with the first q
        sql = "select top 1 * from hse_checklist_q_view"
        data_row_various = customer_information_class_object.fn_question_information_select_one_record(Session("connection_string"), sql)
        If data_row_various IsNot Nothing Then ' it will never be nothing cause we add and fill manually the q tables
            Session("question_RecordID") = data_row_various("RecordID") ' this is first q we will use this record id==> Session("question_RecordID")for navigation using the sp 
            Session("first_record") = Session("question_RecordID")
            Call fill_control_with_data(data_row_various, 3) '3 means here we will fill the q controls
            Call get_and_show_answer() 'fill the answers of the first q if exist
        End If
        ImageButton1.Enabled = False

        'RequiredFieldValidator36.EnableClientScript = True
        RequiredFieldValidator36.Enabled = True

    End Sub

    Protected Sub lnk_btn_next_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnk_btn_next.Click

        'RequiredFieldValidator36.EnableClientScript = True
        RequiredFieldValidator36.Enabled = True

        ' enabled previous link
        If lnk_btn_previous.Enabled = False Then
            lnk_btn_previous.Enabled = True
        End If

        lnk_btn_First.Enabled = True

        'new 12-8-2015
        If opt_true.Checked <> False Or opt_false.Checked <> False Then
            '  here we will save(insert or update) the current q and answer  in the answer table and then show the next q using the [stp_question_browzing] so that the next click will save the second q and show the third q
            Dim typed_check_list_data_set_object As New typed_check_list_data_set
            Dim typed_check_list_data_row As typed_check_list_data_set.hse_checklist_a_tableRow
            'here answer recordid is auto increment so that i will not add it to Addhse_checklist_a_tableRow()
            typed_check_list_data_row = typed_check_list_data_set_object.hse_checklist_a_table.Addhse_checklist_a_tableRow(Session("hse_checklist_header_RecordID"), Session("question_RecordID"), opt_true.Checked, txt_comment.Text, 1) ' here may be need use cint(opt_true.Checked) to convert true or false to 1 or 0 to send it to bit data type


            If data_row_various IsNot Nothing Then 'update answer record  'here we mean the answer data retrieved from the get_and_show_answer()
                Session("process") = 2
                Session("answer_recordID") = data_row_various("RecordID") 'we will use it in save
                customer_information_class_object.fn_answer_add_update(Session("connection_string"), typed_check_list_data_row, Session("process"), lbl_result_record, Session("answer_recordID"))
                If sender.text <> "Last" Then
                    fill_control_collection() 'reset the answer controls with every next
                End If

            ElseIf data_row_various Is Nothing And (opt_true.Checked <> False Or opt_false.Checked <> False) Then ' insert new answer record

                fill_control_collection()  ' we need reset the answer controls
                Session("process") = 1
                Session("answer_recordID") = customer_information_class_object.fn_answer_add_update(Session("connection_string"), typed_check_list_data_row, Session("process"), lbl_result_record)
            End If

            'show the next q using stp_question_browzing and save the q recordid 
            data_row_various = customer_information_class_object.fn_question_information_select_one_record(Session("connection_string"), 1) '1 mean next

            If data_row_various IsNot Nothing Then
                Session("question_RecordID") = data_row_various("RecordID")
                Call fill_control_with_data(data_row_various, 3) '3 means here we will fill the q controls
                Call get_and_show_answer() 'data_row_various here will fill with the answer record if exist

            ElseIf data_row_various Is Nothing And Session("answer_recordID") >= 1 Then ' when we arrive to the after the last q then we will show the next part of data entry and disabled the next button
                lnk_btn_next.Enabled = False
                lnk_btn_last.Enabled = False
                lbl_hint.Text = ("<h4><font color = 'green'>Thank you this is the last Question</font></h4>")
                txt_comment.Text = "No Comment"
                
            End If

        Else
            lbl_hint.Text = ("<h4><font color = 'red'> YOU DIDN'T ANSWER THIS QUESTION PLEASE ANSWER IT </font></h4>")
        End If



    End Sub

    Public Sub fill_control_collection()
        Dim control_collection As New Collection()
        control_collection.Add(opt_true)
        control_collection.Add(opt_false)
        control_collection.Add(Me.Master.FindControl("ContentPlaceHolder1").FindControl("txt_comment")) 'another way to get the control in case if we use master page
        reset_some_controls(control_collection)

    End Sub

    Public Sub reset_some_controls(ByVal s_control_collection As Collection)

        For Each control As Control In s_control_collection

            If TypeOf control Is TextBox Then
                Dim text_box As TextBox
                'text_box = CType(Control, TextBox)
                text_box = control
                text_box.Text = ""


            ElseIf TypeOf control Is RadioButton Then
                Dim radio_button As RadioButton
                radio_button = control
                radio_button.Checked = False
            End If

        Next
    End Sub

    Protected Sub opt_true_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles opt_true.CheckedChanged
        If opt_true.Checked = True Then
            opt_false.Checked = False

        End If
    End Sub

    Protected Sub opt_false_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles opt_false.CheckedChanged
        If opt_false.Checked = True Then
            opt_true.Checked = False
        End If
    End Sub


    Protected Sub lnk_btn_previous_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnk_btn_previous.Click
        'RequiredFieldValidator36.EnableClientScript = False
        RequiredFieldValidator36.Enabled = False

        lnk_btn_last.Enabled = True
        ' enabled next link
        If lnk_btn_next.Enabled = False Then
            lnk_btn_next.Enabled = True
        End If


        If Session("first_record") = Session("question_RecordID") Then
            lnk_btn_previous.Enabled = False
            Exit Sub
        End If

        'show the previous q and save the q recordid using stp_question_browzing
        data_row_various = customer_information_class_object.fn_question_information_select_one_record(Session("connection_string"), 2) '2 mean previous

        If data_row_various IsNot Nothing Then
            Session("question_RecordID") = data_row_various("RecordID")
            Call fill_control_with_data(data_row_various, 3) '3 means here we will fill the q controls
            ' the last thing i finished is here
            Call get_and_show_answer()

        ElseIf data_row_various Is Nothing And Session("answer_recordID") >= 1 Then ' when we arrive tobefore first q 
            lnk_btn_previous.Enabled = False
            lnk_btn_First.Enabled = False
            lnk_btn_last.Enabled = True
        End If




    End Sub

    Protected Sub lnk_btn_First_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnk_btn_First.Click


        If lnk_btn_last.Enabled = False Then
            lnk_btn_last.Enabled = True
        End If
        lnk_btn_next.Enabled = True
        lnk_btn_First.Enabled = False
        lnk_btn_previous.Enabled = False

        'show the previous q and save the q recordid using stp_question_browzing
        data_row_various = customer_information_class_object.fn_question_information_select_one_record(Session("connection_string"), 3) '2 mean previous
        If data_row_various IsNot Nothing Then
            Session("question_RecordID") = data_row_various("RecordID")
            Call fill_control_with_data(data_row_various, 3) '3 means here we will fill the q controls

            Call get_and_show_answer()
        End If
        lnk_btn_last.Enabled = True
       
    End Sub

    Protected Sub lnk_btn_last_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnk_btn_last.Click
        If lnk_btn_First.Enabled = False Then
            lnk_btn_First.Enabled = True
        End If
        lnk_btn_last.Enabled = False
        lnk_btn_next.Enabled = False
        lnk_btn_previous.Enabled = True

        'show the last q using the sp
        data_row_various = customer_information_class_object.fn_question_information_select_one_record(Session("connection_string"), 4) '2 mean previous
        If data_row_various IsNot Nothing Then
            Session("question_RecordID") = data_row_various("RecordID")
            Call fill_control_with_data(data_row_various, 3) '3 means here we will fill the q controls
            Call get_and_show_answer()
            'Call lnk_btn_next_Click(sender, e)
        End If


    End Sub

    Protected Sub cmd_save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmd_save.Click


        'the below 3 statment used in add only not update
        Dim typed_emergency_data_set_object As New typed_emergency_data_set
        Dim typed_emergency_data_row As typed_emergency_data_set.emergencychart_tableRow
        typed_emergency_data_row = typed_emergency_data_set_object.emergencychart_table.Addemergencychart_tableRow( _
        Session("hse_checklist_header_RecordID"), Trim(txt_e_m_name.Text), txt_e_m_account.Text, txt_e_m_ext.Text, txt_d_e_m_name.Text, _
        txt_d_e_m_account.Text, txt_d_e_m_ext.Text, txt_f_a_name.Text, txt_f_a_account.Text, txt_f_a_ext.Text, txt_evac_m_name_1.Text, _
        txt_evac_m_account_1.Text, txt_evac_m_ext_1.Text, txt_evac_m_name_2.Text, txt_evac_m_account_2.Text, txt_evac_m_ext_2.Text, _
        txt_evac_monitor_name.Text, txt_evac_monitor_account.Text, txt_evac_monitor_ext.Text, txt_f_f_name_1.Text, txt_f_f_account_1.Text, _
        txt_f_f_ext_1.Text, txt_f_f_name_2.Text, txt_f_f_account_2.Text, txt_f_f_ext_2.Text, txt_f_f_name_3.Text, txt_f_f_account_3.Text, _
        txt_f_f_ext_3.Text, txt_f_f_name_4.Text, txt_f_f_account_4.Text, txt_f_f_ext_4.Text)

        
        If Session("emergency_chart_data_row") Is Nothing Then
            Session("emergency_process") = 1
            Session("emergency_RecordID") = customer_information_class_object.fn_emergency_add_update(Session("connection_string"), typed_emergency_data_row, Session("emergency_process"))
            lbl_result_record.Text = ("<h4><font color = 'green'>  Thank you The Record Has Been Added Successfully </font></h4>")
        ElseIf Session("emergency_chart_data_row") IsNot Nothing Then
            Session("emergency_process") = 2
            Session("emergency_RecordID") = Session("emergency_chart_data_row")(("RecordID"))
            customer_information_class_object.fn_emergency_add_update(Session("connection_string"), typed_emergency_data_row, Session("emergency_process"), Session("emergency_RecordID"))
            lbl_result_record.Text = ("<h4><font color = 'green'>  Thank you The Record Has Been Updated Successfully </font></h4>")
        End If
        sql = "update hse_checklist_header_table set authorized = 1 where RecordID = " & Session("hse_checklist_header_RecordID")
        Call customer_information_class_object.s_update_status(Session("connection_string"), sql)
        cmd_save.Enabled = False
    End Sub





End Class
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               