﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class check_lists_maker
    Inherits System.Web.UI.Page
    Dim url As String

    Dim data_set_various As DataSet
    Dim data_row_various As DataRow
    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    'various
    Dim array(0) As String
    Dim command_field As CommandField
    Dim link_field As HyperLinkField

    Dim sql As String

    Protected Sub GridView_check_list_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView_check_list.PageIndexChanging
        GridView_check_list.PageIndex = e.NewPageIndex
        'here i should refill the data set again
        Call fill_grid_view_with_data()
    End Sub

    Protected Sub GridView_check_list_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView_check_list.RowCommand
        If e.CommandName = "Delete" Then

            Dim index As Integer = Convert.ToInt32(e.CommandArgument)

            Dim result_of_function As Boolean

            Session("check_list_RecordID") = GridView_check_list.Rows(index).Cells(0).Text
            result_of_function = customer_information_class_object.fn_check_list_information_Delete(Session("connection_string"))

            If result_of_function = True Then
                lbl_result.Text = ("<h4><font color = 'green'> :) The Record Has Been Deleted Successfully :)</font></h4>")
            Else
                lbl_result.Text = ("<h4><font color = 'red'> :) There Is Error Happened During The Deletion Process <br>The Record Has Not Been Deleted :(</font></h4>")
            End If

        End If
    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button
            

            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))


                Call fill_all_drop_down_list_boxes()

                sql = "select * from hse_checklist_header_View where authorized = 2 order by hse_date desc"
                Call get_all_check_lists_branches_or_1(sql)

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub

    Protected Sub GridView_check_list_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridView_check_list.RowEditing
        'url = System.Configuration.ConfigurationManager.AppSettings("url_add_update_check_list") ' "~/health_and_safty_check_list.aspx?"
        'Response.Redirect(url & "RecordID=" & GridView_check_list.Rows(e.NewEditIndex).Cells(0).Text)
    End Sub
   

    Protected Sub GridView_check_list_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridView_check_list.SelectedIndexChanging
        url = System.Configuration.ConfigurationManager.AppSettings("url_check_list_details")
        Response.Redirect(url & "RecordID=" & GridView_check_list.Rows(e.NewSelectedIndex).Cells(0).Text)
    End Sub

    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub

    Public Sub fill_all_drop_down_list_boxes()

        sql = "SELECT RecordID , name FROM TblBranches"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_branches, "RecordID", "name")

       
    End Sub


    Protected Sub ddl_branches_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_branches.SelectedIndexChanged
        Call fill_grid_view_with_data()

    End Sub

    Public Sub fill_grid_view_with_data()
        If ddl_branches.SelectedIndex = 0 Then 'also we can say  ddl_branches.selecteditem.value = -1
            sql = "select * from hse_checklist_header_View where authorized = 2 order by hse_date desc"
            Call get_all_check_lists_branches_or_1(sql)
        Else
            Session("branch_RecordID") = ddl_branches.SelectedItem.Value
            sql = "select * from hse_checklist_header_View where authorized = 2 and Branch_RecordID = " & Session("branch_RecordID") & " order by hse_date desc"
            Call get_all_check_lists_branches_or_1(sql)
        End If
    End Sub
    Public Sub get_all_check_lists_branches_or_1(ByVal s_sql As String)
        lbl_result.Text = ""
        data_set_various = customer_information_class_object.fn_check_list_information_search(Session("connection_string"), s_sql)
        GridView_check_list.DataSource = data_set_various.Tables("check_list_information_table")
        GridView_check_list.DataBind()
        If data_set_various.Tables("check_list_information_table").Rows.Count = 0 Then
            lbl_result.Visible = True
            lbl_result.Text = "No Data Found !!"
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub
End Class
