﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class cashing
    Inherits System.Web.UI.Page
    Dim url As String

    Dim data_set_various As DataSet
    Dim data_row_various As DataRow
    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    'various
    Dim array(0) As String
    Dim command_field As CommandField
    Dim link_field As HyperLinkField

    Dim sql, data_table_name As String



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button


            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))

                Call refresh_grid_view()

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub

    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub

    

    Public Sub refresh_grid_view()
        If Session("Group_RecordID") = 2 Then ' vault

            Call fill_grid_view(2)

        ElseIf Session("Group_RecordID") = 3 Then ' teller

            Call fill_grid_view(3)

        End If
    End Sub

    
    Public Sub fill_grid_view(Optional ByVal s_sql_types As Integer = 0)
        If s_sql_types = 2 Then 'log in as vault
            sql = "select * from master_transacton_view where   fk_branch_RecordID = " & Session("branch_RecordID") & _
                     " and  destination_RecordID = 2 and authorized = 1 order by date desc"

        ElseIf s_sql_types = 3 Then ' log in as teller 

            sql = "select * from master_transacton_view where direction = 'out' and fk_branch_RecordID = " & Session("branch_RecordID") & _
         " and  destination_RecordID = 3 and destination_user_account = '" & Session("user_login_account") & "' and authorized = 1 order by date desc"


            'sql = "select * from master_transacton_view where fk_branch_RecordID = " & Session("branch_RecordID") & _
            '   " and fk_user_RecordID = " & Session("user_RecordID") & " order by date desc"


        End If


        data_table_name = "master_transacton_view"

        data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, data_table_name)
        If data_set_various IsNot Nothing Then
            GridView_master_transaction.DataSource = data_set_various.Tables(data_table_name)
            GridView_master_transaction.DataBind()
        Else
            GridView_master_transaction.EmptyDataText = "<marquee><h3>There Is No Any Data At The Current Time !!</marquee></h3>"
            lbl_result.Visible = True
            lbl_result.Text = "No Data Found !!"
        End If
    End Sub

    Protected Sub GridView_master_transaction_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView_master_transaction.PageIndexChanging
        GridView_master_transaction.PageIndex = e.NewPageIndex
        Call refresh_grid_view()

    End Sub

    Protected Sub GridView_master_transaction_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridView_master_transaction.SelectedIndexChanging
        url = System.Configuration.ConfigurationManager.AppSettings("url_cashing_details") '"~/cashing_details.aspx?"
        Response.Redirect(url & "RecordID=" & GridView_master_transaction.Rows(e.NewSelectedIndex).Cells(0).Text)
    End Sub

End Class
