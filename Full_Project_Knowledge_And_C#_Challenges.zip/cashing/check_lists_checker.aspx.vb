﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class check_lists_maker
    Inherits System.Web.UI.Page
    Dim url As String

    Dim data_set_various As DataSet
    Dim data_row_various As DataRow
    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    'various
    Dim array(0) As String
    Dim command_field As CommandField
    Dim link_field As HyperLinkField

    Dim sql As String

    Protected Sub GridView_check_list_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView_check_list.PageIndexChanging
        GridView_check_list.PageIndex = e.NewPageIndex
        'here i should refill the data set again
        data_set_various = customer_information_class_object.fn_check_list_information_search(Session("connection_string"), RadioButtonList1.SelectedIndex)
        GridView_check_list.DataSource = data_set_various.Tables("check_list_information_table")
        GridView_check_list.DataBind()
    End Sub

    Protected Sub GridView_check_list_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView_check_list.RowCommand
        If e.CommandName = "Delete" Then

            Dim index As Integer = Convert.ToInt32(e.CommandArgument)

            Dim result_of_function As Boolean

            Session("check_list_RecordID") = GridView_check_list.Rows(index).Cells(0).Text
            result_of_function = customer_information_class_object.fn_check_list_information_Delete(Session("connection_string"))

            If result_of_function = True Then
                lbl_result.Text = ("<h4><font color = 'green'> :) The Record Has Been Deleted Successfully :)</font></h4>")
            Else
                lbl_result.Text = ("<h4><font color = 'red'> :) There Is Error Happened During The Deletion Process <br>The Record Has Not Been Deleted :(</font></h4>")
            End If

        End If
    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button
            

            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub
   

    Protected Sub GridView_check_list_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridView_check_list.SelectedIndexChanging
        url = System.Configuration.ConfigurationManager.AppSettings("url_check_list_details")
        Response.Redirect(url & "RecordID=" & GridView_check_list.Rows(e.NewSelectedIndex).Cells(0).Text & "&authorized=" & GridView_check_list.Rows(e.NewSelectedIndex).Cells(9).Text)
    End Sub

    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub


    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub



    Protected Sub RadioButtonList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        lbl_result.Text = ""
        data_set_various = customer_information_class_object.fn_check_list_information_search(Session("connection_string"), RadioButtonList1.SelectedIndex)
        GridView_check_list.DataSource = data_set_various.Tables("check_list_information_table")
        GridView_check_list.DataBind()
        If data_set_various.Tables("check_list_information_table").Rows.Count = 0 Then
            lbl_result.Visible = True
            lbl_result.Text = "No Data Found !!"
        End If

    End Sub
End Class
