﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class searching
    Inherits System.Web.UI.Page
    Dim url As String

    Dim data_set_various As DataSet
    Dim data_row_various As DataRow
    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    'various
    Dim array(0) As String
    Dim command_field As CommandField
    Dim link_field As HyperLinkField

    Dim sql, data_table_name As String
    Dim from_date, to_date As Date

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button


            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))

                If Session("Group_RecordID") = 3 Then
                    ddl_level.Visible = True
                    Call fill_all_drop_down_list_boxes()
                End If

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub

    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub

    Public Sub fill_all_drop_down_list_boxes()
        sql = "SELECT RecordID , name  FROM  levels_table"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_level, "RecordID", "name")
        GeneralClass.get_data_reader(Session("connection_string"), sql).Close()
    End Sub

    Public Sub refresh_grid_view()
        If Session("Group_RecordID") = 2 Then ' vault
            If txt_from_date.Text = "" Or txt_to_date.Text = "" Then
                Call fill_grid_view(1)
            Else
                Call fill_grid_view(2)
            End If


        ElseIf Session("Group_RecordID") = 3 Then ' teller
            If (txt_from_date.Text = "" Or txt_to_date.Text = "") And ddl_level.SelectedIndex = 0 Then 'no dll no calender
                Call fill_grid_view(3)

            ElseIf (txt_from_date.Text = "" Or txt_to_date.Text = "") And ddl_level.SelectedIndex > 0 Then 'dll only
                Call fill_grid_view(4)

            ElseIf (txt_from_date.Text <> "" And txt_to_date.Text <> "") And ddl_level.SelectedIndex > 0 Then 'dll and calender
                Call fill_grid_view(5)

            ElseIf (txt_from_date.Text <> "" And txt_to_date.Text <> "") And ddl_level.SelectedIndex = 0 Then 'calender no dll
                Call fill_grid_view(6)

            End If
        End If
    End Sub


    Public Sub fill_grid_view(Optional ByVal s_sql_types As Integer = 0)
        If s_sql_types = 1 Then 'log in as volt get all records based on branch
            sql = "select * from master_transacton_view where   fk_branch_RecordID = " & Session("branch_RecordID") & _
                     " and  teller_volt = 2 order by date desc"

        ElseIf s_sql_types = 2 Then  'log in as volt get volt records based on date
            sql = "select * from master_transacton_view where   fk_branch_RecordID = " & Session("branch_RecordID") & _
                     " and  teller_volt = 2  and date between '" & from_date.ToString("dd-MMM-yyyy") & "' and '" & to_date.ToString("dd-MMM-yyyy") & " 23:59:59'"


        ElseIf s_sql_types = 3 Then ' log in as teller get all records related to log in user no choose ddl or calendar
            sql = "select * from master_transacton_view where fk_user_RecordID = " & Session("user_RecordID") & _
                " and  fk_branch_RecordID = " & Session("branch_RecordID") & _
                " and  teller_volt = 3 and fk_user_RecordID = " & Session("user_RecordID") & _
                " order by date desc"


        ElseIf s_sql_types = 4 Then 'log in as teller get records related to log in user and ddl
            sql = "select * from master_transacton_view where fk_user_RecordID = " & Session("user_RecordID") & _
                     " and  fk_branch_RecordID = " & Session("branch_RecordID") & _
                     " and  teller_volt = 3 and (source_RecordID =  " & ddl_level.SelectedItem.Value & _
                     " or destination_RecordID = " & ddl_level.SelectedItem.Value & " ) "


        ElseIf s_sql_types = 5 Then 'log in as teller get records related to log in user and ddl and date
            sql = "select * from master_transacton_view where fk_user_RecordID = " & Session("user_RecordID") & _
                     " and  fk_branch_RecordID = " & Session("branch_RecordID") & _
                     " and  teller_volt = 3" & _
                     " and (source_RecordID =  " & ddl_level.SelectedItem.Value & " or destination_RecordID = " & ddl_level.SelectedItem.Value & _
                     " ) and date between '" & from_date.ToString("dd-MMM-yyyy") & "' and '" & to_date.ToString("dd-MMM-yyyy") & " 23:59:59'"
            'and teller_vault_user_account =  " & Session("user_login_account")


        ElseIf s_sql_types = 6 Then 'log in as teller get records related to log in user and date
            sql = "select * from master_transacton_view where fk_user_RecordID = " & Session("user_RecordID") & _
                     " and  fk_branch_RecordID = " & Session("branch_RecordID") & _
                     " and  teller_volt = 3 and date between '" & from_date.ToString("dd-MMM-yyyy") & "' and '" & to_date.ToString("dd-MMM-yyyy") & " 23:59:59'"

        End If


        data_table_name = "master_transacton_view"

        data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, data_table_name)
        If data_set_various IsNot Nothing Then
            GridView_master_transaction.DataSource = data_set_various.Tables(data_table_name)
            GridView_master_transaction.DataBind()
        Else
            GridView_master_transaction.EmptyDataText = "<marquee><h3>There Is No Any Data At The Current Time !!</marquee></h3>"
            lbl_result.Visible = True
            lbl_result.Text = "No Data Found !!"
        End If
    End Sub

    Protected Sub GridView_master_transaction_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView_master_transaction.PageIndexChanging
        GridView_master_transaction.PageIndex = e.NewPageIndex
        Call refresh_grid_view()

    End Sub

    Protected Sub GridView_master_transaction_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridView_master_transaction.SelectedIndexChanging
        url = System.Configuration.ConfigurationManager.AppSettings("url_cashing_details") '"~/cashing_details.aspx?"
        Response.Redirect(url & "RecordID=" & GridView_master_transaction.Rows(e.NewSelectedIndex).Cells(0).Text)
    End Sub



    Protected Sub cmd_search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmd_search.Click
        If txt_from_date.Text = "" And txt_to_date.Text = "" Then
            from_date = "1/1/1753"
            to_date = "1/1/1753"
        Else
            from_date = Cal_from.SelectedDate
            to_date = cal_to.SelectedDate
        End If

        Call refresh_grid_view()
    End Sub


    Protected Sub Cal_from_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cal_from.SelectionChanged
        from_date = Cal_from.SelectedDate
        'Cal_from.Visible = False
        txt_from_date.Text = Format(from_date, "dd/MM/yyyy")
    End Sub

    Protected Sub cal_to_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cal_to.SelectionChanged
        to_date = cal_to.SelectedDate
        'cal_to.Visible = False
        txt_to_date.Text = Format(to_date, "dd/MM/yyyy")
    End Sub

    Protected Sub ddl_level_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_level.SelectedIndexChanged

    End Sub
End Class
