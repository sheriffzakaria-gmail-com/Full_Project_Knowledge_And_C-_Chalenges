﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class balnces
    Inherits System.Web.UI.Page
    Dim url As String

    Dim data_set_various As DataSet
    Dim data_row_various As DataRow
    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    'various
    Dim array(0) As String
    Dim command_field As CommandField
    Dim link_field As HyperLinkField

    Dim sql, data_table_name As String
    Dim from_date, to_date As Date
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button


            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))

                'get balances
                'Call refresh_detail_view()
                Call refresh_grid_view_generic()

               

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub

    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub

    


    Public Sub fill_grid_view_generic(ByVal s_data_table_name As String, ByVal s_grid_view As GridView, Optional ByVal s_sql_types As Integer = 0)
        If s_sql_types = 2 Then

            sql = "select currency_type AS currency, SUM( CASE " & _
                                "WHEN source_RecordID = 2 THEN total_amount * -1 Else total_amount End)  AS BALANCE " & _
                               "FROM dbo.master_transacton_View " & _
                              "WHERE fk_branch_RecordID = " & Session("branch_RecordID") & " And (source_RecordID = 2 Or destination_RecordID = 2) And authorized = 2 " & _
                              "GROUP BY currency_type"

        ElseIf s_sql_types = 3 Then

            sql = "SELECT currency_type AS currency, SUM( CASE WHEN source_RecordID = 3 " & _
                               "THEN total_amount * -1 " & _
                              "Else total_amount End )  AS BALANCE " & _
                              "FROM dbo.master_transacton_View " & _
                              "WHERE   fk_branch_RecordID = " & Session("branch_RecordID") & " AND (source_RecordID = 3 OR destination_RecordID = 3) " & _
                             "AND (source_user_account =  '" & Session("user_login_account") & "' or destination_user_account = '" & Session("user_login_account") & "' ) AND authorized = 2 " & _
                             "GROUP BY currency_type"
        End If


        data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, s_data_table_name)

        If data_set_various IsNot Nothing Then
            s_grid_view.DataSource = data_set_various.Tables(s_data_table_name)
            s_grid_view.DataBind()

            For Each row As GridViewRow In s_grid_view.Rows
                Dim gridview_template As GridView
                gridview_template = DirectCast(row.FindControl("GridView_balances_category"), GridView)
                If s_sql_types = 2 Then

                    sql = "select currency_type AS currency, SUM( CASE " & _
                                        "WHEN source_RecordID = 2 THEN (individual_amount + backage_amount) * -1 Else (individual_amount + backage_amount) End )  AS BALANCE , category  " & _
                                       "FROM dbo.balnce_currency_category_view " & _
                                      "WHERE fk_branch_RecordID = " & Session("branch_RecordID") & " And (source_RecordID = 2 Or destination_RecordID = 2) And authorized = 2 " & _
                                      "and currency_type = '" & row.Cells(0).Text & "' " & _
                                     "GROUP BY currency_type , category " & _
                                     "ORDER BY currency_type , CAST(category AS FLOAT )"

                ElseIf s_sql_types = 3 Then

                    sql = "SELECT currency_type AS currency, SUM( CASE WHEN source_RecordID = 3 " & _
                                       "THEN (individual_amount + backage_amount) * -1 " & _
                                      "Else (individual_amount + backage_amount) End )  AS BALANCE , category " & _
                                      "FROM dbo.balnce_currency_category_view " & _
                                      "WHERE   fk_branch_RecordID = " & Session("branch_RecordID") & " AND (source_RecordID = 3 OR destination_RecordID = 3) " & _
                                     "AND (source_user_account =  '" & Session("user_login_account") & "' or destination_user_account = '" & Session("user_login_account") & "' ) AND authorized = 2 " & _
                                     "and currency_type = '" & row.Cells(0).Text & "' " & _
                                     "GROUP BY currency_type , category " & _
                                     "ORDER BY currency_type , CAST(category AS FLOAT )"
                End If
                s_data_table_name = "balance_with_category"
                data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, s_data_table_name)
                If data_set_various IsNot Nothing Then
                    gridview_template.DataSource = data_set_various.Tables(s_data_table_name)
                    gridview_template.DataBind()
                Else
                    gridview_template.EmptyDataText = "<marquee><h3>There Is No Any Data At The Current Time !!</marquee></h3>"

                End If


            Next

        Else
            s_grid_view.EmptyDataText = "<marquee><h3>There Is No Any Data At The Current Time !!</marquee></h3>"

        End If

    End Sub

    

   
    'Public Sub refresh_detail_view()
    '    If Session("Group_RecordID") = 2 Then ' vault
    '        Call fill_detail_view(2)
    '    ElseIf Session("Group_RecordID") = 3 Then ' teller
    '        Call fill_detail_view(3)
    '    End If
    'End Sub

    Public Sub refresh_grid_view_generic()
        If Session("Group_RecordID") = 2 Then ' vault
            Call fill_grid_view_generic("get balances", GridView_balances_details, 2)
        ElseIf Session("Group_RecordID") = 3 Then ' teller
            Call fill_grid_view_generic("get balances", GridView_balances_details, 3)
        End If
    End Sub

    'Public Sub fill_detail_view(Optional ByVal s_sql_types As Integer = 0)
    '    If s_sql_types = 2 Then

    '        sql = "select currency_type AS currency, SUM( CASE " & _
    '                            "WHEN source_RecordID = 2 THEN total_amount * -1 Else total_amount End)  AS BALANCE " & _
    '                           "FROM dbo.master_transacton_View " & _
    '                          "WHERE fk_branch_RecordID = " & Session("branch_RecordID") & " And (source_RecordID = 2 Or destination_RecordID = 2) And authorized = 2 " & _
    '                          "GROUP BY currency_type"

    '    ElseIf s_sql_types = 3 Then


    '        sql = "SELECT currency_type AS currency  , SUM( CASE WHEN source_RecordID = 3 " & _
    '                                "THEN total_amount * -1 " & _
    '                               "Else total_amount End )  AS BALANCE " & _
    '                               "FROM dbo.master_transacton_View " & _
    '                               "WHERE   fk_branch_RecordID = " & Session("branch_RecordID") & " AND (source_RecordID = 3 OR destination_RecordID = 3) " & _
    '                              "AND (source_user_account =  " & Session("user_login_account") & " or destination_user_account = " & Session("user_login_account") & ") AND authorized = 2 " & _
    '                              "GROUP BY currency_type"
    '    End If

    '    data_table_name = "get balances"

    '    data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, data_table_name)
    '    If data_set_various IsNot Nothing Then
    '        DetailsView1.DataSource = data_set_various.Tables(data_table_name)
    '        DetailsView1.DataBind()
    '    Else
    '        GridView_balances_details.EmptyDataText = "<h1>No records </h1>"

    '    End If
    'End Sub
    'Protected Sub DetailsView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DetailsViewPageEventArgs) Handles DetailsView1.PageIndexChanging

    '    DetailsView1.PageIndex = e.NewPageIndex
    '    Call refresh_detail_view()

    'End Sub




    


End Class
