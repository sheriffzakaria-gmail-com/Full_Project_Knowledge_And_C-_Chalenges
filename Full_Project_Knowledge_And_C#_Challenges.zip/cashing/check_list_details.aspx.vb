Imports System.Data
Imports system.Data.SqlClient
Imports Microsoft.VisualBasic
Partial Class check_list_details
    Inherits System.Web.UI.Page

    Public Shared connection_string As String
    Public Shared required_connection As String
    Private Shared prevPage As String = String.Empty


    Public data_set_various As DataSet 'here if i will retrieve from the function dataset 
    Dim general_data_table As DataTable
    Public data_row_various As DataRow 'here if i will retrieve from the function just 1 datarow

    Dim data_reader As SqlDataReader 'this data reader to fill drop down list box

    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    Dim sql As String

    Public collection_label, collection_text, collection_opt, collection_opt_false As New Collection


    Public Function prepare_connection(ByVal s_required_connection As String) As String
        Return GeneralClass.GetConnectionString(s_required_connection) 'because GeneralClass under app_code we use it direct without import it in this class
    End Function
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button

            prevPage = "~\" & Request.UrlReferrer.Segments(2)

            Session("hse_checklist_header_RecordID") = Request.QueryString("RecordID")

            If Session("Group_RecordID") = 2 And Request.QueryString("authorized") <> 2 Then ' the sender is checker and this check list need to be authories
                cmd_authorize.Visible = True
                Label1.Visible = True
            End If

            Call prepare_controls_for_data_row(Page.Controls)
            Call control_any_controls(Page.Controls)

        End If
    End Sub

    Public Sub fill_control_with_data(ByVal s_data_table As DataTable, ByVal s_collection_label As Collection, ByVal s_collection_opt As Collection, ByVal s_collection_opt_false As Collection, ByVal s_collection_text As Collection)

        For Each data_row As DataRow In s_data_table.Rows

            s_collection_label(s_data_table.Rows.IndexOf(data_row) + 1).text = data_row("question")

            s_collection_opt(s_data_table.Rows.IndexOf(data_row) + 1).GroupName = ""
            s_collection_opt_false(s_data_table.Rows.IndexOf(data_row) + 1).GroupName = ""

            If data_row("answer") Is DBNull.Value Then
                s_collection_opt(s_data_table.Rows.IndexOf(data_row) + 1).checked = False
                s_collection_opt_false(s_data_table.Rows.IndexOf(data_row) + 1).checked = False
            Else
                s_collection_opt(s_data_table.Rows.IndexOf(data_row) + 1).checked = data_row("answer")
                If s_collection_opt(s_data_table.Rows.IndexOf(data_row) + 1).checked = True Then
                    s_collection_opt_false(s_data_table.Rows.IndexOf(data_row) + 1).checked = False
                Else
                    s_collection_opt_false(s_data_table.Rows.IndexOf(data_row) + 1).checked = True
                End If

            End If

            s_collection_text(s_data_table.Rows.IndexOf(data_row) + 1).text = IIf(data_row("comment") IsNot DBNull.Value, data_row("comment"), "")

        Next


    End Sub

    Public Sub fill_control_with_data(ByVal s_data_row As DataRow)
        'txt_e_m_name.Text = IIf(s_data_row("e_m_name") IsNot DBNull.Value, s_data_row("e_m_name"), "")
        'txt_e_m_account.Text = IIf(s_data_row("e_m_account") IsNot DBNull.Value, s_data_row("e_m_account"), "")
        'txt_e_m_ext.Text = IIf(s_data_row("e_m_ext") IsNot DBNull.Value, s_data_row("e_m_ext"), "")

        'txt_d_e_m_name.Text = IIf(s_data_row("d_e_m_name") IsNot DBNull.Value, s_data_row("d_e_m_name"), "")
        'txt_d_e_m_account.Text = IIf(s_data_row("d_e_m_account") IsNot DBNull.Value, s_data_row("d_e_m_account"), "")
        'txt_d_e_m_ext.Text = IIf(s_data_row("d_e_m_ext") IsNot DBNull.Value, s_data_row("d_e_m_ext"), "")

        'txt_f_a_name.Text = IIf(s_data_row("f_a_name") IsNot DBNull.Value, s_data_row("f_a_name"), "")
        'txt_f_a_account.Text = IIf(s_data_row("f_a_account") IsNot DBNull.Value, s_data_row("f_a_account"), "")
        'txt_f_a_ext.Text = IIf(s_data_row("f_a_ext") IsNot DBNull.Value, s_data_row("f_a_ext"), "")

        'txt_evac_m_name_1.Text = IIf(s_data_row("evac_m_name_1") IsNot DBNull.Value, s_data_row("evac_m_name_1"), "")
        'txt_evac_m_account_1.Text = IIf(s_data_row("evac_m_account_1") IsNot DBNull.Value, s_data_row("evac_m_account_1"), "")
        'txt_evac_m_ext_1.Text = IIf(s_data_row("evac_m_ext_1") IsNot DBNull.Value, s_data_row("evac_m_ext_1"), "")
        'txt_evac_m_name_2.Text = IIf(s_data_row("evac_m_name_2") IsNot DBNull.Value, s_data_row("evac_m_name_2"), "")
        'txt_evac_m_account_2.Text = IIf(s_data_row("evac_m_account_2") IsNot DBNull.Value, s_data_row("evac_m_account_2"), "")
        'txt_evac_m_ext_2.Text = IIf(s_data_row("evac_m_ext_2") IsNot DBNull.Value, s_data_row("evac_m_ext_2"), "")

        'txt_evac_monitor_name.Text = IIf(s_data_row("evac_monitor_name") IsNot DBNull.Value, s_data_row("evac_monitor_name"), "")
        'txt_evac_monitor_account.Text = IIf(s_data_row("evac_monitor_account") IsNot DBNull.Value, s_data_row("evac_monitor_account"), "")
        'txt_evac_monitor_ext.Text = IIf(s_data_row("evac_monitor_ext") IsNot DBNull.Value, s_data_row("evac_monitor_ext"), "")

        'txt_f_f_name_1.Text = IIf(s_data_row("f_f_name_1") IsNot DBNull.Value, s_data_row("f_f_name_1"), "")
        'txt_f_f_account_1.Text = IIf(s_data_row("f_f_account_1") IsNot DBNull.Value, s_data_row("f_f_account_1"), "")
        'txt_f_f_ext_1.Text = IIf(s_data_row("f_f_ext_1") IsNot DBNull.Value, s_data_row("f_f_ext_1"), "")
        'txt_f_f_name_2.Text = IIf(s_data_row("f_f_name_2") IsNot DBNull.Value, s_data_row("f_f_name_2"), "")
        'txt_f_f_account_2.Text = IIf(s_data_row("f_f_account_2") IsNot DBNull.Value, s_data_row("f_f_account_2"), "")
        'txt_f_f_ext_2.Text = IIf(s_data_row("f_f_ext_2") IsNot DBNull.Value, s_data_row("f_f_ext_2"), "")
        'txt_f_f_name_3.Text = IIf(s_data_row("f_f_name_3") IsNot DBNull.Value, s_data_row("f_f_name_3"), "")
        'txt_f_f_account_3.Text = IIf(s_data_row("f_f_account_3") IsNot DBNull.Value, s_data_row("f_f_account_3"), "")
        'txt_f_f_ext_3.Text = IIf(s_data_row("f_f_ext_3") IsNot DBNull.Value, s_data_row("f_f_ext_3"), "")
        'txt_f_f_name_4.Text = IIf(s_data_row("f_f_name_4") IsNot DBNull.Value, s_data_row("f_f_name_4"), "")
        'txt_f_f_account_4.Text = IIf(s_data_row("f_f_account_4") IsNot DBNull.Value, s_data_row("f_f_account_4"), "")
        'txt_f_f_ext_4.Text = IIf(s_data_row("f_f_ext_4") IsNot DBNull.Value, s_data_row("f_f_ext_4"), "")

    End Sub


    Public Sub prepare_controls_for_data_row(ByVal controls As ControlCollection)

        Dim control As Control

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then
                                'MsgBox(ctlContent.ID)
                                For Each ctlpanel As Control In ctlContent.Controls
                                    If TypeOf ctlpanel Is Panel Then
                                        'MsgBox(ctlContent.ID)
                                        For Each control In ctlpanel.Controls

                                            If TypeOf control Is TextBox And InStr(control.ID, "Box") > 0 Then
                                                Dim textbox As TextBox
                                                textbox = control
                                                collection_text.Add(textbox)

                                            ElseIf TypeOf control Is Label And InStr(control.ID, "question") > 0 Then
                                                Dim Label As Label
                                                Label = control
                                                collection_label.Add(Label)


                                            ElseIf TypeOf control Is RadioButton And InStr(control.ID, "true") > 0 Then
                                                Dim RadioButton As RadioButton
                                                RadioButton = control
                                                collection_opt.Add(RadioButton)

                                            ElseIf TypeOf control Is RadioButton And InStr(control.ID, "false") > 0 Then
                                                Dim RadioButton_false As RadioButton
                                                RadioButton_false = control
                                                collection_opt_false.Add(RadioButton_false)


                                            End If
                                        Next control
                                    End If ' pannel
                                Next ' pannel
                            End If
                        Next
                    End If
                Next
            End If
        Next

        'q & a
        general_data_table = customer_information_class_object.fn_check_list_q_a_information(Session("connection_string"))
        If general_data_table IsNot Nothing Then
            Call fill_control_with_data(general_data_table, collection_label, collection_opt, collection_opt_false, collection_text)

            'emergency chart
            ' i stoped it because i make it in new page
            '' ''sql = "select * from emergency_chart_view where fk_check_list_RecordID = " & Session("hse_checklist_header_RecordID")
            '' ''Session("emergency_chart_data_row") = customer_information_class_object.fn_emergency_information_select_one_record(Session("connection_string"), sql)
            '' ''Call fill_control_with_data(Session("emergency_chart_data_row"))
        Else 'hide the authorize controls in case if there is not any data
            cmd_authorize.Visible = False
            Label1.Visible = False
        End If
    End Sub

    Public Sub control_any_controls(ByVal controls As ControlCollection)
        Dim control As Control

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then
                                'MsgBox(ctlContent.ID)
                                For Each ctlpanel As Control In ctlContent.Controls
                                    If TypeOf ctlpanel Is Panel Then
                                        'MsgBox(ctlContent.ID)
                                        For Each control In ctlpanel.Controls

                                            If TypeOf control Is TextBox Then
                                                Dim textbox As TextBox
                                                textbox = control
                                                textbox.Enabled = False
                                            ElseIf TypeOf control Is DropDownList Then
                                                Dim DropDownList As DropDownList
                                                DropDownList = control
                                                DropDownList.Enabled = False

                                            ElseIf TypeOf control Is Label Then
                                                Dim Label As Label
                                                Label = control
                                                Label.Enabled = False

                                            ElseIf TypeOf control Is RadioButton Then
                                                Dim RadioButton As RadioButton
                                                RadioButton = control
                                                RadioButton.Enabled = False

                                            ElseIf TypeOf control Is Calendar Then
                                                Dim calendar As Calendar
                                                calendar = control
                                                calendar.Enabled = False
                                            End If

                                        Next control

                                    End If ' pannel
                                Next ' pannel
                            End If
                        Next
                    End If
                Next
            End If
        Next


    End Sub


    Protected Sub cmd_authorize_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmd_authorize.Click
        sql = "update hse_checklist_header_table set authorized = 2 where RecordID = " & Session("hse_checklist_header_RecordID")
        Call customer_information_class_object.s_update_status(Session("connection_string"), sql)
        Response.Redirect("check_lists_checker.aspx")
    End Sub

    Protected Sub cmd_back_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmd_back.Click

        Response.Redirect(prevPage)

        'Server.Transfer(prevPage) ' "~\" & Request.UrlReferrer.Segments(2))

    End Sub

    Protected Sub opt_true_22_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles opt_true_22.CheckedChanged

    End Sub
End Class
