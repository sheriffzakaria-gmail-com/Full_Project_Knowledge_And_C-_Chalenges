
Partial Class invalid_login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Write("<h2><font color = 'red'>Invalid Login . </br>" & Session("can_not_log_in") & "</br>Please Refer To IT Security</font></h2>")
    End Sub
End Class
