﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class evacuation
    Inherits System.Web.UI.Page
    Dim url As String

    Dim data_set_various As DataSet
    Dim data_row_various As DataRow
    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    'various
    Dim array(0) As String
    Dim command_field As CommandField
    Dim link_field As HyperLinkField

    Dim sql, data_table_name As String

    Protected Sub GridView_evacuation_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView_evacuation.PageIndexChanging
        GridView_evacuation.PageIndex = e.NewPageIndex
        'here i should refill the data set again
        Call fill_grid_view()
    End Sub

    Protected Sub GridView_evacuation_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView_evacuation.RowCommand


        Dim index As Integer = Convert.ToInt32(e.CommandArgument)

        Dim result_of_function As Boolean

        Session("evacuation_recordID") = GridView_evacuation.Rows(index).Cells(0).Text

        If e.CommandName = "Delete" Then
            result_of_function = customer_information_class_object.fn_delete_record_from_grid_view(Session("connection_string"), "stp_delete_record", "emergency_chart_table", Session("emergency_chart_RecordID"))

            If result_of_function = True Then
                lbl_result.Text = ("<h4><font color = 'green'> :) The Record Has Been Deleted Successfully :)</font></h4>")
            Else
                lbl_result.Text = ("<h4><font color = 'red'> :) There Is Error Happened During The Deletion Process <br>The Record Has Not Been Deleted :(</font></h4>")
            End If
        End If

    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button


            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))

                If Session("Group_RecordID") = 3 Then
                    ddl_branches.Visible = True
                    Call fill_all_drop_down_list_boxes()
                    GridView_evacuation.Columns(11).Visible = False
                    GridView_evacuation.Columns(12).Visible = False
                    Call fill_grid_view(2)

                ElseIf Session("Group_RecordID") = 2 Then
                    rbl_authorized.Visible = True
                    GridView_evacuation.Columns(11).Visible = False
                    GridView_evacuation.Columns(12).Visible = False

                ElseIf Session("Group_RecordID") = 1 Then 'maker
                    Call fill_grid_view()
                End If
                
            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub

    Protected Sub GridView_evacuation_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridView_evacuation.RowEditing
        'note when press new link in gridview the querystring count = 0 because 
        Session("process") = 2
        url = System.Configuration.ConfigurationManager.AppSettings("url_add_update_evacuation") ' "~/add_update_emergency_chart.aspx?"
        Response.Redirect(url & "RecordID=" & GridView_evacuation.Rows(e.NewEditIndex).Cells(0).Text)
    End Sub

    Protected Sub GridView_evacuation_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridView_evacuation.SelectedIndexChanging
        url = System.Configuration.ConfigurationManager.AppSettings("url_evacuation_details") '"~/emergency_chart_details.aspx?"
        Response.Redirect(url & "RecordID=" & GridView_evacuation.Rows(e.NewSelectedIndex).Cells(0).Text & "&authorized=" & GridView_evacuation.Rows(e.NewSelectedIndex).Cells(9).Text)
    End Sub

    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub


    Public Sub fill_grid_view(Optional ByVal s_sql_types As Integer = 100) '100 means all 
        If s_sql_types = 0 Then 'checker and unauthorized parameter passed from radio button
            sql = "select * from evacuation_view where authorized = 1 and fk_branch_RecordID = " & Session("branch_RecordID") & " order by date desc"
        ElseIf s_sql_types = 1 Then  'checker and authorized parameter passed from radio button
            sql = "select * from evacuation_view where authorized = 2 and fk_branch_RecordID = " & Session("branch_RecordID") & " order by date desc"
        ElseIf s_sql_types = 2 Then 'log in as cres and see all branches
            sql = "select * from evacuation_view where authorized = 2 order by date desc"
        ElseIf s_sql_types = 3 Then ' log in as cres and see specific branch
            sql = "select * from evacuation_view where authorized = 2 and fk_branch_RecordID = " & Session("branch_RecordID") & " order by date desc"

        Else 'all records during the load or log in as maker based on specific branch
            sql = "select * from evacuation_view where  fk_branch_RecordID = " & Session("branch_RecordID") & " order by date desc"
        End If

        data_table_name = "evacuation_table"

        data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, data_table_name)

        If data_set_various IsNot Nothing Then

            GridView_evacuation.DataSource = data_set_various.Tables(data_table_name)
            GridView_evacuation.DataBind()

        Else
            lbl_result.Visible = True
            lbl_result.Text = "No Data Found !!"
        End If


    End Sub


    Protected Sub rbl_authorized_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbl_authorized.SelectedIndexChanged
        Call fill_grid_view(rbl_authorized.SelectedIndex)
    End Sub

    Public Sub fill_all_drop_down_list_boxes()

        sql = "SELECT RecordID , name FROM TblBranches"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_branches, "RecordID", "name")


    End Sub

    Protected Sub ddl_branches_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_branches.SelectedIndexChanged
        If ddl_branches.SelectedIndex = 0 Then 'also we can say  ddl_branches.selecteditem.value = -1
            Call fill_grid_view(2)


        Else
            Session("branch_RecordID") = ddl_branches.SelectedItem.Value
            Call fill_grid_view(3)


        End If
    End Sub
End Class
