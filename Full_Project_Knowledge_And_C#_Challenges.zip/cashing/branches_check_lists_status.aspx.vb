﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Drawing

Partial Class branches_check_lists_status
    Inherits System.Web.UI.Page
    Dim url As String

    Dim data_set_various As DataSet
    Dim data_row_various As DataRow
    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    'various
    Dim array(0) As String
    Dim command_field As CommandField
    Dim link_field As HyperLinkField

    Dim sql As String
    Dim data_table_name As String

    Protected Sub GridView_branches_check_lists_status_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView_branches_check_lists_status.PageIndexChanging

        GridView_branches_check_lists_status.PageIndex = e.NewPageIndex
        'here i should refill the data set again
        sql = "select * from Branch_check_list_status_view"
        data_table_name = "branches_check_lists_status_table"
        data_set_various = customer_information_class_object.fn_get_data_for_grid_view(Session("connection_string"), sql, data_table_name)
        GridView_branches_check_lists_status.DataSource = data_set_various.Tables(data_table_name)
        GridView_branches_check_lists_status.DataBind()
    End Sub

    


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button


            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))



                sql = "select * from Branch_check_list_status_view"
                data_table_name = "branches_check_lists_status_table"
                data_set_various = customer_information_class_object.fn_get_data_for_grid_view(Session("connection_string"), sql, data_table_name)
                GridView_branches_check_lists_status.DataSource = data_set_various.Tables(data_table_name)
                GridView_branches_check_lists_status.DataBind()



            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub

    Protected Sub GridView_branches_check_lists_status_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView_branches_check_lists_status.RowDataBound
    
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim status As String = e.Row.Cells(6).Text
            Select Case status
                Case "Old"
                    e.Row.BackColor = Color.Aqua
                Case "Waiting"
                    e.Row.BackColor = Color.Beige
                Case "Done"
                    e.Row.BackColor = Color.GreenYellow
                Case "Lating"
                    e.Row.BackColor = Color.Red
            End Select
        End If


    End Sub




    Protected Sub GridView_branches_check_lists_status_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridView_branches_check_lists_status.RowEditing
        'url = System.Configuration.ConfigurationManager.AppSettings("url_add_update_check_list") ' "~/health_and_safty_check_list.aspx?"
        'Response.Redirect(url & "RecordID=" & GridView_branches_check_lists_status.Rows(e.NewEditIndex).Cells(0).Text)
    End Sub

    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub
End Class
