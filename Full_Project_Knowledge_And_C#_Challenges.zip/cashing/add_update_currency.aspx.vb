﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class add_update_currency
    Inherits System.Web.UI.Page
    Public Shared connection_string As String
    Public Shared required_connection As String


    Public data_set_various As DataSet 'here if i will retrieve from the function dataset 
    Public data_row_various As DataRow 'here if i will retrieve from the function just 1 datarow

    Dim data_reader As SqlDataReader 'this data reader to fill drop down list box
    'Dim data_table As DataTable

    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    Dim sql, data_table_name As String

    'Public individual_amount, total_individual As Double
    'Public backage_amount, total_backage As Double
    'Public total_amount As Double

    Public Function prepare_connection(ByVal s_required_connection As String) As String
        Return GeneralClass.GetConnectionString(s_required_connection) 'because GeneralClass under app_code we use it direct without import it in this class
    End Function


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then

            Session("user_login_account") = GeneralClass.get_user_login_account()
            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                lbl_branch_name.Text = Session("branch_name")
                lbl_group.Text = Session("Group_name")

                If Request.QueryString.Count = 0 Then 'here in case we add new contract not update
                    Session("process") = 1
                End If

                If Session("process") = 1 Then
                    cmd_add_update.Text = "Submit Amount"
                    cmd_add_update.CommandName = "ADD"

                ElseIf Session("process") = 2 Then
                    'cmd_add_update.Text = "Update Data"
                    'cmd_add_update.CommandName = "UPDATE"
                    'Session("evacuation_recordID") = Request.QueryString("RecordID")
                    'sql = "select * from evacuation_table where RecordID = " & Session("evacuation_recordID")
                    'data_table_name = "evacuation_table"
                    'data_row_various = customer_information_class_object.fn_select_one_record(Session("connection_string"), sql, data_table_name)
                    'Call fill_control_with_data(data_row_various)

                End If


                If Session("Group_RecordID") = 2 Then 'vault then out only to teller only
                    rbl_direction.Items(0).Enabled = False
                    rbl_direction.Items(1).Selected = True
                    txt_source.Visible = True
                    txt_source.Text = "Teller"

                    ddl_currency.Enabled = True

                    td_account.Visible = True
                    ddl_user_account.Visible = True 'to make vault select teller user account 

                    ddl_source_target.Visible = False
                    td_from_to.InnerText = "TO"

                End If

                Call fill_all_drop_down_list_boxes()

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If

    End Sub

    Protected Sub cmd_add_update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmd_add_update.Click
        Dim control_collection As Collection
        Dim quantity_individual_amount, quantity_backage_amount As Integer

        control_collection = fill_control_collection()


        If Session("process") = 1 Then 'in case if we add the record we need to reset the data after inserting the record
            Session("master_transaction_record") = customer_information_class_object.fn_add_update_cashing_master(Session("connection_string"), Session("user_RecordID"), Session("branch_RecordID"), Session("Group_RecordID"), control_collection, Session("total_amount"), Session("Group_RecordID"), Session("process"))

            For Each row As GridViewRow In Gridview1.Rows
                Dim textbox_1, textbox_2, textbox_3, textbox_4 As TextBox

                textbox_1 = DirectCast(row.FindControl("TextBox1"), TextBox)
                textbox_2 = DirectCast(row.FindControl("TextBox2"), TextBox)

                If Trim(textbox_1.Text) <> "" And Trim(textbox_1.Text) <> "0" Then

                    Session("individual_amount") = CDbl(textbox_1.Text) * CDbl(Session("data_table").Rows(row.RowIndex)(0))
                    quantity_individual_amount = CDbl(textbox_1.Text)
                Else
                    quantity_individual_amount = 0
                    Session("individual_amount") = 0
                End If

                textbox_3 = DirectCast(row.FindControl("TextBox3"), TextBox)
                textbox_4 = DirectCast(row.FindControl("TextBox4"), TextBox)

                If Trim(textbox_3.Text) <> "" And Trim(textbox_3.Text) <> "0" Then
                    Session("backage_amount") = CDbl(textbox_3.Text) * CDbl(Session("data_table").Rows(row.RowIndex)(0)) * 100
                    quantity_backage_amount = CDbl(textbox_3.Text)
                Else
                    quantity_backage_amount = 0
                    Session("backage_amount") = 0
                End If

                Session("detail_transaction_record") = customer_information_class_object.fn_add_update_cashing_detail(Session("connection_string"), Session("master_transaction_record"), Session("data_table").Rows(row.RowIndex)(1), quantity_individual_amount, Session("individual_amount"), quantity_backage_amount, Session("backage_amount"), Session("process"))
            Next


            lbl_result.Text = ("<h4><font color = 'green'> :) The Record Has Been Added Successfully :)</font></h4>")
            Call reset_any_controls(Page.Controls)
            reset_text_box_template_in_gridview(Gridview1)
            cmd_add_update.Enabled = False

        ElseIf Session("process") = 2 Then
            'customer_information_class_object.fn_add_update_evacuation(Session("connection_string"), Session("branch_RecordID"), control_collection, Session("user_RecordID"), Session("process"), Session("evacuation_recordID"))
            'lbl_result.Text = ("<h4><font color = 'green'> :) The Record Has Been Updated Successfully :)</font></h4>")
        End If

    End Sub

    Public Sub fill_all_drop_down_list_boxes()

        'sql = "SELECT RecordID , name FROM TblBranches"
        'Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_branches, "RecordID", "name")

        sql = "SELECT RecordID , name  FROM  currency_type_table"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_currency, "RecordID", "name")

        If Session("Group_RecordID") = 2 Then
            sql = "SELECT RecordID , useraccount  FROM  v_users where Group_RecordID = 3 and Branch_RecordID = " & Session("branch_RecordID")
            Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_user_account, "RecordID", "useraccount")

            sql = "SELECT RecordID , name  FROM  levels_table where RecordID = 3 "  'vault out to branch (teller)
        Else
            sql = "SELECT RecordID , name  FROM  levels_table"
        End If
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_source_target, "RecordID", "name")

       
        GeneralClass.get_data_reader(Session("connection_string"), sql).Close()
    End Sub
    Public Sub fill_control_with_data(ByVal s_data_row As DataRow)
        'ddl_source.SelectedItem.Text = Session("branch_name")

        ''Group A
        'txt_source.Text = IIf(s_data_row("a_address") IsNot DBNull.Value, s_data_row("a_address"), "")
        'txt_a_floors_number.Text = IIf(s_data_row("a_floors_number") IsNot DBNull.Value, s_data_row("a_floors_number"), "")
        'txt_a_emoloyees_number.Text = IIf(s_data_row("a_emoloyees_number") IsNot DBNull.Value, s_data_row("a_emoloyees_number"), "")
        'txt_a_designated_assemply_point.Text = IIf(s_data_row("a_designated_assemply_point") IsNot DBNull.Value, s_data_row("a_designated_assemply_point"), "")
        'txt_a_alternative_assemply_point.Text = IIf(s_data_row("a_alternative_assemply_point") IsNot DBNull.Value, s_data_row("a_alternative_assemply_point"), "")

        'If s_data_row("a_elevator_available") Is DBNull.Value Then
        '    rbl_direction.Items(0).Selected = False
        '    rbl_direction.Items(1).Selected = False
        'ElseIf s_data_row("a_elevator_available") = True Then
        '    rbl_direction.Items(0).Selected = True
        '    rbl_direction.Items(1).Selected = False
        'ElseIf s_data_row("a_elevator_available") = False Then
        '    rbl_direction.Items(0).Selected = False
        '    rbl_direction.Items(1).Selected = True
        'End If

        'If s_data_row("a_usage_elevator_emergency") Is DBNull.Value Then
        '    rbl_a_usage_elevator_emergency.Items(0).Selected = False
        '    rbl_a_usage_elevator_emergency.Items(1).Selected = False
        'ElseIf s_data_row("a_usage_elevator_emergency") = True Then
        '    rbl_a_usage_elevator_emergency.Items(0).Selected = True
        '    rbl_a_usage_elevator_emergency.Items(1).Selected = False
        'ElseIf s_data_row("a_usage_elevator_emergency") = False Then
        '    rbl_a_usage_elevator_emergency.Items(0).Selected = False
        '    rbl_a_usage_elevator_emergency.Items(1).Selected = True
        'End If


        ''Group B
        'Cal_evacuation_date.SelectedDate = s_data_row("b_evacuation_date")
        'txt_evacuation_date.Text = IIf(s_data_row("b_evacuation_date") IsNot DBNull.Value, s_data_row("b_evacuation_date"), "") ' i used in stored procedure convert(varchar(10), CAST( [Insurance_starting_date] as Insurance_starting_date  ),103)   ' old use CStr(Cal_Insurance_starting_date.SelectedDate.Day) & "/" & CStr(Cal_Insurance_starting_date.SelectedDate.Month) & "/" & Cal_Insurance_starting_date.SelectedDate.Year

        'ddl_currency.SelectedValue = IIf(s_data_row("b_emergency_situation") IsNot DBNull.Value, s_data_row("b_emergency_situation"), "-1")
        'txt_b_evacuation_duration.Text = IIf(s_data_row("b_evacuation_duration") IsNot DBNull.Value, s_data_row("b_evacuation_duration"), "")

        'If s_data_row("b_evacuation_panic") Is DBNull.Value Then
        '    rbl_b_evacuation_panic.Items(0).Selected = False
        '    rbl_b_evacuation_panic.Items(1).Selected = False
        'ElseIf s_data_row("b_evacuation_panic") = True Then
        '    rbl_b_evacuation_panic.Items(0).Selected = True
        '    rbl_b_evacuation_panic.Items(1).Selected = False
        'ElseIf s_data_row("b_evacuation_panic") = False Then
        '    rbl_b_evacuation_panic.Items(0).Selected = False
        '    rbl_b_evacuation_panic.Items(1).Selected = True
        'End If

        'If s_data_row("b_disability_person") Is DBNull.Value Then
        '    rbl_b_disability_person.Items(0).Selected = False
        '    rbl_b_disability_person.Items(1).Selected = False
        'ElseIf s_data_row("b_disability_person") = True Then
        '    rbl_b_disability_person.Items(0).Selected = True
        '    rbl_b_disability_person.Items(1).Selected = False
        'ElseIf s_data_row("b_disability_person") = False Then
        '    rbl_b_disability_person.Items(0).Selected = False
        '    rbl_b_disability_person.Items(1).Selected = True
        'End If

        'If s_data_row("b_assembly_area") Is DBNull.Value Then
        '    rbl_b_assembly_area.Items(0).Selected = False
        '    rbl_b_assembly_area.Items(1).Selected = False
        'ElseIf s_data_row("b_assembly_area") = True Then
        '    rbl_b_assembly_area.Items(0).Selected = True
        '    rbl_b_assembly_area.Items(1).Selected = False
        'ElseIf s_data_row("b_assembly_area") = False Then
        '    rbl_b_assembly_area.Items(0).Selected = False
        '    rbl_b_assembly_area.Items(1).Selected = True
        'End If

        'If s_data_row("b_attendees_area") Is DBNull.Value Then
        '    rbl_b_attendees_area.Items(0).Selected = False
        '    rbl_b_attendees_area.Items(1).Selected = False
        'ElseIf s_data_row("b_attendees_area") = True Then
        '    rbl_b_attendees_area.Items(0).Selected = True
        '    rbl_b_attendees_area.Items(1).Selected = False
        'ElseIf s_data_row("b_attendees_area") = False Then
        '    rbl_b_attendees_area.Items(0).Selected = False
        '    rbl_b_attendees_area.Items(1).Selected = True
        'End If


        ''Group C
        'txt_c_emergency_manager_name.Text = IIf(s_data_row("c_emergency_manager_name") IsNot DBNull.Value, s_data_row("c_emergency_manager_name"), "")
        'txt_c_emergency_manager_deputy.Text = IIf(s_data_row("c_emergency_manager_deputy") IsNot DBNull.Value, s_data_row("c_emergency_manager_deputy"), "")

        'If s_data_row("c_ensure_evacuation") Is DBNull.Value Then
        '    rbl_c_ensure_evacuation.Items(0).Selected = False
        '    rbl_c_ensure_evacuation.Items(1).Selected = False
        'ElseIf s_data_row("c_ensure_evacuation") = True Then
        '    rbl_c_ensure_evacuation.Items(0).Selected = True
        '    rbl_c_ensure_evacuation.Items(1).Selected = False
        'ElseIf s_data_row("c_ensure_evacuation") = False Then
        '    rbl_c_ensure_evacuation.Items(0).Selected = False
        '    rbl_c_ensure_evacuation.Items(1).Selected = True
        'End If

        'If s_data_row("c_coloured_hats") Is DBNull.Value Then
        '    rbl_c_coloured_hats.Items(0).Selected = False
        '    rbl_c_coloured_hats.Items(1).Selected = False
        'ElseIf s_data_row("c_coloured_hats") = True Then
        '    rbl_c_coloured_hats.Items(0).Selected = True
        '    rbl_c_coloured_hats.Items(1).Selected = False
        'ElseIf s_data_row("c_coloured_hats") = False Then
        '    rbl_c_coloured_hats.Items(0).Selected = False
        '    rbl_c_coloured_hats.Items(1).Selected = True
        'End If

        'If s_data_row("c_ohs_team") Is DBNull.Value Then
        '    rbl_c_ohs_team.Items(0).Selected = False
        '    rbl_c_ohs_team.Items(1).Selected = False
        'ElseIf s_data_row("c_ohs_team") = True Then
        '    rbl_c_ohs_team.Items(0).Selected = True
        '    rbl_c_ohs_team.Items(1).Selected = False
        'ElseIf s_data_row("c_ohs_team") = False Then
        '    rbl_c_ohs_team.Items(0).Selected = False
        '    rbl_c_ohs_team.Items(1).Selected = True
        'End If

        'If s_data_row("c_evacuation_up_to_date") Is DBNull.Value Then
        '    rbl_c_evacuation_up_to_date.Items(0).Selected = False
        '    rbl_c_evacuation_up_to_date.Items(1).Selected = False
        'ElseIf s_data_row("c_evacuation_up_to_date") = True Then
        '    rbl_c_evacuation_up_to_date.Items(0).Selected = True
        '    rbl_c_evacuation_up_to_date.Items(1).Selected = False
        'ElseIf s_data_row("c_evacuation_up_to_date") = False Then
        '    rbl_c_evacuation_up_to_date.Items(0).Selected = False
        '    rbl_c_evacuation_up_to_date.Items(1).Selected = True
        'End If

        ''group D

        'If s_data_row("d_evacuation_alarm") Is DBNull.Value Then
        '    rbl_d_evacuation_alarm.Items(0).Selected = False
        '    rbl_d_evacuation_alarm.Items(1).Selected = False
        'ElseIf s_data_row("d_evacuation_alarm") = True Then
        '    rbl_d_evacuation_alarm.Items(0).Selected = True
        '    rbl_d_evacuation_alarm.Items(1).Selected = False
        'ElseIf s_data_row("d_evacuation_alarm") = False Then
        '    rbl_d_evacuation_alarm.Items(0).Selected = False
        '    rbl_d_evacuation_alarm.Items(1).Selected = True
        'End If

        'If s_data_row("d_clear_instruction") Is DBNull.Value Then
        '    rbl_d_clear_instruction.Items(0).Selected = False
        '    rbl_d_clear_instruction.Items(1).Selected = False
        'ElseIf s_data_row("d_clear_instruction") = True Then
        '    rbl_d_clear_instruction.Items(0).Selected = True
        '    rbl_d_clear_instruction.Items(1).Selected = False
        'ElseIf s_data_row("d_clear_instruction") = False Then
        '    rbl_d_clear_instruction.Items(0).Selected = False
        '    rbl_d_clear_instruction.Items(1).Selected = True
        'End If

        'If s_data_row("d_card_access_door") Is DBNull.Value Then
        '    rbl_d_card_access_door.Items(0).Selected = False
        '    rbl_d_card_access_door.Items(1).Selected = False
        'ElseIf s_data_row("d_card_access_door") = True Then
        '    rbl_d_card_access_door.Items(0).Selected = True
        '    rbl_d_card_access_door.Items(1).Selected = False
        'ElseIf s_data_row("d_card_access_door") = False Then
        '    rbl_d_card_access_door.Items(0).Selected = False
        '    rbl_d_card_access_door.Items(1).Selected = True
        'End If

        'If s_data_row("d_emergency_exit_unobstructed") Is DBNull.Value Then
        '    rbl_d_emergency_exit_unobstructed.Items(0).Selected = False
        '    rbl_d_emergency_exit_unobstructed.Items(1).Selected = False
        'ElseIf s_data_row("d_emergency_exit_unobstructed") = True Then
        '    rbl_d_emergency_exit_unobstructed.Items(0).Selected = True
        '    rbl_d_emergency_exit_unobstructed.Items(1).Selected = False
        'ElseIf s_data_row("d_emergency_exit_unobstructed") = False Then
        '    rbl_d_emergency_exit_unobstructed.Items(0).Selected = False
        '    rbl_d_emergency_exit_unobstructed.Items(1).Selected = True
        'End If

        'If s_data_row("d_signs_visible") Is DBNull.Value Then
        '    rbl_d_signs_visible.Items(0).Selected = False
        '    rbl_d_signs_visible.Items(1).Selected = False
        'ElseIf s_data_row("d_signs_visible") = True Then
        '    rbl_d_signs_visible.Items(0).Selected = True
        '    rbl_d_signs_visible.Items(1).Selected = False
        'ElseIf s_data_row("d_signs_visible") = False Then
        '    rbl_d_signs_visible.Items(0).Selected = False
        '    rbl_d_signs_visible.Items(1).Selected = True
        'End If

        'If s_data_row("d_security_perform") Is DBNull.Value Then
        '    rbl_d_security_perform.Items(0).Selected = False
        '    rbl_d_security_perform.Items(1).Selected = False
        'ElseIf s_data_row("d_security_perform") = True Then
        '    rbl_d_security_perform.Items(0).Selected = True
        '    rbl_d_security_perform.Items(1).Selected = False
        'ElseIf s_data_row("d_security_perform") = False Then
        '    rbl_d_security_perform.Items(0).Selected = False
        '    rbl_d_security_perform.Items(1).Selected = True
        'End If

        ''Group E

        'If s_data_row("e_bulding_service") Is DBNull.Value Then
        '    rbl_e_bulding_service.Items(0).Selected = False
        '    rbl_e_bulding_service.Items(1).Selected = False
        'ElseIf s_data_row("e_bulding_service") = True Then
        '    rbl_e_bulding_service.Items(0).Selected = True
        '    rbl_e_bulding_service.Items(1).Selected = False
        'ElseIf s_data_row("e_bulding_service") = False Then
        '    rbl_e_bulding_service.Items(0).Selected = False
        '    rbl_e_bulding_service.Items(1).Selected = True
        'End If

        'If s_data_row("e_maintainance") Is DBNull.Value Then
        '    rbl_e_maintainance.Items(0).Selected = False
        '    rbl_e_maintainance.Items(1).Selected = False
        'ElseIf s_data_row("e_maintainance") = True Then
        '    rbl_e_maintainance.Items(0).Selected = True
        '    rbl_e_maintainance.Items(1).Selected = False
        'ElseIf s_data_row("e_maintainance") = False Then
        '    rbl_e_maintainance.Items(0).Selected = False
        '    rbl_e_maintainance.Items(1).Selected = True
        'End If

        'If s_data_row("e_bsis") Is DBNull.Value Then
        '    rbl_e_bsis.Items(0).Selected = False
        '    rbl_e_bsis.Items(1).Selected = False
        'ElseIf s_data_row("e_bsis") = True Then
        '    rbl_e_bsis.Items(0).Selected = True
        '    rbl_e_bsis.Items(1).Selected = False
        'ElseIf s_data_row("e_bsis") = False Then
        '    rbl_e_bsis.Items(0).Selected = False
        '    rbl_e_bsis.Items(1).Selected = True
        'End If

        'If s_data_row("e_emergency_service") Is DBNull.Value Then
        '    rbl_e_emergency_service.Items(0).Selected = False
        '    rbl_e_emergency_service.Items(1).Selected = False
        'ElseIf s_data_row("e_emergency_service") = True Then
        '    rbl_e_emergency_service.Items(0).Selected = True
        '    rbl_e_emergency_service.Items(1).Selected = False
        'ElseIf s_data_row("e_emergency_service") = False Then
        '    rbl_e_emergency_service.Items(0).Selected = False
        '    rbl_e_emergency_service.Items(1).Selected = True
        'End If

        'If s_data_row("e_fire_brigade") Is DBNull.Value Then
        '    rbl_e_fire_brigade.Items(0).Selected = False
        '    rbl_e_fire_brigade.Items(1).Selected = False
        'ElseIf s_data_row("e_fire_brigade") = True Then
        '    rbl_e_fire_brigade.Items(0).Selected = True
        '    rbl_e_fire_brigade.Items(1).Selected = False
        'ElseIf s_data_row("e_fire_brigade") = False Then
        '    rbl_e_fire_brigade.Items(0).Selected = False
        '    rbl_e_fire_brigade.Items(1).Selected = True
        'End If

        'If s_data_row("e_ambulance") Is DBNull.Value Then
        '    rbl_e_ambulance.Items(0).Selected = False
        '    rbl_e_ambulance.Items(1).Selected = False
        'ElseIf s_data_row("e_ambulance") = True Then
        '    rbl_e_ambulance.Items(0).Selected = True
        '    rbl_e_ambulance.Items(1).Selected = False
        'ElseIf s_data_row("e_ambulance") = False Then
        '    rbl_e_ambulance.Items(0).Selected = False
        '    rbl_e_ambulance.Items(1).Selected = True
        'End If

        'If s_data_row("e_police") Is DBNull.Value Then
        '    rbl_e_police.Items(0).Selected = False
        '    rbl_e_police.Items(1).Selected = False
        'ElseIf s_data_row("e_police") = True Then
        '    rbl_e_police.Items(0).Selected = True
        '    rbl_e_police.Items(1).Selected = False
        'ElseIf s_data_row("e_police") = False Then
        '    rbl_e_police.Items(0).Selected = False
        '    rbl_e_police.Items(1).Selected = True
        'End If

        'txt_emergency_manager_name.Text = IIf(s_data_row("emergency_manager_name") IsNot DBNull.Value, s_data_row("emergency_manager_name"), "")
        'txt_emergency_manager_signature.Text = IIf(s_data_row("emergency_manager_signature") IsNot DBNull.Value, s_data_row("emergency_manager_signature"), "")


    End Sub

    Protected Sub cmd_back_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmd_back.Click
        Response.Redirect("home_page.aspx")
    End Sub



    Public Sub reset_any_controls(ByVal controls As ControlCollection)
        Dim control As Control

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then
                                'MsgBox(ctlContent.ID)
                                For Each control In ctlContent.Controls
                                    'MsgBox(control.ID)
                                    ' Do work...
                                    If TypeOf control Is TextBox Then
                                        Dim textbox As TextBox
                                        textbox = control
                                        textbox.Text = ""

                                        'ElseIf TypeOf control Is Label Then ' i stoped the label to show lbl_result.Text = ("<h4><font color = 'green'> :) The Record Has Been Added Successfully :)</font></h4>")
                                        '    Dim label As Label
                                        '    label = control
                                        '    label.Text = ""

                                    ElseIf TypeOf control Is CheckBox Then
                                        Dim CheckBox As CheckBox
                                        CheckBox = control
                                        CheckBox.Checked = False

                                    ElseIf TypeOf control Is DropDownList Then
                                        Dim DropDownList As DropDownList
                                        DropDownList = control
                                        DropDownList.SelectedIndex = -1

                                    ElseIf TypeOf control Is RadioButtonList Then
                                        Dim RadioButtonList As RadioButtonList
                                        RadioButtonList = control
                                        For Each item As ListItem In RadioButtonList.Items
                                            item.Selected = False
                                        Next

                                    ElseIf TypeOf control Is Panel Then
                                        For Each conntrol_in_panel As Control In control.Controls
                                            If TypeOf conntrol_in_panel Is TextBox Then
                                                Dim textbox As TextBox
                                                textbox = conntrol_in_panel
                                                textbox.Text = ""

                                            ElseIf TypeOf conntrol_in_panel Is Label Then ' i stoped the label to show lbl_result.Text = ("<h4><font color = 'green'> :) The Record Has Been Added Successfully :)</font></h4>")
                                                Dim label As Label
                                                label = conntrol_in_panel
                                                label.Text = ""

                                            ElseIf TypeOf conntrol_in_panel Is CheckBox Then
                                                Dim CheckBox As CheckBox
                                                CheckBox = conntrol_in_panel
                                                CheckBox.Checked = False

                                            ElseIf TypeOf conntrol_in_panel Is DropDownList Then
                                                Dim DropDownList As DropDownList
                                                DropDownList = conntrol_in_panel
                                                DropDownList.SelectedIndex = -1

                                            ElseIf TypeOf conntrol_in_panel Is RadioButtonList Then
                                                Dim RadioButtonList As RadioButtonList
                                                RadioButtonList = conntrol_in_panel
                                                For Each item As ListItem In RadioButtonList.Items
                                                    item.Selected = False
                                                Next item
                                            End If

                                        Next conntrol_in_panel


                                    End If
                                Next control

                            End If
                        Next
                    End If
                Next
            End If
        Next


    End Sub
    Public Sub reset_text_box_template_in_gridview(ByVal s_gridview As GridView)
        For Each row As GridViewRow In s_gridview.Rows
      
            DirectCast(row.FindControl("TextBox1"), TextBox).Text = ""
            DirectCast(row.FindControl("TextBox2"), TextBox).Text = ""
            DirectCast(row.FindControl("TextBox3"), TextBox).Text = ""
            DirectCast(row.FindControl("TextBox4"), TextBox).Text = ""

        Next

        DirectCast(Gridview1.FooterRow.FindControl("txt_total_individual"), TextBox).Text = ""
        DirectCast(Gridview1.FooterRow.FindControl("txt_total_backage"), TextBox).Text = ""
    End Sub




    Public Function fill_control_collection() As Collection
        Dim control_collection As New Collection()


        Dim control As Control

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then
                                'MsgBox(ctlContent.ID)
                                For Each control_in_placeholder As Control In ctlContent.Controls 'content place holder
                                    If TypeOf control_in_placeholder Is TextBox Then
                                        Dim textbox As TextBox
                                        textbox = control_in_placeholder
                                        control_collection.Add(textbox, textbox.ID)

                                    ElseIf TypeOf control_in_placeholder Is CheckBox Then
                                        Dim CheckBox As CheckBox
                                        CheckBox = control_in_placeholder
                                        control_collection.Add(CheckBox, CheckBox.ID)

                                    ElseIf TypeOf control_in_placeholder Is RadioButtonList Then
                                        Dim RadioButtonList As RadioButtonList
                                        RadioButtonList = control_in_placeholder
                                        control_collection.Add(RadioButtonList, RadioButtonList.ID)

                                    ElseIf TypeOf control_in_placeholder Is DropDownList Then
                                        Dim DropDownList As DropDownList
                                        DropDownList = control_in_placeholder
                                        control_collection.Add(DropDownList, DropDownList.ID)

                                    ElseIf TypeOf control_in_placeholder Is RadioButton Then
                                        Dim RadioButton As RadioButton
                                        RadioButton = control_in_placeholder
                                        control_collection.Add(RadioButton)

                                    ElseIf TypeOf control_in_placeholder Is Calendar Then
                                        Dim Calendar As Calendar
                                        Calendar = control_in_placeholder
                                        control_collection.Add(Calendar, Calendar.ID)

                                    End If


                                    If TypeOf control_in_placeholder Is Panel Then
                                        'MsgBox(ctlContent.ID)
                                        For Each control In control_in_placeholder.Controls

                                            If TypeOf control Is TextBox Then
                                                Dim textbox As TextBox
                                                textbox = control
                                                control_collection.Add(textbox, textbox.ID)

                                            ElseIf TypeOf control Is CheckBox Then
                                                Dim CheckBox As CheckBox
                                                CheckBox = control
                                                control_collection.Add(CheckBox, CheckBox.ID)

                                            ElseIf TypeOf control Is RadioButtonList Then
                                                Dim RadioButtonList As RadioButtonList
                                                RadioButtonList = control
                                                control_collection.Add(RadioButtonList, RadioButtonList.ID)

                                            ElseIf TypeOf control Is DropDownList Then
                                                Dim DropDownList As DropDownList
                                                DropDownList = control
                                                control_collection.Add(DropDownList, DropDownList.ID)

                                            ElseIf TypeOf control Is RadioButton Then
                                                Dim RadioButton As RadioButton
                                                RadioButton = control
                                                control_collection.Add(RadioButton)

                                            ElseIf TypeOf control Is Calendar Then
                                                Dim Calendar As Calendar
                                                Calendar = control
                                                control_collection.Add(Calendar, Calendar.ID)

                                            End If
                                        Next control
                                    End If ' pannel
                                Next ' pannel
                            End If
                        Next
                    End If
                Next
            End If
        Next

        Return control_collection


    End Function


    'Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
    '    Cal_evacuation_date.Visible = True
    'End Sub

    'Protected Sub Cal_evacuation_date_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cal_evacuation_date.SelectionChanged
    '    Cal_evacuation_date.Visible = False
    '    txt_evacuation_date.Text = Format(Cal_evacuation_date.SelectedDate, "dd/MM/yyyy") '& " " & DateTime.Now.ToString("T") 'String.Format(Now, " HH:mm:ss")

    'End Sub


    Protected Sub ddl_currency_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_currency.SelectedIndexChanged
        If ddl_currency.SelectedIndex > 0 Then
            lbl_total_all.Visible = True
            txt_total_all.Text = ""
            txt_total_all.Visible = True
            lnk_reset_grid_view.Visible = True
        Else
            lbl_total_all.Visible = False
            txt_total_all.Visible = False
            lnk_reset_grid_view.Visible = False
        End If

        sql = "SELECT category,fk_currency_category_recordID FROM currency_type_category_view WHERE fk_currency_type_recordID = " & ddl_currency.SelectedIndex
        data_table_name = "number_of_rows_for_this_currency"
        data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, data_table_name)
        If data_set_various IsNot Nothing Then

            Session("data_table") = data_set_various.Tables(data_table_name)
            Gridview1.DataSource = Session("data_table")
            Gridview1.DataBind()

        Else
            lbl_result.Visible = True
            lbl_result.Text = "No Data Found !!"
        End If

    End Sub


    Protected Sub rbl_direction_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbl_direction.SelectedIndexChanged
        If rbl_direction.Items(1).Selected = True Then
            td_from_to.InnerText = "TO"
        Else
            td_from_to.InnerText = "FROM"
        End If
        ddl_currency.Enabled = True
        ddl_source_target.Enabled = True
        If rbl_direction.Items(0).Selected = True And Session("Group_RecordID") = 3 Then  'in and teller   
            sql = "SELECT RecordID , name  FROM  levels_table where RecordID in (1,4,5)"  'execlude vault or teller to avoid teller in from vault or teller
            Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_source_target, "RecordID", "name", 1)
        ElseIf rbl_direction.Items(1).Selected = True And Session("Group_RecordID") = 3 Then  'out and teller 
            sql = "SELECT RecordID , name  FROM  levels_table where RecordID in (1,2,4,5)"
            Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_source_target, "RecordID", "name", 1)
        End If

    End Sub



    Protected Sub TextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)

        'Dim textbox_1, textbox_2, txt_total_individual As TextBox
        'Dim current_row As GridViewRow = TryCast(sender, TextBox).Parent.Parent
        'textbox_1 = DirectCast(current_row.FindControl("TextBox1"), TextBox)
        'textbox_2 = DirectCast(current_row.FindControl("TextBox2"), TextBox)
        'txt_total_individual = DirectCast(Gridview1.FooterRow.FindControl("txt_total_individual"), TextBox)


        'Session("individual_amount") = CDbl(textbox_1.Text) * CDbl(Session("data_table").Rows(current_row.RowIndex)(0))
        'textbox_2.Text = Session("individual_amount") 'individual_amount

        'Session("total_individual") = Session("total_individual") + Session("individual_amount")
        'txt_total_individual.Text = Session("total_individual") 'total_individual

        '=======================================================================================


        Dim txt_total_individual As TextBox
        txt_total_individual = DirectCast(Gridview1.FooterRow.FindControl("txt_total_individual"), TextBox)
        Session("individual_amount") = 0
        Session("total_individual") = 0

        For Each row As GridViewRow In Gridview1.Rows
            Dim textbox_1, textbox_2 As TextBox
            textbox_1 = DirectCast(row.FindControl("TextBox1"), TextBox)
            textbox_2 = DirectCast(row.FindControl("TextBox2"), TextBox)

            If Trim(textbox_1.Text) <> "" Then

                Session("individual_amount") = CDbl(textbox_1.Text) * CDbl(Session("data_table").Rows(row.RowIndex)(0))
                textbox_2.Text = Session("individual_amount") 'individual_amount
                Session("total_individual") = Session("total_individual") + Session("individual_amount")
            ElseIf Trim(textbox_1.Text) = "" Then
                textbox_2.Text = ""
            End If
        Next

        txt_total_individual.Text = Session("total_individual") 'total_individual
        Session("total_amount") = Session("total_individual") + Session("total_backage")
        txt_total_all.Text = Session("total_amount")

        If Session("total_amount") = 0 Then
            cmd_add_update.Enabled = False
        End If

    End Sub

    Protected Sub TextBox3_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        'Dim textbox_3, textbox_4, txt_total_backage As TextBox
        'Dim current_row As GridViewRow = TryCast(sender, TextBox).Parent.Parent

        'textbox_3 = DirectCast(current_row.FindControl("TextBox3"), TextBox)
        'textbox_4 = DirectCast(current_row.FindControl("TextBox4"), TextBox)
        'txt_total_backage = DirectCast(Gridview1.FooterRow.FindControl("txt_total_backage"), TextBox)

        'Session("backage_amount") = CDbl(textbox_3.Text) * CDbl(Session("data_table").Rows(current_row.RowIndex)(0)) * 100
        'textbox_4.Text = Session("backage_amount")

        'Session("total_backage") = Session("total_backage") + Session("backage_amount")
        'txt_total_backage.Text = Session("total_backage")

        '======================================================================================

        Dim txt_total_backage As TextBox
        txt_total_backage = DirectCast(Gridview1.FooterRow.FindControl("txt_total_backage"), TextBox)
        Session("backage_amount") = 0
        Session("total_backage") = 0

        For Each row As GridViewRow In Gridview1.Rows
            Dim textbox_3, textbox_4 As TextBox
            textbox_3 = DirectCast(row.FindControl("TextBox3"), TextBox)
            textbox_4 = DirectCast(row.FindControl("TextBox4"), TextBox)

            If Trim(textbox_3.Text) <> "" Then

                Session("backage_amount") = CDbl(textbox_3.Text) * CDbl(Session("data_table").Rows(row.RowIndex)(0)) * 100
                textbox_4.Text = Session("backage_amount")
                Session("total_backage") = Session("total_backage") + Session("backage_amount")

            ElseIf Trim(textbox_3.Text) = "" Then
                textbox_4.Text = ""
            End If

        Next

        txt_total_backage.Text = Session("total_backage")
        Session("total_amount") = Session("total_individual") + Session("total_backage")
        txt_total_all.Text = Session("total_amount")

        If Session("total_amount") = 0 Then
            cmd_add_update.Enabled = False
        End If

    End Sub

    Protected Sub Gridview1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles Gridview1.RowDataBound
        ' to access grid view footer
        'If e.Row.RowType = DataControlRowType.Header Then
        '    e.Row.Cells(3).Text = "TOTAL ALL : "
        '    e.Row.Cells(4).Text = Session("total_amount")
        'End If
    End Sub

    Protected Sub ddl_source_target_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_source_target.SelectedIndexChanged
        If rbl_direction.Items(1).Selected = True And ddl_source_target.SelectedIndex = 3 Then
            txt_source.Visible = True
            txt_source.Text = "Vault"

        End If

        If ddl_source_target.SelectedIndex > 0 And Session("total_amount") <> 0 Then
            cmd_add_update.Enabled = True
        End If


    End Sub


    Protected Sub ddl_user_account_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_user_account.SelectedIndexChanged
        If ddl_user_account.SelectedIndex > 0 And Session("total_amount") <> 0 Then
            cmd_add_update.Enabled = True
        End If
    End Sub

    Protected Sub lnk_reset_grid_view_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnk_reset_grid_view.Click
        reset_text_box_template_in_gridview(Gridview1)
        txt_total_all.Text = ""
    End Sub
End Class
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         