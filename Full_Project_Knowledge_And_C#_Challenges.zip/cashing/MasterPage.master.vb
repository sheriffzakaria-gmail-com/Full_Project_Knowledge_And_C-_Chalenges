
Partial Class MasterPage
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Session("Group_RecordID") = 1 Then
        '    Lnk_check_lists_checker.Enabled = False
        '    Lnk_check_lists_cres.Enabled = False
        '    Lnk_branch_data.Enabled = False
        '    lnk_branches_check_lists_status.Enabled = False
        '    Lnk_meta_data.Enabled = False
        '    Lnk_summary_report.Enabled = False

        'ElseIf Session("Group_RecordID") = 2 Then
        '    Lnk_check_lists_maker.Enabled = False
        '    Lnk_check_lists_cres.Enabled = False
        '    Lnk_add_cashing.Enabled = False
        '    Lnk_branch_data.Enabled = False
        '    lnk_branches_check_lists_status.Enabled = False
        '    Lnk_meta_data.Enabled = False
        '    Lnk_summary_report.Enabled = False
        '    Lnk_add_emergency_chart.Enabled = False
        '    Lnk_add_evacuation.Enabled = False
        '    Lnk_add_cleaning_evaluation.Enabled = False

        'ElseIf Session("Group_RecordID") = 3 Then
        '    Lnk_check_lists_maker.Enabled = False
        '    Lnk_check_lists_checker.Enabled = False
        '    'Lnk_evacuation.Enabled = False
        '    Lnk_add_cashing.Enabled = False
        '    Lnk_add_emergency_chart.Enabled = False
        '    Lnk_add_evacuation.Enabled = False
        '    Lnk_add_cleaning_evaluation.Enabled = False
        '    lnk_branch_data_view.Enabled = False

        'End If
    End Sub

End Class

