﻿
Partial Class test
    Inherits System.Web.UI.Page

End Class
