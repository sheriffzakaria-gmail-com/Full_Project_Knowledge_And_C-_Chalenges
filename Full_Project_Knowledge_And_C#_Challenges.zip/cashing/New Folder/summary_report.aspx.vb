﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class evacuation
    Inherits System.Web.UI.Page
    Dim url As String

    Dim data_set_various As DataSet
    Dim data_row_various As DataRow
    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    'various
    Dim array(0) As String
    Dim command_field As CommandField
    Dim link_field As HyperLinkField

    Dim sql, data_table_name As String

    Protected Sub GridView_summary_report_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView_summary_report.PageIndexChanging
        GridView_summary_report.PageIndex = e.NewPageIndex
        'here i should refill the data set again
        Call fill_grid_view(1)
    End Sub

    Protected Sub GridView_summary_report_2_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView_summary_report.PageIndexChanging
        GridView_summary_report_2.PageIndex = e.NewPageIndex
        'here i should refill the data set again
        Call fill_grid_view(2)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button


            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))

                Call fill_grid_view(1)
                If data_set_various.Tables(data_table_name).Rows.Count = 0 Then
                    lbl_result.Visible = True
                    lbl_result.Text = "No Data Found !!"
                End If

                Call fill_grid_view(2)
                If data_set_various.Tables(data_table_name).Rows.Count = 0 Then
                    lbl_result.Visible = True
                    lbl_result.Text = "No Data Found !!"
                End If

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub

    
    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub


    Public Sub fill_grid_view(Optional ByVal s_sql_types As Integer = 100) '100 means all 
        If s_sql_types = 1 Then
            sql = "select * from total_per_branch_view order by Month DESC"
            data_table_name = "total_per_branch"
            data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, data_table_name)
            GridView_summary_report.DataSource = data_set_various.Tables(data_table_name)
            GridView_summary_report.DataBind()
        ElseIf s_sql_types = 2 Then
            sql = "select * from total_all_branches_view"
            data_table_name = "total_all_branches"
            data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, data_table_name)
            GridView_summary_report_2.DataSource = data_set_various.Tables(data_table_name)
            GridView_summary_report_2.DataBind()

        End If

    End Sub


 


End Class
