﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class cashing_old
    Inherits System.Web.UI.Page
    Dim url As String

    Dim data_set_various As DataSet
    Dim data_row_various As DataRow
    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    'various
    Dim array(0) As String
    Dim command_field As CommandField
    Dim link_field As HyperLinkField

    Dim sql, data_table_name As String

    Protected Sub GridView_emergency_chart_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView_transaction_details.PageIndexChanging
        GridView_transaction_details.PageIndex = e.NewPageIndex
        'here i should refill the data set again
        Call fill_grid_view()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button


            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))

                Call refresh_detail_view()

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub

    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub

    Protected Sub DetailsView1_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles DetailsView1.DataBound

        If data_set_various.Tables(0).Rows.Count > 0 Then
            If DetailsView1.Rows(9).Cells(1).Text = "Authorized" Then
                DetailsView1.Fields(12).Visible = False 'button field as link called authorize
            Else
                DetailsView1.Fields(12).Visible = True
            End If
        End If

    End Sub

    Protected Sub DetailsView1_ItemCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DetailsViewCommandEventArgs) Handles DetailsView1.ItemCommand
        If e.CommandName = "Authorize" Then
            If Session("Group_RecordID") = 2 Then 'vault
                sql = "update master_transacton_table set authorized = 2 , teller_vault_user_account = " & Session("user_login_account") & " where RecordID = " & DetailsView1.Rows(0).Cells(1).Text
            Else ' teller
                sql = "update master_transacton_table set authorized = 2   where RecordID = " & DetailsView1.Rows(0).Cells(1).Text
            End If

            Call customer_information_class_object.s_update_status(Session("connection_string"), sql)

            Call refresh_detail_view()
        End If

        If e.CommandName = "Show Details" Then
            Call fill_grid_view()
        End If
    End Sub

    Protected Sub DetailsView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DetailsViewPageEventArgs) Handles DetailsView1.PageIndexChanging

        DetailsView1.PageIndex = e.NewPageIndex
        Call refresh_detail_view()

    End Sub

    Public Sub refresh_detail_view()
        If Session("Group_RecordID") = 2 Then ' vault

            Call fill_detail_view(2)

        ElseIf Session("Group_RecordID") = 3 Then ' teller

            Call fill_detail_view(3)

        End If
    End Sub

    Public Sub fill_grid_view(Optional ByVal s_sql_types As Integer = 100) '100 means all for maker
        sql = "select * from  detail_currency_View where fk_transaction_RecordID = " & DetailsView1.Rows(0).Cells(1).Text

        data_table_name = "detail_currency_View"

        data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, data_table_name)
        If data_set_various IsNot Nothing Then
            GridView_transaction_details.DataSource = data_set_various.Tables(data_table_name)
            GridView_transaction_details.DataBind()
        Else
            lbl_result.Visible = True
            lbl_result.Text = "No Data Found !!"
        End If

    End Sub
    Public Sub fill_detail_view(Optional ByVal s_sql_types As Integer = 0)
        If s_sql_types = 2 Then 'log in as vault
            sql = "select * from master_transacton_view where fk_branch_RecordID = " & Session("branch_RecordID") & _
                     " and  level_RecordID = 2 order by date desc"

        ElseIf s_sql_types = 3 Then ' log in as teller
            sql = "select * from master_transacton_view where fk_branch_RecordID = " & Session("branch_RecordID") & _
         " and  level_RecordID = 3 and teller_vault_user_account = " & Session("user_login_account") & " order by date desc"

        End If


        data_table_name = "master_transacton_view"

        data_set_various = customer_information_class_object.fn_search_data(Session("connection_string"), sql, data_table_name)
        If data_set_various IsNot Nothing Then
            DetailsView1.DataSource = data_set_various.Tables(data_table_name)
            DetailsView1.DataBind()
        Else
            DetailsView1.EmptyDataText = "<h1>No records </h1>"
            lbl_result.Visible = True
            lbl_result.Text = "No Data Found !!"
        End If
    End Sub
End Class
