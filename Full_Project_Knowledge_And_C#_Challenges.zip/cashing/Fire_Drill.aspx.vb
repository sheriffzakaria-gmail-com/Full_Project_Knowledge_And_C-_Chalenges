﻿

Imports System.Data
Imports System.Data.SqlClient


Partial Class fire_drill
    Inherits System.Web.UI.Page

    Public Shared connection_string As String
    Public Shared required_connection As String

    Public Shared oracle_connection_string, oracle_prime_connection_string As String
    Public Shared oracle_required_connection As String

    Dim data_set_various As DataSet 'here if i will retrieve from the function dataset 
    Dim data_table_various As DataTable
    Shared data_row_various As DataRow 'here if i will retrieve from the function just 1 datarow


    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    Dim sql As String
    Dim answer As Boolean

    Public Function prepare_connection(ByVal s_required_connection As String) As String
        Return GeneralClass.GetConnectionString(s_required_connection) 'because GeneralClass under app_code we use it direct without import it in this class
    End Function
    Public Sub reset_any_controls(ByVal controls As ControlCollection)
        Dim control As Control

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then
                                'MsgBox(ctlContent.ID)
                                For Each control In ctlContent.Controls
                                    'MsgBox(control.ID)
                                    ' Do work...
                                    If TypeOf control Is TextBox Then
                                        Dim textbox As TextBox
                                        textbox = control
                                        textbox.Text = ""
                                    ElseIf TypeOf control Is DropDownList Then
                                        Dim DropDownList As DropDownList
                                        DropDownList = control
                                        DropDownList.SelectedIndex = -1

                                        ''ElseIf TypeOf control Is Calendar Then
                                        ''    Dim calendar As Calendar
                                        ''    calendar = control
                                        ''    calendar.Enabled = False
                                    End If
                                Next control

                            End If
                        Next
                    End If
                Next
            End If
        Next


    End Sub
    Public Sub fill_control_with_data(ByVal s_data_row As DataRow, ByVal s_all_part As Integer) ' 1 all but 2 fill some control  
        If s_all_part = 1 Then

            txt_branch_name.Text = IIf(s_data_row("branch_name") IsNot DBNull.Value, s_data_row("branch_name"), "")
            'If(IsDBNull(dRow("sysdate")), "", Format(dRow("sysdate"), "MM/dd/yyyy")) ' in visual studio 2011 and 2010 we can use this concept but if i will use iif it will return error in case if the field value = null cause i cant use format(null,"dd/MM/yyyy") but i can solve it by using IIf(s_data_row("insurance_ending_date") IsNot DBNull.Value, Format(CStr(s_data_row("insurance_ending_date") & ""), "Short Date"), String.Empty)
            txt_date.Text = IIf(s_data_row("date") IsNot DBNull.Value, Format(CStr(s_data_row("date") & ""), "Short Date"), String.Empty) ' i try this in case of null Format(Now, "dd/MM/yyyy")) ' also i can use  in stored procedure convert(varchar(10), CAST( [Insurance_starting_date] as Insurance_starting_date  ),103)   ' old use CStr(Cal_Insurance_starting_date.SelectedDate.Day) & "/" & CStr(Cal_Insurance_starting_date.SelectedDate.Month) & "/" & Cal_Insurance_starting_date.SelectedDate.Year
            txt_evacuation_duration.Text = IIf(s_data_row("evacuation_duration") IsNot DBNull.Value, s_data_row("evacuation_duration"), "")
            txt_observation.Text = IIf(s_data_row("observation") IsNot DBNull.Value, s_data_row("observation"), "")

            CheckBox1.Checked = IIf(s_data_row("emergency_manager_red_hat") IsNot DBNull.Value, s_data_row("emergency_manager_red_hat"), False)
            CheckBox2.Checked = IIf(s_data_row("evacuation_manager") IsNot DBNull.Value, s_data_row("evacuation_manager"), False)
            CheckBox3.Checked = IIf(s_data_row("first_aider") IsNot DBNull.Value, s_data_row("first_aider"), False)
            CheckBox4.Checked = IIf(s_data_row("fire_fighters") IsNot DBNull.Value, s_data_row("fire_fighters"), False)
            CheckBox5.Checked = IIf(s_data_row("evacuation_monitor") IsNot DBNull.Value, s_data_row("evacuation_monitor"), False)

            txt_reason_of_evacuation.Text = IIf(s_data_row("reason_of_evacuation") IsNot DBNull.Value, s_data_row("reason_of_evacuation"), "")
            txt_comment.Text = IIf(s_data_row("comment") IsNot DBNull.Value, s_data_row("comment"), "")
            txt_branch_manager_name.Text = IIf(s_data_row("branch_manager_name") IsNot DBNull.Value, s_data_row("branch_manager_name"), "")

        ElseIf s_all_part = 2 Then
            txt_branch_name.Text = Session("branch_name") 'IIf(s_data_row("branch_name") IsNot DBNull.Value, s_data_row("branch_name"), "")
            txt_date.Text = Format(Now, "dd/MM/yyyy")
        End If

    End Sub

    

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then  'here we need execute the below during the normal load for the page not the load as result from control like button

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then

                data_row_various = customer_information_class_object.fn_check_fire_drill_record(Session("connection_string"), Now, Session("branch_RecordID"))

                If data_row_various IsNot Nothing Then ' we here has 1 record
                    Session("fire_drill_process") = 2 'update
                    'show the data in control
                    Call fill_control_with_data(data_row_various, 1) ' here the record is exist so that we will fill all the control with the all data
                    Session("fire_drill_RecordID") = data_row_various("RecordID") 'to use it in update statment

                Else
                    Session("fire_drill_process") = 1 'insert
                    'show the date and branch
                    Call fill_control_with_data(Nothing, 2) ' may be here we will send nothing not ==> data_table_various.Rows(0)

                End If

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If


        End If

    End Sub

    Protected Sub Image_save_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles Image_save.Click
        Dim control_collection As Collection

        control_collection = fill_control_collection()


        If Session("fire_drill_process") = 1 Then ' insert
            Session("fire_drill_RecordID") = customer_information_class_object.fn_Fire_Drill_add_update_record(Session("connection_string"), Session("branch_RecordID"), control_collection, Session("user_RecordID"), Session("fire_drill_process"))
            lbl_result.Text = ("<h4><font color = 'green'>  Thank you The Record Has Been Added Successfully </font></h4>")
            ' ImageButton1.Enabled = False
        ElseIf Session("fire_drill_process") = 2 Then 'update
            customer_information_class_object.fn_Fire_Drill_add_update_record(Session("connection_string"), Session("branch_RecordID"), control_collection, Session("user_RecordID"), Session("fire_drill_process"), Session("fire_drill_RecordID"))
            lbl_result.Text = ("<h4><font color = 'green'> Thank you The Record Has Been Updated Successfully </font></h4>")
        End If

        Image_save.Enabled = False

    End Sub



    Public Function fill_control_collection() As Collection
        Dim control_collection As New Collection()


        Dim control As Control ' not used

        For Each ctlMaster As Control In Page.Controls
            If TypeOf ctlMaster Is MasterPage Then
                For Each ctlForm As Control In ctlMaster.Controls
                    'MsgBox(ctlForm.ID)
                    If TypeOf ctlForm Is HtmlForm Then
                        For Each ctlContent As Control In ctlForm.Controls
                            'MsgBox(ctlContent.ID)
                            If TypeOf ctlContent Is ContentPlaceHolder Then
                                'MsgBox(ctlContent.ID)
                                For Each control_in_placeholder As Control In ctlContent.Controls 'content place holder
                                    If TypeOf control_in_placeholder Is TextBox Then
                                        Dim textbox As TextBox
                                        textbox = control_in_placeholder
                                        control_collection.Add(textbox, textbox.ID)

                                    ElseIf TypeOf control_in_placeholder Is CheckBox Then
                                        Dim CheckBox As CheckBox
                                        CheckBox = control_in_placeholder
                                        control_collection.Add(CheckBox, CheckBox.ID)

                                    End If


                                    If TypeOf control_in_placeholder Is Panel Then
                                        'MsgBox(ctlContent.ID)
                                        For Each control In control_in_placeholder.Controls

                                            If TypeOf control Is TextBox Then
                                                Dim textbox As TextBox
                                                textbox = control
                                                control_collection.Add(textbox, textbox.ID)

                                            ElseIf TypeOf control Is CheckBox Then
                                                Dim CheckBox As CheckBox
                                                CheckBox = control
                                                control_collection.Add(CheckBox, CheckBox.ID)


                                                'ElseIf TypeOf control Is RadioButton And InStr(control.ID, "true") > 0 Then
                                                '    Dim RadioButton As RadioButton
                                                '    RadioButton = control
                                                '    collection_opt.Add(RadioButton)

                                                'ElseIf TypeOf control Is RadioButton And InStr(control.ID, "false") > 0 Then
                                                '    Dim RadioButton_false As RadioButton
                                                '    RadioButton_false = control
                                                '    collection_opt_false.Add(RadioButton_false)


                                            End If
                                        Next control
                                    End If ' pannel
                                Next ' pannel
                            End If
                        Next
                    End If
                Next
            End If
        Next

        Return control_collection


    End Function

    Public Sub reset_some_controls(ByVal s_control_collection As Collection)

        For Each control As Control In s_control_collection

            If TypeOf control Is TextBox Then
                Dim text_box As TextBox
                'text_box = CType(Control, TextBox)
                text_box = control
                text_box.Text = ""


            ElseIf TypeOf control Is RadioButton Then
                Dim radio_button As RadioButton
                radio_button = control
                radio_button.Checked = False
            End If

        Next
    End Sub


End Class
