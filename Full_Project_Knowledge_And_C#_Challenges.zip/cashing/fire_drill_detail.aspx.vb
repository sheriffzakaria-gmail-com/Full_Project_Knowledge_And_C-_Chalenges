﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class fire_drill_all
    Inherits System.Web.UI.Page
    Dim url As String

    Dim data_set_various As DataSet
    Dim data_row_various As DataRow
    Dim general_class_object As New GeneralClass
    Dim customer_information_class_object As New customer_information_class

    'various
    Dim array(0) As String
    Dim command_field As CommandField
    Dim link_field As HyperLinkField

    Dim sql As String
    Dim data_table_name As String


    Protected Sub GridView_fire_drill_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView_fire_drill.PageIndexChanging
        GridView_fire_drill.PageIndex = e.NewPageIndex
        'here i should refill the data set again
        If Session("Group_RecordID") = 3 Then
            If ddl_branches.SelectedIndex = 0 Then
                sql = "select * from fire_drill_view"
                Call get_all_fire_drill_branches_or_1(sql)
            Else
                Session("branch_RecordID") = ddl_branches.SelectedItem.Value
                sql = "select * from fire_drill_view where  Branch_RecordID = " & Session("branch_RecordID")
                Call get_all_fire_drill_branches_or_1(sql)
            End If
        ElseIf Session("Group_RecordID") = 2 Then
            If RadioButtonList1.SelectedIndex = 0 Then
                GridView_fire_drill.Columns(14).Visible = True
                sql = "select * from fire_drill_view where  Branch_RecordID = " & Session("branch_RecordID") & " and Authorized = 1"
            Else
                GridView_fire_drill.Columns(14).Visible = False
                sql = "select * from fire_drill_view where  Branch_RecordID = " & Session("branch_RecordID") & " and Authorized = 2"
            End If
            data_table_name = "fire_drill_information_table"
            data_set_various = customer_information_class_object.fn_get_data_for_grid_view(Session("connection_string"), sql, data_table_name)
            GridView_fire_drill.DataSource = data_set_various.Tables(data_table_name)
            GridView_fire_drill.DataBind()

        ElseIf Session("Group_RecordID") = 1 Then

            sql = "select * from fire_drill_view where  Branch_RecordID = " & Session("branch_RecordID")
            Call get_all_fire_drill_branches_or_1(sql)
        End If

    End Sub

    Protected Sub GridView_fire_drill_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView_fire_drill.RowCommand
        If e.CommandName = "Edit" Then 'the best if i use button field not command field
            Dim fire_drill_recordID As Integer = Convert.ToInt32(GridView_fire_drill.DataKeys(0).Value)
            sql = "update fire_drill_table set authorized = 2 where RecordID = " & fire_drill_recordID
            customer_information_class_object.fn_authorize_fire_drill(Session("connection_string"), sql)
            'also i can use the below
            'Dim index As Integer = Convert.ToInt32(e.CommandArgument)
            'sql = "update fire_drill_table set authorized = 2 where RecordID = " & GridView_fire_drill.Rows(index).Cells(0).Text

        End If

        If e.CommandName = "Delete" Then

            Dim index As Integer = Convert.ToInt32(e.CommandArgument)

            Dim result_of_function As Boolean

            Session("check_list_RecordID") = GridView_fire_drill.Rows(index).Cells(0).Text
            result_of_function = customer_information_class_object.fn_check_list_information_Delete(Session("connection_string"))

            If result_of_function = True Then
                lbl_result.Text = ("<h4><font color = 'green'> :) The Record Has Been Deleted Successfully :)</font></h4>")
            Else
                lbl_result.Text = ("<h4><font color = 'red'> :) There Is Error Happened During The Deletion Process <br>The Record Has Not Been Deleted :(</font></h4>")
            End If

        End If


    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then 'here we need execute the below during the normal load for the page not the load as result from control like button


            Session("user_login_account") = GeneralClass.get_user_login_account()

            If GeneralClass.validate_user_account_in_admin_db(Session("connection_string"), Session("user_login_account")) = True Then
                data_row_various = general_class_object.get_user_id_and_user_type(Session("connection_string"), Session("user_login_account"))

                If Session("Group_RecordID") = 2 Then
                    RadioButtonList1.Visible = True

                End If

                If Session("Group_RecordID") = 3 Then
                    ddl_branches.Visible = True
                    Call fill_all_drop_down_list_boxes()
                    sql = "select * from fire_drill_view"
                    Call get_all_fire_drill_branches_or_1(sql)

                ElseIf Session("Group_RecordID") = 1 Then
                    sql = "select * from fire_drill_view where  Branch_RecordID = " & Session("branch_RecordID")
                    Call get_all_fire_drill_branches_or_1(sql)
                End If

            Else
                Response.Redirect("~\invalid_login.aspx")
            End If

        End If
    End Sub

    Protected Sub GridView_fire_drill_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridView_fire_drill.RowEditing
        'url = System.Configuration.ConfigurationManager.AppSettings("url_add_update_check_list") ' "~/health_and_safty_check_list.aspx?"
        'Response.Redirect(url & "RecordID=" & GridView_fire_drill.Rows(e.NewEditIndex).Cells(0).Text)
    End Sub

    Protected Sub GridView_fire_drill_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridView_fire_drill.SelectedIndexChanging
        'url = System.Configuration.ConfigurationManager.AppSettings("url_check_list_details")
        'Response.Redirect(url & "RecordID=" & GridView_fire_drill.Rows(e.NewSelectedIndex).Cells(0).Text)

    End Sub

    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub
    Public Sub fill_all_drop_down_list_boxes()

        sql = "SELECT RecordID , name FROM TblBranches"
        Call general_class_object.fill_any_drop_down_list(GeneralClass.get_data_reader(Session("connection_string"), sql), ddl_branches, "RecordID", "name")

    End Sub
    Protected Sub ddl_branches_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_branches.SelectedIndexChanged

        If ddl_branches.SelectedIndex = 0 Then 'also we can say  ddl_branches.selecteditem.value = -1
            sql = "select * from fire_drill_view"
            Call get_all_fire_drill_branches_or_1(sql)
        Else
            Session("branch_RecordID") = ddl_branches.SelectedItem.Value
            sql = "select * from fire_drill_view where  Branch_RecordID = " & Session("branch_RecordID")
            Call get_all_fire_drill_branches_or_1(sql)
        End If

    End Sub
    Public Sub get_all_fire_drill_branches_or_1(ByVal s_sql As String)
        lbl_result.Text = ""
        data_set_various = customer_information_class_object.fn_fire_drill_information_search(Session("connection_string"), s_sql)
        GridView_fire_drill.DataSource = data_set_various.Tables("fire_drill_information_table")
        GridView_fire_drill.DataBind()
        If data_set_various.Tables("fire_drill_information_table").Rows.Count = 0 Then
            lbl_result.Visible = True
            lbl_result.Text = "No Data Found !!"
 
        End If
    End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        lbl_result.Text = ""
        If RadioButtonList1.SelectedIndex = 0 Then
            GridView_fire_drill.Columns(14).Visible = True
            sql = "select * from fire_drill_view where  Branch_RecordID = " & Session("branch_RecordID") & " and Authorized = 1"
        Else
            GridView_fire_drill.Columns(14).Visible = False
            sql = "select * from fire_drill_view where  Branch_RecordID = " & Session("branch_RecordID") & " and Authorized = 2"
        End If
        data_table_name = "fire_drill_information_table"
        data_set_various = customer_information_class_object.fn_get_data_for_grid_view(Session("connection_string"), sql, data_table_name)
        GridView_fire_drill.DataSource = data_set_various.Tables(data_table_name)
        GridView_fire_drill.DataBind()

        If data_set_various.Tables(data_table_name).Rows.Count = 0 Then
            lbl_result.Visible = True
            lbl_result.Text = "No Data Found !!"
        End If
    End Sub
End Class
